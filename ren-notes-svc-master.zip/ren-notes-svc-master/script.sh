#!/bin/bash

java -javaagent:/newrelic/newrelic.jar -jar ./app.jar
