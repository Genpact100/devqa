## ren-spring-boot-template-jre11
test

This is a template application (starter project) for creating a java 11 spring boot APIs. The template helps the developers to setup the workspace and start working on actual API / business logic in minutes.

The teamplate includes the following..
  - The template extends from the parent POM, which has all the common dependencies / libraries (eg logging, errorcode etc).
  - Sonar cube plugin.
  - Dockerfile with appropriate base image
  - Devops / CICD setup.
  - Healthcheck APIs.
  - Unit test case setup.

Tobe included in future..

  - API security
  - Local sonar cube setup
  - Cucumber framework setup. 
  - Other best practices.

## Advantages.

  - Enforce common code structure across platform
  - All the application extends common parent app.. 
  - Makes the common dependencies available through parent pom.
  - Enforce standard versioning of artifact across platform.
  - Reusability.
  
## Clone the repo.

``` 
git clone git@github.build.ge.com:REN-AWS/ren-spring-boot-template-jre11.git

copy files from  ren-spring-boot-template-jre11 to <name of your project>
```

## Create a project in github and Change the git origin

- Create a new project in git with <name of your project>
- Copy the command to change the git origin, provided by github
- On git-bash or command line, change the directoy (cd) to your project directory.
- execute the below git command (remeter to replace the attribute 'add' with 'set-url')
``` 
git init
git add .
git commit -m "first commit'
git remote add origin <git url>
git push -u origin master

```
	
## Replace the placeholder string (ren-spring-boot-template-jre11) in files..
 There is a placeholder string (ren-spring-boot-template-jre11 ) in the following files which needs to be replaced by the appropriate name for your project.
Files you need to replace the string in..
  - pom.xml 
  - Dockerfile
  - devops/values.xml
  - devops/Chart.yaml
  - Java file, com.ge.ren.resource.HealthCheckResource.java
  - Java unit test file, com.ge.ren.resource.HealthCheckResourceTest.java
 
Either replace it manually or use the following command in the git bash
``` 
sed -i 's/ren-spring-boot-template-jre11/YOUR_APPICATION_NAME/g' Dockerfile pom.xml devops/helm/values.yaml devops/helm/Chart.yaml src/main/java/com/ge/ren/resource/HealthCheckResource.java src/test/java/com/ge/ren/resource/HealthCheckResourceTest.java
```
Commint the above changes to github

## Create a webhook in your git repo
- In setting - hook add https://devops-ds.ren.apps.ge.com/jenkins/github-webhook
- Select push and pull option.
- Refer to the devops repo for details .. 
- https://github.build.ge.com/REN-AWS/devops-pipeline

## Jenkins.
- Create a new item in your POD
- Provide the name of the project and 
- Provide the github link.
- Select user as github
- For details https://github.build.ge.com/REN-AWS/devops-pipeline

## Maven dependencies:
-  mvn dependency:tree

 
 
 
