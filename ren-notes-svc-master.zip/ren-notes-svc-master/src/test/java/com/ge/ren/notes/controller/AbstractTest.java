package com.ge.ren.notes.controller;

import java.io.IOException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ren.NotesApplicationSvc;


@SpringBootTest(classes = NotesApiController.class)
@RunWith(SpringRunner.class)
@WebAppConfiguration
@AutoConfigureMockMvc
@EnableWebMvc
public abstract class AbstractTest {
	@Autowired
	protected MockMvc mockMvc;

   @Autowired
   NotesApiController controller;
   
   protected void setUp() {
      mockMvc = MockMvcBuilders.standaloneSetup(controller).build(); //.webAppContextSetup(webApplicationContext).build();
      //this.mockMvc = MockMvcBuilders.standaloneSetup(controller)
      //		  .setControllerAdvice(new ExceptionHandler()).alwaysExpect(MockMvcResultMatchers.content().contentType("application/json")).build();
      System.out.println(">> MockMvc setup is done for Controller test!");
   }
   protected String mapToJson(Object obj) throws JsonProcessingException {
      ObjectMapper objectMapper = new ObjectMapper();
      return objectMapper.writeValueAsString(obj);
   }
   protected <T> T mapFromJson(String json, Class<T> clazz)
      throws JsonParseException, JsonMappingException, IOException {
      
      ObjectMapper objectMapper = new ObjectMapper();
      return objectMapper.readValue(json, clazz);
   }
}