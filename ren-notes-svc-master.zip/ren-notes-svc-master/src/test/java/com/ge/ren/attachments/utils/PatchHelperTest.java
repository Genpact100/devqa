package com.ge.ren.attachments.utils;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Validator;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.TreeNode;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ren.attachments.model.patch.Attachment;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.model.patch.Patch;
import com.ge.ren.notes.constants.Scope;
import com.ge.ren.notes.dto.Note;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
//@ActiveProfiles("dev")
@TestInstance(Lifecycle.PER_CLASS)
@RunWith(SpringRunner.class)
@SpringBootTest (classes = {PatchHelper.class}, properties = {"descriptionSize=20", "titleSize=10", "storageType=fyleSystem"})
//@TestPropertySource(locations = "/application.properties")
//@AutoConfigureMockMvc
@RequiredArgsConstructor
public class PatchHelperTest {

	//@MockBean
	//ObjectMapper objectMapper;
	
	@Autowired
	PatchHelper helper;
	
	@BeforeAll
    void setUp() throws IOException, JsonPatchException {
		System.setProperty("spring.profiles.active", "dev");
		MockitoAnnotations.initMocks(this);
		//mockBackEnd = new MockWebServer();
        //mockBackEnd.start();
        //when(requestInterceptor.getTenantId()).thenReturn("tenantId");
        //when(requestInterceptor.getResource(anyString())).thenReturn(Arrays.asList(new String[]{"ALL"}));
		//when(objectMapper.readTree(anyString())).thenReturn(new JsonNode());
	    // Create the patch
		//com.github.fge.jsonpatch.JsonPatch patching = com.github.fge.jsonpatch.JsonPatch.fromJson(patchNode);
	    // Convert the original object to JsonNode
	    //JsonNode originalObjNode = objectMapper.valueToTree(originalObj);

		//when(objectMapper.treeToValue(any(), any())).thenReturn(getNote());
	}
	
	
	@Test
	public void applyPatch() throws JsonProcessingException, IOException, JsonPatchException {
		   
		ObjectMapper mapper = new ObjectMapper();
		List<Patch> patchList = getJsonPatch().getPatch();
		Note updated =  helper.applyPatch(getNote(), mapper.writeValueAsString(patchList) );
		assertTrue(updated.getUpdatedBy().equalsIgnoreCase("Dmitry"));
		assertTrue(updated.getNote() != null);
   }
   
	@Test
	public void  toJsonTest()	throws RuntimeException, JsonProcessingException{
		String str = helper.toJson(getNote());
		assertTrue(str != null);
		assertTrue(str.contains("note"));
	}


	@Test
	public void fromJson() throws RuntimeException, JsonProcessingException{
		
		Note note = helper.fromJson(asJsonString(getNote()), Note.class);
		assertTrue(note != null);
		assertTrue(note.getCategory() != null);
	}
	
    public static String asJsonString(final Note notes) {
    	try {
    		return new ObjectMapper().writeValueAsString(notes);
    	} catch (Exception e) {
    		throw new RuntimeException(e);
    	}
    }
    
    private Note getNote() {
    	Note attachment = new Note();
		attachment.setCategory("category");
		attachment.setCreatedBy("DMITRY");
		attachment.setCreationDate("08/22/21 21:21:21");
		attachment.setDeleted(false);
		attachment.setDomainId("500011");
		attachment.setId("id");
		attachment.setNote("note");
		attachment.setPriority("HIGH");
		attachment.setScope(Scope.internal.toString());
		attachment.setStatus("active");
		attachment.setTenantId("tenantId");
		attachment.setTitle("title");
		attachment.setUpdateDate("08/22/22 23:23:23");
		attachment.setUpdatedBy("updatedBy");
		attachment.setValidDateBy("08/30/23 01:01:01");
    	return attachment;
    }	
    
	private Optional<MultipartFile[]> getOptionalFiles() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] fileso = {file};
	    Optional<MultipartFile[]> files = Optional.of(fileso);
	    return files;
	}
	private JsonPatch getJsonPatch() {
    	JsonPatch jp = new JsonPatch();
    	//Attachment atts = new Attachment("add", (AWS_PATH1+System.getenv("spring.profiles.active")+AWS_PATH2)+"attachments", "test1.txt");
    	Patch patch = new Patch("replace", "/note", "new note value");
    	List<Patch> plist = new ArrayList<>();
    	plist.add(patch);
    	patch = new Patch("replace", "/updatedBy", "Dmitry");
    	plist.add(patch);
    	List<Attachment> alist = new ArrayList<>();
    	//alist.add(atts);
	   	jp.setAttachments(alist);
	   	jp.setPatch(plist);
	   	return jp;
	}
}
