package com.ge.ren.attachments.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.ren.notes.exception.ApiException;

@SpringBootTest (classes = {HttpUtils.class}) 
@TestInstance(Lifecycle.PER_CLASS)
@RunWith(SpringRunner.class)
public class HttpUtilsTest  extends HttpUtils{

	
	@MockBean
	HttpURLConnection connection;
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
	private static final String URL = "https://renewables-uai3031357-attachments-dev.s3.us-east-1.amazonaws.com/attachments/siteNotes/2022-02-10/16445107452791791931615-test-image.png";
	private static final String httpMethod = "GET";
	
	private static final HttpUtils inst = new HttpUtils();
    public static HttpUtils getInstance() {
        return inst;
    }
	@SuppressWarnings("unused")
	@BeforeAll
	public void setup() throws MalformedURLException {
		HttpUtils httpUtils = new HttpUtils();
	    //when(connection.invokeHttpRequest( anyString(), any())).thenReturn(list);   //doReturn(expected).when(connection).getResponseCode();
	}
	@SuppressWarnings("static-access")
//	@Test
	public void invokeHttpRequestTest() throws IOException {
		//AWS4SignerBase abstractCls = Mockito.mock(AWS4SignerBase.class,	Mockito.RETURNS_MOCKS); //.CALLS_REAL_METHODS
		Map<String, String> headers = new HashMap<>();
		String hostHeader = new URL(URL).getHost();
        headers.put("Host", hostHeader);
        HttpURLConnection mockConnection = mock(HttpURLConnection.class);
        InputStream mockInputStream = new ByteArrayInputStream("response".getBytes());
        when(mockConnection.getInputStream()).thenReturn(mockInputStream);

        URL endpointUrl = new URL(URL);
        ByteArrayOutputStream mockOutputStream = new ByteArrayOutputStream();
        when(mockConnection.getOutputStream()).thenReturn(mockOutputStream);
        Assertions.assertThrows(ApiException.class, () -> {   HttpUtils.invokeHttpRequest(
					    endpointUrl, 
						"GET", 
		                headers,
		                "UNSIGNED-PAYLOAD");});
				

	}
	
	@SuppressWarnings("static-access")
	@Test
	public void createHttpConnectionTest() throws MalformedURLException{
		HttpURLConnection connection = getInstance().createHttpConnection(new URL(URL), httpMethod, new HashMap<String, String> ());
		assertFalse(connection.getContentLength() > 0);

		try {
			Assertions.assertThrows(org.opentest4j.AssertionFailedError.class, () -> {
				//HttpURLConnection connection1 = HttpUtils.createHttpConnection(new URL(URL), httpMethod, null);
				assertTrue(connection.getContentLength() > 0);
			});
		}catch(NullPointerException e) {
			thrown.expect(NullPointerException.class);
		}
		
		//List<Attachment> processUpdateLinks(String id, List<Attachment> attachments, Class<T> entityClass) 
		//when(service.processUpdateLinks(anyString(), any(), any())).thenThrow(new ApiException("500", "Error"));
		Assertions.assertThrows(ApiException.class, () -> {
			@SuppressWarnings("unused")
			HttpURLConnection connection1 = HttpUtils.createHttpConnection(null, null, null);
		});
		
	}
	
	@SuppressWarnings("static-access")
	@Test
	public void executeHttpConnectionTest() throws IOException {
		HttpURLConnection mockConnection = mock(HttpURLConnection.class);
        InputStream mockInputStream = new ByteArrayInputStream("response".getBytes());
        when(mockConnection.getInputStream()).thenReturn(mockInputStream);

        // Call the method
        String response = HttpUtils.executeHttpRequest(mockConnection);

        // Verify the results
        assertEquals("response\r", response);
        verify(mockConnection).getInputStream();
        verify(mockConnection).disconnect();
	}
		
	@Test
	public void urlEncodeTest() {
		Assertions.assertThrows(java.lang.NullPointerException.class, () -> {
			HttpUtils.urlEncode(null, false);
		});
		
		String result = HttpUtils.urlEncode(URL, false);
		assertFalse(result.isBlank());
	}
}
