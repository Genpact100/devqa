package com.ge.ren.notes.config;

import com.xebialabs.restito.server.StubServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ComponentScan(basePackages={"com.ge.ren.notes"})
//@ImportResource("classpath:spring/spring-main.xml")
public class CucumberTestConfig {

	/*
	 * @Autowired public StubServer superService;
	 * 
	 * @Bean StubServer superService() { return new StubServer(9090); }
	 */
}
