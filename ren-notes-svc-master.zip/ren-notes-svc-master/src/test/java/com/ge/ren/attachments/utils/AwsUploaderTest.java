package com.ge.ren.attachments.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;
import org.assertj.core.util.Arrays;
import org.hamcrest.Matcher;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.verification.VerificationMode;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.VerificationModeFactory;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SDKGlobalConfiguration;
import com.amazonaws.auth.AnonymousAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.GetNotes;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.PatchNote;
import com.ge.ren.notes.utils.DateFormatMS;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import static com.ge.ren.notes.constants.Constants.*;

import io.findify.s3mock.S3Mock;

@Slf4j
//@ActiveProfiles("dev")
@TestInstance(Lifecycle.PER_CLASS)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {AwsUploader.class}, properties = {"bucket=attachments","descriptionSize=20", "titleSize=10", "storageType=s3aws", "searchLimit=1",  "region=us-east-1"})  //(classes = FileUploader.class)
@TestPropertySource(locations = "/application.properties")
@AutoConfigureMockMvc
public class AwsUploaderTest {
	
    
    @Autowired
    private MockMvc mockMvc;
    @Rule
    public ExpectedException thrown = ExpectedException.none();
	
    //@Autowired
    //AttachmentUtilHelper validateUtil; // = new AttachmentUtilHelper();

    @MockBean
    Autils utils;
    
    //@MockBean
    //AwsUploader awsUploader;
    
    @MockBean
    FileUploader fileUploader;
 
    @MockBean
    AmazonS3 s3b;

    @Autowired
    AwsUploader uploader;
    
    @Value("${storageType}")
	private String storageType;
    
    @Value("${bucket}")
	private String bucket;
    
    @Value("${region}")
    private String region;
	
   
    @Value("${AWS_S3_KMS_KEY:TODO_ADD_KMS_KEY_TO_PROPS}")
    private String kmsKey;

   String json = "{ \"domainId\": \"500023\", \"description\": \"Site description\", \"title\": \"Site tile\", \"creationDate\": \"07/30/21 01:01:01\"}";

	@BeforeAll
    public void setup() {
		StringBuilder nt = new StringBuilder("aaa");

		for(int i=0; i<2505; i++ ) {
			nt.append("1");
		}
        MockitoAnnotations.initMocks(this);
        AttachmentUtilHelper utilHelper = new AttachmentUtilHelper();
        
    }
	int nameSize=10;
	int	titleSize=5;
    @After
    public void tearDown() {}
    
    private static ByteBuffer getRandomByteBuffer(int size) throws IOException {
        byte[] b = new byte[size];
        new Random().nextBytes(b);
        return ByteBuffer.wrap(b);
    }
    
  
    //@Test
    public void bucketSummaryTest() throws IOException {
    	//AmazonS3 s3b = Mockito.mock(AmazonS3ClientBuilder.class).build(); //.withRegion(REGION)
	    //AmazonS3 s3b = AmazonS3ClientBuilder.standard().withRegion(REGION).build();
		//ObjectListing objectListing = s3b.listObjects(bucket);
		//List<S3ObjectSummary>  sum = objectListing.getObjectSummaries();
	    //AwsUploader uploader = Mockito.mock(AwsUploader.class);
		//Mockito.doNothing().when(awsUploader).bucketSummary(any());
		//wsUploader.bucketSummary(null);
		
    }    


    @Test
    public void removeS3ObjectTest() {

    	AmazonS3Client s3b = new AmazonS3Client(new AnonymousAWSCredentials());
    	s3b.setEndpoint("http://127.0.0.1:8001");
    	Assertions.assertThrows(com.ge.ren.notes.exception.ApiException.class, () -> {
    		boolean remove = uploader.removeS3Object("/tmp/s3/test.txt");
    		assertFalse(remove);
    	});
    	
	    //Mockito.when(awsUploader.removeS3Object(anyString())).thenReturn(true);
	    //boolean res = awsUploader.removeS3Object("/tmp/s3/test.txt");
	    //assertTrue(res);
	    
        //Mockito.doThrow(AmazonServiceException.class).when(awsUploader).removeS3Object(any());
    	//Assertions.assertThrows(AmazonServiceException.class, () -> {
    	//	uploader.removeS3Object("/tmp/s3/test.txt");
    	//});
    	
    	//when(mongoTemplate.count(any(), anyString())).thenReturn(new Long(1));
    	//when(awsUploader.removeS3Object(anyString())).thenThrow(AmazonServiceException());
    	//Assertions.assertThrows(AmazonServiceException.class, () -> {
    	//	uploader.removeS3Object("/tmp/s3/test.txt");
    	//});
    	
    }
    
    //
    private Throwable AmazonServiceException() {
		// TODO Auto-generated method stub
		return null;
	}

	//@org.junit.jupiter.api.Test //@Test //   (expected = ResourceNotValid.class)
	public void ResourceNoteValidExceptionTest() {
		log.info("Test ResourceNoteValidExceptionTest");
       // Mockito.doThrow(new ResourceNotValid("title")).doReturn(new Notes()).when(mutils).validateForSpecChars("$", "title");
        //Mockito.doThrow(new ResourceNotValid("note")).when(mutils).validateForSpecChars("$", "title");
	}
	
    @org.junit.jupiter.api.Test //@Test //   (expected = AttributeNotFound.class)
	public void AttributeNotFoundExceptionTest() {
		log.info("Test validateDateBy(String date, String name)");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		AttachmentUtilHelper.validateDateBy("date", "name");
    	});
        	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		AttachmentUtilHelper.validateDateBy("01/01/21", "date short");
        	});
    		
    	AttachmentUtilHelper.validateDateBy("01/01/39 22:22:22", "date full");

		//Mockito.doThrow(new AttributeNotFound("title")).when(mutils).validateForSpecChars("$", "title");
	}


    @org.junit.jupiter.api.Test //@Test //  (expected = JsonMappingException.class)
	public void JsonMappingExceptionTest(){
		log.info("Test JsonParseException");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
			AttachmentUtilHelper.validateForSpecChars("{[#]}", "post");
		});
		// Validate for script
		Assertions.assertThrows(ResourceNotValid.class, () -> {
			AttachmentUtilHelper.validateForSpecChars("#javasscript", "patch");
		});

		//Mockito.doThrow(new JsonMappingException("json")).when(mutils).validateJsonString("{{{");
	}
	
    @org.junit.jupiter.api.Test //@Test //  (expected = AttributeNotFound.class)
	public void JsonProcessingExceptionTest() {
		log.info("Test JsonParsingException");
		Assertions.assertThrows(JsonParseException.class, () -> {
			AttachmentUtilHelper.validateJsonString("dfghdafrgd");
		});
		Assertions.assertThrows(JsonParseException.class, () -> {
			AttachmentUtilHelper.validateJsonString("zcxfbzf");
		});
		//Mockito.doThrow(new AttributeNotFound("msg")).when(mutils).validateJsonString("{{{");
	}
    
	private MultipartFile[] getMultipartFiles() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] fileso = {file};
	    Optional<MultipartFile[]> files = Optional.of(fileso);
	    return fileso;
	}
}
