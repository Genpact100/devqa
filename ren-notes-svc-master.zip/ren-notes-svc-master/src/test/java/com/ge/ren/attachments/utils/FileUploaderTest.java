package com.ge.ren.attachments.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.junit.After;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;


import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.utils.DateFormatMS;


import lombok.extern.slf4j.Slf4j;

@Slf4j
//@ActiveProfiles("dev")
@TestInstance(Lifecycle.PER_CLASS)
//@RunWith(SpringRunner.class)
@SpringBootTest  (classes = {FileUploader.class})
@TestPropertySource(locations = "/application.properties")
//@AutoConfigureMockMvc
public class FileUploaderTest {
	
    @Rule
    public ExpectedException thrown = ExpectedException.none();
	
	String json = null;
	StringBuilder nt = new StringBuilder("aaa");


    @MockBean
    Autils utils;

    @MockBean
    DateFormatMS dateFormat;
    
    @Autowired
    FileUploader fileUploader;

    @Value("${storage.type:s3aws}")
	private String storageType;
    
    @Value("${aws.bucket.prefix:TODO_add_to_properties}")
	private String bucket;
    
    @Value("${aws.region:us-east-1}")
    private String region;
	
    @Value("${aws.folder:attachments}")
    private String folder;
    
    @Value("${AWS_S3_KMS_KEY:TODO_ADD_KMS_KEY_TO_PROPS}")
    private String kmsKey;

    @Value("${spring.profiles.active}")
    String activeProfile;

    @Value("${aws.access.key}")
    private String awsAccessKey;
    @Value("${aws.secret.key}")
    private String awsSecretKey; 
  
	@BeforeAll
    public void setup() throws JsonMappingException, JsonProcessingException {
		for(int i=0; i<2505; i++ ) {
			nt.append("1");
		}
        MockitoAnnotations.initMocks(this);
        //AttachmentUtilHelper utils = Mockito.mock(AttachmentUtilHelper.class);
        json = "{ \"domainId\": \"500023\", \"note\": \"Si teote\", \"title\": \"Sit etle\", \"priority\": \"MEDIUM\",  \"category\": \"category\", \"scope\": \"internal\", \"status\": \"active\", \"validDateBy\": \"07/30/21 01:01:01\"}";
        
		when(utils.compileBucketPath(anyString())).thenReturn("case");
		Mockito.when(utils.validatePathExists(anyString())).thenReturn(true);
		Mockito.doNothing().when(utils).validateForFileType(any());
		when(utils.getErrorDescription(anyString(), anyInt(), anyString(), anyString(), anyString())).thenReturn("aws");
		when(dateFormat.getFileNameDateString()).thenReturn("01-01-22");
    }
	int nameSize=10;
	int	titleSize=5;
    @After
    public void tearDown() {}
    
    private static ByteBuffer getRandomByteBuffer(int size) throws IOException {
        byte[] b = new byte[size];
        new Random().nextBytes(b);
        return ByteBuffer.wrap(b);
    }
    

    @Test
    public void uploadFileAttachmentTest() throws IOException {
    	String fileName = "sitaNotes";  
        //S3Client s3 = S3Client.builder().region(software.amazon.awssdk.regions.Region.US_EAST_1).build();
        log.info("test file uploader");
        try {
        	//MultipartFile multipartFile = new MockMultipartFile("test1.txt", "Hello World".getBytes());
        	
        	List<AttachmentData> list = fileUploader.uploadFiles("case", null);
        	assertTrue(list.isEmpty());
        	
        	MultipartFile multipartFile = new MockMultipartFile("test1.txt", new byte[0]);
        	MultipartFile[] mfile = getMultipartFiles();
        	MultipartFile[] mfiles = {multipartFile}; 
	        list = fileUploader.uploadFiles("case", mfiles );
	        assertTrue(list.isEmpty());
	        
        	list = fileUploader.uploadFiles("case", getMultipartFiles());
        	assertNotNull(list);
        	FileUploader uploader = Mockito.mock(FileUploader.class);
        	Mockito.doThrow(com.ge.ren.notes.exception.ApiException.class).when(uploader).uploadFiles("case", null);
        	
    		Mockito.doAnswer(invocation -> {
    	        Object arg0 = invocation.getArgument(0);
    	        Object arg1 = invocation.getArgument(1);
    	        
    	        assertEquals("case", arg0);
    	        assertEquals(null, arg1);
    			System.out.println(" Case Argument = " + invocation.getArgument(0));
    			assertTrue("case".equals(invocation.getArgument(0)));
    			return null;
    		}).when(uploader).uploadFiles(anyString(), any());
    		
    		//Mockito.doThrow().when(uploader).uploadFiles("case", any(null));
    		 
    		uploader.uploadFiles("case", null);
    		
        }catch(Exception e) {
        	log.error("{}",e);
        }
    }

    @Test
    public void uploadFileTest() throws IOException {
    	AttachmentData ada =new AttachmentData();
    	ada.setFile("file");
    	AttachmentData  ad = fileUploader.uploadFile(new AttachmentData(), "domainName");
    	assertTrue(ad.toString().contains("file"));
    }

  
    @Test
	public void uploadFileByteTest(){
    	byte[] contents = new String("text").getBytes();
    	fileUploader.uploadFile("bucket", "fileName", contents);
    	assertTrue(true);
    }
  
    @Test
    public void uploadFileBinaryTest() {
    	fileUploader.uploadFile("bucket", "fileName", "binary");
    	assertTrue(true);
    }


	
    //@org.junit.jupiter.api.Test //@Test //   (expected = ResourceNotValid.class)
	public void ResourceNoteValidExceptionTest() {
		log.info("Test ResourceNoteValidExceptionTest");
       // Mockito.doThrow(new ResourceNotValid("title")).doReturn(new Notes()).when(mutils).validateForSpecChars("$", "title");
        //Mockito.doThrow(new ResourceNotValid("note")).when(mutils).validateForSpecChars("$", "title");
	}
	
    @Test //@Test //   (expected = AttributeNotFound.class)
	public void AttributeNotFoundExceptionTest() {
		log.info("Test validateDateBy(String date, String name)");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		AttachmentUtilHelper.validateDateBy("date", "name");
    	});
        	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		AttachmentUtilHelper.validateDateBy("01/01/21", "date short");
        	});
    		
    	AttachmentUtilHelper.validateDateBy("01/01/39 22:22:22", "date full");

		//Mockito.doThrow(new AttributeNotFound("title")).when(mutils).validateForSpecChars("$", "title");
	}


    @Test //@Test //  (expected = JsonMappingException.class)
	public void JsonMappingExceptionTest(){
		log.info("Test JsonParseException");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
			AttachmentUtilHelper.validateForSpecChars("{[#]}", "post");
		});
		// Validate for script
		Assertions.assertThrows(ResourceNotValid.class, () -> {
			AttachmentUtilHelper.validateForSpecChars("#javasscript", "patch");
		});

		//Mockito.doThrow(new JsonMappingException("json")).when(mutils).validateJsonString("{{{");
	}
	
    @Test //@Test //  (expected = AttributeNotFound.class)
	public void JsonProcessingExceptionTest() {
		log.info("Test JsonParsingException");
		Assertions.assertThrows(JsonParseException.class, () -> {
			AttachmentUtilHelper.validateJsonString("dfghdafrgd");
		});
		Assertions.assertThrows(JsonParseException.class, () -> {
			AttachmentUtilHelper.validateJsonString("zcxfbzf");
		});
		//Mockito.doThrow(new AttributeNotFound("msg")).when(mutils).validateJsonString("{{{");
	}
    
	private MultipartFile[] getMultipartFiles() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] fileso = {file};
	    Optional<MultipartFile[]> files = Optional.of(fileso);
	    return fileso;
	}
	
	/*    public void validatePatchRequestTest() throws AttributeNotFound, IOException{
    	for(int i=0; i<2505; i++ ) {nt.append("1");}

		
		try {
			notes.setDomainId("");
			notes.setNote(null);
			AttachmentUtilHelper.validatePostRequest(notes, "patch"); 
		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);
		}

		try {// domain missing
			notes.setDomainId("domainId");
			AttachmentUtilHelper.validatePostRequest(notes, "patch");
			notes.setDomainId("");
			AttachmentUtilHelper.validatePostRequest(notes, "patch"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		} catch(AttributeNotFound e) {
	        thrown.expect(AttributeNotFound.class);
		} catch(Exception e) {
			thrown.expect(Exception.class);
		}
		try {
			// title missing
			notes.setTitle("");
			AttachmentUtilHelper.validatePostRequest(notes, "patch");
		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);

		}
		try {
			notes.setTitle("title");
			notes.setNote("note");
		}catch(ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
			//throw new  ResourceNotValid("spec Chars included");
		}
			
		AttachmentUtilHelper.validatePostRequest(notes, "patch");
		try {
			notes.setNote("note#");
			AttachmentUtilHelper.validateForSpecChars(notes.getNote(), "note");
			AttachmentUtilHelper.validatePostRequest(notes, "patch");
		}catch(ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
			//throw new  ResourceNotValid("spec Chars included");
		}
		
		try {
			notes.setNote(" ");
			AttachmentUtilHelper.validatePostRequest(notes, "patch"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}


		try {
			notes.setNote(nt.toString());
			AttachmentUtilHelper.validatePostRequest(notes, "patch"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		notes.setNote("note");
        notes.setTitle(nt.toString());
		try {
			AttachmentUtilHelper.validatePostRequest(notes, "patch"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		notes.setTitle("#");
        try {
			AttachmentUtilHelper.validateForSpecChars(notes.getNote(), "title");
			AttachmentUtilHelper.validatePostRequest(notes, "patch");
        } catch(ResourceNotValid e) {
	        thrown.expect(ResourceNotValid.class);
        }
        try {
        	AttachmentUtilHelper.validatePostRequest(notes, "patch");
            notes.setTitle(nt.toString());
        	AttachmentUtilHelper.validatePostRequest(notes, "patch");
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setTitle("title");
		notes.setScope("internal");
		try {
			AttachmentUtilHelper.validatePostRequest(notes, "patch");
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }

        notes.setStatus("");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		AttachmentUtilHelper.validateStatus(notes);
    	});        
        notes.setStatus("inactive2");
        try {
            AttachmentUtilHelper.validatePostRequest(notes, "patch");        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        

        try {
            notes.setStatus("inactive");
            AttachmentUtilHelper.validateStatus(notes);
            notes.setStatus("");
            AttachmentUtilHelper.validateStatus(notes);
            notes.setScope("#nactive2");
            AttachmentUtilHelper.validatePostRequest(notes, "patch");        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setScope("internal");
        notes.setValidDateBy("12/12/15 11:11:11");
        try {
            AttachmentUtilHelper.validatePostRequest(notes, "patch");        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setValidDateBy("12/12/25 11:11:11");
        notes.setStatus("active");
        AttachmentUtilHelper.validatePostRequest(notes, "patch");
        
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		AttachmentUtilHelper.validateForSpecChars("$", "note");
    	});
        Note note = new Note();
        note.setPriority("p");
        try {
        	AttachmentUtilHelper.validatePriority(note);
        }catch(ResourceNotValid e) {
            Assertions.assertThrows(ResourceNotValid.class, () -> {
            	AttachmentUtilHelper.validatePriority(note);
    		});
        }
        note.setPriority("HIGH");
        AttachmentUtilHelper.validatePriority(note);
        note.setPriority("MEDIUM");
        AttachmentUtilHelper.validatePriority(note);
        note.setPriority("LOW");
        AttachmentUtilHelper.validatePriority(note);
        
	}*/
}
