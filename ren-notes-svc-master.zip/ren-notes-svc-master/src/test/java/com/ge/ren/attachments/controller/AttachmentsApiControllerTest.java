package com.ge.ren.attachments.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static com.ge.ren.notes.constants.Constants.POST;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.apache.commons.collections4.map.MultiValueMap;
import org.junit.Rule;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.mockito.ArgumentMatchers.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.amazonaws.util.IOUtils;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.Attachments;
import com.ge.ren.attachments.model.PostAttachment;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.model.patch.Patch;
import com.ge.ren.attachments.service.impl.AttachmentServiceImpl;
import com.ge.ren.attachments.utils.Autils;
import com.ge.ren.common.keycloak.exception.TokenVerifyException;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.constants.Scope;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.utils.ApiUtil;


import lombok.extern.slf4j.Slf4j;
@Slf4j
@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest (classes = AttachementApiController.class, properties = {"bucket=attachments","descriptionSize=20", "titleSize=10", "storageType=fyleSystem", "searchLimit=1", "pageSizeDef=1", "EMPTY_JSON_RESPONSE={}", "pageNum=1"}) 
@TestPropertySource(locations = "/application.properties") 
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@EnableWebMvc
public class AttachmentsApiControllerTest extends AbstractTest{
    private String DOMAIN_SERVICE = "/common/v1/attachments";
    
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
    @Autowired
    MockMvc mockMvc;
    
	@MockBean
    AttachmentServiceImpl service;

    @MockBean
	RequestInterceptor requestInterceptor;
    @MockBean
    ApiUtil apiUtil;

    @MockBean
    Autils utils;

    @Value("${searchLimit}")
    int searchLimit = 1;
    @Value("${pageSizeDef}")
    int pageSizeDef = 1;
    
    @Value("${pageNum}")
    int pageNum = 1;
    
    @Value("${EMPTY_JSON_RESPONSE}")
    String EMPTY_JSON_RESPONSE = "{}";

	String tenantId = "tenantId";
    private int pageIdx = 0;
    private int pageSize = 10;
	private String uri = DOMAIN_SERVICE;
	
    @org.junit.jupiter.api.BeforeEach
    public void setup() throws TokenVerifyException, JsonParseException, IOException {
		super.setUp();
		MockitoAnnotations.initMocks(this);

        when(requestInterceptor.getTenantId()).thenReturn("tenantid");
        when(requestInterceptor.getUsername()).thenReturn("name");

        when(apiUtil.retrieveTenantId(requestInterceptor)).thenReturn("tenantId");
        when(apiUtil.retrieveUserName(requestInterceptor)).thenReturn("tenantName");

        when( utils.validateForFileSize( any())).thenReturn(true);
 		when( utils.getDescriptionSizeCheck(any(), anyString())).thenReturn(true);
 		when( utils.getTitleSizeCheck(any(), anyString())).thenReturn(true);
 		ResponseEntity r = new ResponseEntity(asJsonString(getAttachment()), HttpStatus.ACCEPTED);
 		when(service.processPostRequest(any(NotesRequest.class), any())).thenReturn(r); 
 		r= new ResponseEntity(asJsonString(getAttachment()), HttpStatus.OK);
 		when(service.processPatchRequest(any(NotesRequest.class), any(), any())).thenReturn(r); 
 		
 		//
 		
 		when(service.processGetRequest(anyString(), anyString(), anyInt(), anyInt(), anyString(), anyString())).thenReturn("{}"); 		
	}
	
	// Test POST    
    @Test
	public void createPostAttachmentTest() throws Exception {
       log.info("POST Attachment Controller Test start...  " );
 	   String uri = DOMAIN_SERVICE;
 	   String inputJson = mapToJson(getAttachment());
 	   inputJson = "";
 	   ResponseEntity r = new ResponseEntity(mapToJson(getAttachment()), HttpStatus.ACCEPTED);
 	   
 	   when(service.processPostRequest(any(NotesRequest.class), any())).thenReturn(r);  

    	MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
    	MockMultipartFile json = new MockMultipartFile("json", "", "application/json", mapToJson(getPA()).getBytes());
 
    	MvcResult  mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri)
                //.file(file)
                .file(json)
  			   //
  	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
  	           .andExpect(status().is(202)).andReturn();
  	   assertTrue(mvcResult.getResponse().getStatus() >= 200);
  	   
  	   when( utils.validateForFileSize( any())).thenReturn(true);
  	   
	   mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post("/common/v1/attachments")
	  			.accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE)
	  			.contentType("application/json"))
		  		.andExpect(MockMvcResultMatchers.status().is2xxSuccessful());
	  	
	   assertTrue(mvcResult.getResponse().getStatus() >= 200);	   
 	   
 	   assertTrue(mvcResult.getResponse().getStatus() >= 200);
	   org.springframework.util.MultiValueMap<String, MockMultipartFile> params = new  LinkedMultiValueMap<>();
	   params.add("file", file);
	   params.add("json", json);
	   
	   //Validate for Attached Files and throw:
 	   // Throw Resource Not Valid big FILES
	   when( utils.validateForFileSize( any())).thenReturn(false);
	   
		Assertions.assertThrows(org.springframework.web.util.NestedServletException.class, () -> {
			try {
				this.mockMvc.perform(MockMvcRequestBuilders.multipart(DOMAIN_SERVICE)
		               .file(json)
		 			   .contentType(MediaType.APPLICATION_JSON)
 						.header("Allow", "POST")
		 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"));
			}catch(ResourceNotValid e) {
				throw new ResourceNotValid("");
			}
		}); 
    }
    
    
    //GET
    @Test
	public void processGetAttachmentTest() throws Exception{
		log.info("GET method Attachment Controller Test start...  " );

		Attachment  attachment = new Attachment(); 
		assertTrue(null != attachment);
		attachment =getAttachment();		
        
        log.info(">>> GET method Mock Context -> {} ", mockMvc.getDispatcherServlet().getWebApplicationContext().getBeanDefinitionNames());
        
        
        when(service.processGetRequest(anyString(), anyString(), anyInt(), anyInt(), anyString(), anyString())).thenReturn(attachment.toString());  
 
        when(requestInterceptor.getTenantId()).thenReturn("tenantid");
        when(requestInterceptor.getUsername()).thenReturn("name");

        when(apiUtil.retrieveTenantId(requestInterceptor)).thenReturn("tenantId");
        when(apiUtil.retrieveUserName(requestInterceptor)).thenReturn("tenantName");

        when( utils.validateForFileSize( any())).thenReturn(true);
 		when( utils.getDescriptionSizeCheck(any(), anyString())).thenReturn(true);
 		when( utils.getTitleSizeCheck(any(), anyString())).thenReturn(true);

        //test GET

		  MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.delete(uri+"/{id}", "1")
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(MockMvcResultMatchers.status().isOk())
            .andDo(MockMvcResultHandlers.print())
            .andReturn();
		  
		  try { 
			  when(service.processGetRequest(anyString(), anyString(), anyInt(), anyInt(), anyString(), anyString())).thenReturn(asJsonString(attachment));
		        

			  Optional<Integer> pageIdx = Optional.empty();
		      Optional<Integer> pageSize = Optional.empty();
		      when(service.processGetRequest(any(NotesRequest.class))).thenReturn(asJsonString(attachment));		        
			  	mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get("/common/v1/attachments/get")
		                .queryParam("domainName", "case")
		                .queryParam("filter", "id,title,note")
		                .queryParam("query", "priority==MEDIUM;category==category")
		                .queryParam("pageIdx", "1")
		                .queryParam("pageSize", "1")
			  			.contentType("application/json")
			  			.accept(MediaType.APPLICATION_JSON))
				  		.andExpect(MockMvcResultMatchers.status().is2xxSuccessful());
				 
			  
				MvcResult res = mockMvc.perform(MockMvcRequestBuilders.get(uri))
							.andDo(MockMvcResultHandlers.print()).andExpect(status().is2xxSuccessful()).andReturn();
		        assertTrue(res.getResponse().getStatus() >= 200);
	 				  
		        // validate Optionals
		        // Cover NoteRequest Optionals
		        mockMvc.perform(get(DOMAIN_SERVICE)
		                .queryParam("domainName", "case")
		                .queryParam("filter", "id,title,note")
		                .queryParam("query", "priority==MEDIUM;category==category")
		                .queryParam("pageIdx", "1")
		                .queryParam("pageSize", "10")
		                .contentType(MediaType.APPLICATION_JSON))
		                .andExpect(status().isOk());	                
		       
		        res = mockMvc.perform(get(DOMAIN_SERVICE  + "/{id}", "1")
		        		.header("tenantId",tenantId )
		        		.queryParam("filter", "id,note,title")
		        		.queryParam("pageIdx", "1")
		        		.queryParam("pageSize", "1")
		        		.queryParam("domainId", "id")
		        		.queryParam("domainName", "case")
		                .contentType(MediaType.APPLICATION_JSON))

		                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();

		                
		        assertTrue(res.getResponse().getStatus() >= 200);
	
		        
		     // Validate 204

		     when(service.processGetRequest(any(NotesRequest.class))).thenReturn("");

		        res = mockMvc.perform(get(DOMAIN_SERVICE  + "/{id}", "1").accept(MediaType.APPLICATION_JSON).content("{}")).andDo(MockMvcResultHandlers.print())
		     		   .andExpect(MockMvcResultMatchers.status().is(204)).andReturn();
		        assertTrue(res.getResponse().getStatus() >= 200);

		        
			    // test GET by ID
		         assertTrue(res.getResponse().getStatus() >= 200);
	
	
			   
			     // 204 check
		         // Validate 204
		         when(service.processGetRequest(any(NotesRequest.class))).thenReturn("{}");
		         res = mockMvc.perform(get(DOMAIN_SERVICE  + "/{id}", "1").accept(MediaType.APPLICATION_JSON).content("{}")).andDo(MockMvcResultHandlers.print())
			     		   .andExpect(MockMvcResultMatchers.status().is(204)).andReturn();
		         assertTrue(res.getResponse().getStatus() >= 200);
		        
		  }catch(NullPointerException e) {
			 thrown.expect(NullPointerException.class);
		  }

      System.out.println("get Notes Controller Test done.  " );
	}
	
	
	//PATCH
	@Test
	public void patchNoteTest() throws Exception {
        log.info(">>> PATCH  Mock Context -> ", mockMvc.getDispatcherServlet().getWebApplicationContext().getBeanDefinitionNames());
        
	   String uri = DOMAIN_SERVICE; String response ="";
	   	MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
    	MockMultipartFile json = new MockMultipartFile("json", "", "application/json", mapToJson(getAttachment()).getBytes());

	     MockHttpServletRequestBuilder builder =
	              MockMvcRequestBuilders.patch(uri+"/{id}", "1")
	              						.header("Allow", "PATCH")
	                                    .contentType(MediaType.APPLICATION_JSON_VALUE)
	                                    .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json")
	                                    .characterEncoding("UTF-8")
	                                    .content(getAttachmentJson());
	     MvcResult mvcResult =  mockMvc.perform(builder)
	                  .andExpect(MockMvcResultMatchers.status().is2xxSuccessful())

	                  .andDo(MockMvcResultHandlers.print()).andReturn();
	      
	   assertEquals(200, mvcResult.getResponse().getStatus());
	   
	   //Validate for Attached Files and throw:
	   when( utils.validateForFileSize( any())).thenReturn(false);
	   
	   Assertions.assertThrows(org.springframework.web.util.NestedServletException.class, () -> {
			mockMvc.perform(MockMvcRequestBuilders.multipart(uri)
	               .file(file)
	               .file(json)
	               .header("Allow", "PATCH")
	 			   .contentType(MediaType.APPLICATION_JSON)
	 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"));
	   });
		
	   // Validate file size = true	 ValidationAnnotationUtils
  	   when( utils.validateForFileSize( any())).thenReturn(true);
  	   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri)
            .file(json)
	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
	           .andExpect(status().is(202)).andReturn();
	   assertTrue(mvcResult.getResponse().getStatus() >= 200);	   


	   System.out.println("done patch test ..");

	}

   @Test
   public void processDeleteNoteTest() throws Exception {
	   
       log.info(">>> DELETE  Mock Context -> ", mockMvc.getDispatcherServlet().getWebApplicationContext());
       
	      String uri = DOMAIN_SERVICE ;
	      when(apiUtil.retrieveTenantId(requestInterceptor)).thenReturn("tenantId");
	      
	  MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.delete(uri+"/{id}", "1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(MockMvcResultHandlers.print())
                .andReturn();

	  assertTrue( mvcResult.getResponse().getStatus() == 200);
   }
	  

   //helpers
   
   private Note getNote() {
   	Note attachment = new Note();
		attachment = new Note(); 
		attachment.setCategory("category");
		attachment.setCreatedBy("DMITRY");
		attachment.setCreationDate("08/22/21 21:21:21");
		attachment.setDeleted(false);
		attachment.setDomainId("500011");
		attachment.setId("id");
		attachment.setNote("note");
		attachment.setPriority("HIGH");
		attachment.setScope(Scope.internal.toString());
		attachment.setStatus("active");
		attachment.setTenantId("tenantId");
		attachment.setTitle("title");
		attachment.setUpdateDate("08/22/22 23:23:23");
		attachment.setUpdatedBy("updatedBy");
		attachment.setValidDateBy("08/30/23 01:01:01");
		List<AttachmentData> attachments = new ArrayList<>();
		AttachmentData ad = new AttachmentData("attachments/test1.txt", "text/txt", "test1.txt");
		attachments.add(ad);
		attachment.setAttachments(attachments);
   	return attachment;
   }	
	private JsonPatch getJsonPatch() {
    	JsonPatch jp = new JsonPatch();
    	
    	Patch patch = new Patch("add", "note", "new note value");
    	List<Patch> plist = new ArrayList<>();
    	plist.add(patch);
    	patch = new Patch("add", "validDateBy", "08/22/25 22:22:22");
    	plist.add(patch);
    	List<com.ge.ren.attachments.model.patch.Attachment> alist = new ArrayList<>();
    	
    	jp.setAttachments(alist);
    	jp.setPatch(plist);
    	return jp;
	}
	
	private Optional<MultipartFile[]> createMultipartFileOptional() throws IOException {
		File file = new File("src/main/resources/attachments/test-image.png");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file",
		            file.getName(), "text/plain", IOUtils.toByteArray(input));
		MultipartFile[] mf = {multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, 
				multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile,
				multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile};
		Optional<MultipartFile[]> mfo = Optional.of(mf);
		return mfo;  
	}	
    private static String asJsonString(final Attachment attachment) {
    	try {
    		return new ObjectMapper().writeValueAsString(attachment);
    	} catch (Exception e) {
    		throw new RuntimeException(e);
    	}
    }
    
	private String  getAttachmentJson(){
		String noteJson = "{" + 
        		"\"domainId\": \"500023\"," + 
        		"\"domainName\": \"case\"," + 
        		"\"description\": \"This placeholder is for Description\"," + 
        		"\"title\": \"text for title\"" +	"}";
		return noteJson;
	}
    private Attachment getAttachment() {
    	Attachment attachment = new Attachment();
		attachment.setCreatedBy("createdBy");
		attachment.setCreationDate("creationDate");
		attachment.setDescription("description");
		attachment.setDomainId("domainId");
		attachment.setId("id");
		attachment.setTenantId("tenantId");
		attachment.setTitle("title");
		attachment.setUpdateDate("updateDate");
		attachment.setUpdatedBy("updatedBy");
    	return attachment;
    }
    private PostAttachment getPA() {
    	return new PostAttachment(
    	"domainId",
        "domainName",
        "description",
        "title",
         null);
    }
	private Optional<MultipartFile[]> getOptionalFiles() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] fileso = {file};
	    Optional<MultipartFile[]> files = Optional.of(fileso);
	    return files;
	}
}
