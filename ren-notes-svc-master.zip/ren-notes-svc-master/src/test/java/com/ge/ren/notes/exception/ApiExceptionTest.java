package com.ge.ren.notes.exception;

import org.junit.jupiter.api.Test;

import com.ge.ren.notes.exception.*;

import static org.assertj.core.api.Assertions.assertThat;

class ApiExceptionTest {

    @Test
    void getCodeTest() {
        ApiException e = new DuplicateKeyException("Resource Not Found ");
        
        assertThat(e.getMessage().equalsIgnoreCase("Resource Not Found ")).isTrue();

         e = new InvalidParameterException("Site Error ");
        assertThat(e.getMessage().equalsIgnoreCase("Site Error ")).isTrue();

        e = new NotFoundException("Resource Not Found ");
        assertThat(e.getMessage().equalsIgnoreCase("Resource Not Found ")).isTrue();

        e = new NotImplementedException("Resource Not Found ");
        assertThat(e.getMessage().equalsIgnoreCase("Resource Not Found ")).isTrue();

        e = new ResourceNotValid("Resource Not Valid ");
        assertThat(e.getMessage().equalsIgnoreCase("Resource Not Valid ")).isTrue();

        e = new NoteNotFound("Site group not found ");
        assertThat(e.getMessage().equalsIgnoreCase("Site group not found ")).isTrue();

        e = new UnauthorizedForActionException("Site Error ");
        assertThat(e.getMessage().equalsIgnoreCase("Site Error ")).isTrue();

        e = new  AttributeNotFound("Attribute not found ");
            assertThat(e.getMessage().equalsIgnoreCase("Attribute not found ")).isTrue();
        e = new AttachmentNotFound("Attachment not found ");
        	assertThat(e.getMessage().equalsIgnoreCase("Attachment not found ")).isTrue();
        System.out.println("get Exception Test done.  " );
    }

}