package com.ge.ren.resource;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.ren.notes.controller.NotesApiController;
import com.ge.ren.notes.service.NotesService;
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ApplicationTest {

	
	@Mock
    private NotesApiController controller;

	@Mock
    private NotesService service;

    @Test
    public void contextLoads() throws Exception {
    	System.out.println("get Application Test started....  " );
        assertTrue(null != controller);
        assertTrue(null != service);
        System.out.println("get Application Test done.  " );
    }
}
