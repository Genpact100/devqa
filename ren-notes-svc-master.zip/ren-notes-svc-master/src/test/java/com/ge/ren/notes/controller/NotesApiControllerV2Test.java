package com.ge.ren.notes.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.common.keycloak.exception.TokenVerifyException;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.constants.Constants;
import com.ge.ren.notes.constants.Scope;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.UpsertNote;
import com.ge.ren.notes.service.impl.NotesServiceImpl;
import com.ge.ren.notes.utils.ApiUtil;
import static org.mockito.ArgumentMatchers.anyList;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@EnableWebMvc
public class NotesApiControllerV2Test extends  AbstractTest{
    private String DOMAIN_SERVICE = "/common/v2";
    
    @Autowired
    private MockMvc mockMvc;
    
	@MockBean
    NotesServiceImpl service;

    @MockBean
	RequestInterceptor requestInterceptor;
    @MockBean
    ApiUtil apiUtil;

    ObjectMapper objectMapper = new ObjectMapper(); 

	UpsertNote notes = new UpsertNote();
	NotesRequest noteRequest = new NotesRequest();
	String tenantId = "tenantId";

	
	@MockBean
	com.ge.ren.attachments.utils.Autils utils;
	
	@BeforeEach
    public void setup() throws TokenVerifyException, JsonParseException, IOException {
		super.setUp();
		MockitoAnnotations.initMocks(this);

        when(requestInterceptor.getTenantId()).thenReturn("tenantid");
        when(requestInterceptor.getUsername()).thenReturn("name");
        UpsertNote note = getNote();
  		when(service.processGetRequest(any())).thenReturn(objectMapper.writeValueAsString(note));

        when(apiUtil.retrieveTenantId(requestInterceptor)).thenReturn("tenantId");
        when(apiUtil.retrieveUserName(requestInterceptor)).thenReturn("tenantName");
        
        List<String> capabilitiesList = new ArrayList<>();
        capabilitiesList.add(Constants.NOTES_AND_ATTACHMENTS);
        capabilitiesList.add(Constants.INTERNAL_ACCESS);
        List<String> roleList = new ArrayList<>();
        roleList.add(Constants.ROLE_SUPER_ADMIN);
        when(requestInterceptor.getUserCapabilities()).thenReturn(capabilitiesList);
        when(requestInterceptor.getUserRoles()).thenReturn(roleList);        
        when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("internal");

 		when( utils.validateForFileSize( any())).thenReturn(true);  	
	}
	
    @AfterAll
    void tearDown() throws IOException {
    }
    	
	@Test
	public void bulkPatchNoteTest() throws Exception {
		String uri = DOMAIN_SERVICE + "/asset-notes";
		UpsertNote upsertNote = new UpsertNote();
        upsertNote.setDomainId("domainId");
		upsertNote.setOnPremId("onPremId");
        List<UpsertNote> upsertNotesList = List.of(upsertNote);

        when(apiUtil.retrieveTenantId(requestInterceptor)).thenReturn("tenantId");
        when(apiUtil.retrieveUserName(requestInterceptor)).thenReturn("user");

		MvcResult mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.patch(uri).header("Allow", "PATCH")
		                      .accept(MediaType.APPLICATION_JSON_VALUE)
							  .contentType(MediaType.APPLICATION_JSON)
							  .content(mapToJson(upsertNotesList)))
		                      .andReturn();
		assertTrue(mvcResult.getResponse().getStatus() >= 200);

		uri = DOMAIN_SERVICE + "/site-notes";
		mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.patch(uri).header("Allow", "PATCH")
		                      .accept(MediaType.APPLICATION_JSON_VALUE)
							  .contentType(MediaType.APPLICATION_JSON)
							  .content(mapToJson(upsertNotesList)))
		                      .andReturn();
		assertTrue(mvcResult.getResponse().getStatus() >= 200);
	}
	
	private UpsertNote getNote() {
		UpsertNote note = new UpsertNote();
		note.setCategory("category");
		note.setCreatedBy("createdBy");
		note.setDeleted(false);
		note.setDomainId("domainId");
		note.setNote("note");
		note.setPriority("priority");
		note.setScope(Scope.internal.toString());
		note.setStatus("active");
		note.setTenantId("tenantId");
		note.setTitle("title");
		note.setUpdatedBy("updatedBy");
		note.setValidDateBy("validDateBy");
		return note;
	}	
}

