package com.ge.ren.notes.utils;

import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.text.FieldPosition;
import java.text.Format.Field;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DateFormatMS.class)
public class DateTimeUtilTest {

	@Autowired
	DateFormatMS df;
	@Test
	public void getCurrentDateFormatedTest() {
		String str = df.getCurrentDateFormated();
		assertTrue(!str.isEmpty());
		
		Timestamp ts = df.getcurrentTimestamp();
		assertTrue(ts.getTime() > 0);
		
		ts =  df.covertStringToTimestamp("2021-10-10 11:11:11");
		assertTrue(ts.getTime() > 0);
		ts = df.covertToTimestamp("11/11/11 11:11:11");
		assertTrue(ts.getTime() > 0);
		
		ts = df.covertToTimestamp("2021/11/11");
		assertTrue(ts.getTime() > 0);

		//StringBuffer sb = df.format(new Date() , new StringBuffer(), new FieldPosition(Field));
		System.out.println(" <<<<< stat testing Bucket name >>>>>>" );
		String date = df.getTodayDateString();
		assertTrue(!date.isEmpty());
		
		String file = df.getFileNameDateString();
		assertTrue(!file.isEmpty());
		
		date = df.getTodayDateString();
		assertTrue(!date.isEmpty());
		
		date = df.getFileNameDateString();
		assertTrue(!date.isEmpty());
		
		long number = df.getcurrentUnixTimestamp();
		assertTrue(number > 0);
		System.out.println(" DataFormat testing Bucket name is done... " );
	}
}
