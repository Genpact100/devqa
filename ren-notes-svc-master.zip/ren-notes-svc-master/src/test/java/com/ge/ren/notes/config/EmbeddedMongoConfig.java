package com.ge.ren.notes.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@Configuration
@EnableMongoRepositories(basePackages = "com.ge.ren.chicago.asset.repository")
@EnableAutoConfiguration
@Profile("BDD")
public class EmbeddedMongoConfig {

	
}
