package com.ge.ren.attachments.utils;

import static com.ge.ren.notes.constants.Constants.AWS_PATH1;
import static com.ge.ren.notes.constants.Constants.AWS_PATH2;
import static com.ge.ren.notes.constants.Constants.PATCH;
import static com.ge.ren.notes.constants.Constants.POST;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
//import org.powermock.api.mockito.PowerMockito;
//import org.powermock.core.classloader.annotations.PrepareForTest;
//import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.util.IOUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.Attachments;
import com.ge.ren.attachments.model.GetAttachments;
import com.ge.ren.attachments.model.PatchAttachment;
import com.ge.ren.attachments.model.PostAttachment;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.model.patch.Patch;
import com.ge.ren.attachments.service.impl.AttachmentServiceImpl;
import com.ge.ren.notes.constants.ErrorConstants;
import com.ge.ren.notes.constants.Scope;
import com.ge.ren.notes.dto.AttachmentBase;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.notes.model.AssetNotes;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.Pagination;
import com.ge.ren.notes.model.PatchNote;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.model.SiteNotes;
import com.ge.ren.notes.service.impl.NotesServiceImpl;
import com.ge.ren.notes.utils.DateFormatMS;
import com.ge.ren.notes.utils.ValidateUtil;

import lombok.extern.slf4j.Slf4j;

import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.rules.ExpectedException;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
@Slf4j
//@RunWith(PowerMockRunner.class)  
//@PrepareForTest(AttachmentServiceImpl.class)

@SpringBootTest (classes = {Autils.class}) //,MongoConfig.class
@TestInstance(Lifecycle.PER_CLASS)
//@RunWith(SpringRunner.class)
public class ValidatePostRequestTest {

	
	@MockBean
	ValidateUtil validateUtil;
	
	@MockBean
	DateFormatMS  dateFormat;
	
	@Autowired
	Autils autils;
	
	
	@Rule
    public ExpectedException thrown = ExpectedException.none();

	@org.junit.jupiter.api.Test
	public void validateForPostRequestTest() throws JsonMappingException, JsonProcessingException {
		String call = " PowerMock with Mockito ";  
	    String callexpectation = " Call Expectation ";  
	    
		MockMultipartFile mfile = new MockMultipartFile("data", "filename.kml", "text/plain", "some kml".getBytes());
    	//byte[] bytes = mfile.getBytes();
    	byte[] bytes = new byte[7024];
	    MockMultipartFile file = new MockMultipartFile("file",  "renewables-uai3031357-attachments-dev/attachments/test-image.png", MediaType.TEXT_PLAIN_VALUE, bytes);
	    MockMultipartFile[] fileso = {file};
	    //MockMultipartFile file = Optional.empty();
	    Optional<MultipartFile[]> files = Optional.of(fileso);
	    MultipartFile[] f = files.get();
	    
	    //PowerMockito.mockStatic(AttachmentServiceImpl.class);  
	    AttachmentServiceImpl mock = mock(AttachmentServiceImpl.class);
	    Mockito.when(mock.validatePostRequest(any(), any(), anyString())).thenReturn(new PostAttachment());
 
	      
	    PostAttachment pa = mock.validatePostRequest(new PostAttachment(), fileso, POST);  
	    assertEquals(pa.getDescription(), null );  
	    pa = mock.validatePostRequest(new PostAttachment(), fileso, PATCH);
	    assertEquals(pa.getDescription(), null);

	    try {
	    	//Mockito.when(mock.validatePostRequest(any(), any(), anyString())).thenThrow(AttributeNotFound.class);
	    	//Mockito.doThrow(ResourceNotValid.class).when(service).validatePostRequest(pat, null, POST );
			//Mockito.doThrow(new ResourceNotValid(ErrorConstants.VaidatedMessage.DOMAINID_NOT_FOUND.description())).when(service.validatePostRequest(new PostAttachment(), any() , "post"));
			//Mockito.doThrow(new ResourceNotValid(ErrorConstants.VaidatedMessage.DOMAINID_NOT_FOUND.description())).when(mutils).validatePostRequest(new PostAttachment(), any() , "patch");
			//Mockito.doThrow(new ResourceNotValid("getDescriptionSizeChecked")).when(mutils).getDescriptionSizeChecked(new PostAttachment());
		} catch (AttributeNotFound e) {
			log.debug("{}", e);
			assertTrue(e.getMessage().contains("Attribute"));
		} 
	    pa = new PostAttachment();
		StringBuilder sb = new StringBuilder(); 
	    for(int i=0; i<4005; i++ ) {
			sb.append("1");
		}
	    pa.setDescription(sb.toString());
	    try {
	    	Mockito.when(mock.validatePostRequest(any(), any(), anyString())).thenThrow(ResourceNotValid.class);
		} catch (ResourceNotValid e) {
			log.debug("{}", e);
			assertTrue(e.getMessage().length() >5000);
		} 
	    pa.setDescription(null);
	    pa.setTitle(sb.toString());
	    try {
	    	//Mockito.when(mock.validatePostRequest(any(), any(), anyString())).thenThrow(ResourceNotValid.class);
	    	
		} catch (ResourceNotValid e) {
			log.debug("{}", e);
			assertEquals(e, null);
		} 

	    log.debug(" >>> completed validateForFileSizeTest .....");

	}

	@Test
	public void validatePostAttachmentTest() throws IOException {
		Attachment a = getAttachment();
        try {
        	a = autils.validatePatchRequest(a, getFiles(), "patch");
            assertFalse(a != null);
        	a = autils.validatePatchRequest(a, getFiles(), "post");
            assertFalse(a != null);
        }
        catch (ApiException e){
            assertThat(e.getMessage().contains("exception")).isFalse();
        }catch(Exception e) {
        	assertThat(null == e);
        }
        
        try {
        	 
        	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		final Attachment at = getAttachment(); 
        		at.setDomainId(null); 
				autils.validatePatchRequest(at, getFiles(), "patch");
		    });
        	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		final Attachment at = getAttachment(); 
        		at.setDomainId("1"); 
    			at.setDomainName(null);
    			autils.validatePatchRequest(at, getFiles(), "post");
		    });
        	try {
	        	a.setDescription(null);
				autils.validatePatchRequest(getAttachment(), getFiles(), "patch");
	        	a.setDescription(null);
				autils.validatePatchRequest(getAttachment(), getFiles(), "post");
        	}catch(NullPointerException e) {
        		thrown.expect(NullPointerException.class);
        	}
			
			StringBuilder sb = new StringBuilder();
			for(int i=0; i<4005; i++ ) {sb.append("1");	}
        	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		final Attachment at = getAttachment(); 
        		at.setDescription(sb.toString());
				autils.validatePatchRequest(at, getFiles(), "patch");
		    });
        	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		final Attachment at = getAttachment();
        		at.setDescription(sb.toString());
				autils.validatePatchRequest(at, getFiles(), "post");
		    });
        	try {
	        	a.setTitle(null);
	        	autils.validatePatchRequest(a, getFiles(), "patch");
	        	a.setTitle(null);
	        	autils.validatePatchRequest(a, getFiles(), "post");
        	}catch(NullPointerException e) {
        		thrown.expect(NullPointerException.class);
        	}
	        	
        	
        	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		final Attachment at = getAttachment();
        		at.setTitle(sb.toString());
				autils.validatePatchRequest(at, getFiles(), "patch");
		    });
        	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		final Attachment at = getAttachment();
        		at.setTitle(sb.toString());
				autils.validatePatchRequest(at, getFiles(), "post");
		    });
        	
        	//spec chars:
        	when(ValidateUtil.validateForSpecChars(anyString(), anyString())).thenReturn("valid");
        	autils.validatePatchRequest(a, getFiles(), "patch");
        	
        	when(ValidateUtil.validateForSpecChars(anyString(), anyString())).thenReturn("valid");
        	autils.validatePatchRequest(a, getFiles(), "post");
        	
        	when(ValidateUtil.validateForSpecChars(anyString(), anyString())).thenThrow(new ResourceNotValid(""));

        	
           	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		final Attachment at = getAttachment();
            	at.setTitle("@@");
				autils.validatePatchRequest(at, getFiles(), "post");
		    });

           	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		final Attachment at = getAttachment();
            	at.setTitle("@@");
				autils.validatePatchRequest(at, getFiles(), "patch");
		    });
           	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		final Attachment at = getAttachment();
            	at.setDescription("##");
				autils.validatePatchRequest(at, getFiles(), "patch");
		    });

           	
           	
           	a.setDescription("d");
           	Assertions.assertThrows(AttributeNotFound.class, () -> {
        		final Attachment at = getAttachment();
            	at.setTitle("##");
				autils.validatePatchRequest(at, null, "post");
		    });

           	Assertions.assertThrows(AttributeNotFound.class, () -> {
        		final Attachment at = getAttachment();
            	at.setDescription("##");
				autils.validatePatchRequest(at, null, "post");
		    });

           	
        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        	//thrown.expect(NullPointerException.class);
		}catch(Exception e) {
			assertThat(null == e);
		}
        
        
        
    	//doNothing().when(validation).validateId(anyString(), anyString(), any());
    	//doNothing().when(validateUtil).validateJsonString(any());
        //noteR.setBody(pn);	
		//Note attachment = new Note (((PostNote)noteR.getBody()));
		
		//ResponseEntity<Object> resp = this.servicen.processPostRequest(noteR);
    	//Mockito.verify(servicen, Mockito.atLeastOnce()).processPostRequest(any());
		
	
		
		
		
        //when(repository.findByTenantIdAndSiteGroupId(any(), any())).thenReturn(null);
        //when(repository.insert((SiteGroup) any())).thenReturn(siteGroup);
        //when(siteGroupTypeRepository.findByTenantIdAndSiteGroupType(any(),any())).thenReturn(new SiteGroupType());
        //when(siteGroupTypeService.retrieveTypeByTenantIdAndSiteGroupType(any(),any())).thenReturn(type);

		//Mockito.when(service.processPostRequest(noteR)).thenReturn(new ResponseEntity<> (notes, HttpStatus.CREATED));

		//ResponseEntity<Object> id = service.processDeleteRequest(noteR, SiteNotes.class);
		//Mockito.verify(service, Mockito.atLeastOnce()).processPostRequest(noteR);		
		//assertTrue(noteR.getId().contentEquals("id"));
		
		// validate for Error
	}

	@org.junit.jupiter.api.Test
    public void checkAttachmentsTest() throws JsonMappingException, JsonProcessingException {
		PostAttachment pat = new PostAttachment(  );
		com.ge.ren.notes.model.Attachment a = new com.ge.ren.notes.model.Attachment( "dev", "path");
		assertTrue(a != null);
		
		GetAttachments ga = new GetAttachments();
		ga.setAttachments(Arrays.asList(new com.ge.ren.attachments.model.Attachment()));
		assertTrue(ga.getAttachments() != null);
		ga.setPagination(new Pagination());
		assertNotNull(ga.getPagination());

		 AssetNotes an = getAssetNote();
		 an.setAttachments(Arrays.asList(new AttachmentData()));
		 assertNotNull(an);
		 
		 AttachmentData ad = getAttachmentData();
		 assertTrue(ad != null);
		 ad = new AttachmentData ("type", "file", "test1.txt");
		 assertFalse(ad.getContentType().equals("type"));
		 assertTrue(!ad.getFile().equals("file"));
		 assertTrue(ad.toString().contains("file"));
		 
		 //attachment dto
		 com.ge.ren.attachments.dto.AttachmentData aData = new com.ge.ren.attachments.dto.AttachmentData();
		 assertTrue(aData != null);
		 aData.setContentType("type");
		 aData.setFile("file");
		 assertTrue(aData.getContentType().contains("type"));
		 assertTrue(aData.getFile().contains("file"));
		 aData = new com.ge.ren.attachments.dto.AttachmentData("type", "file");
		 assertTrue(!aData.getContentType().contains("type"));
		 assertTrue(!aData.getFile().contains("file"));
		 assertFalse(aData.toString().isEmpty());
		 
		 
		 //AttachmentBase
		 com.ge.ren.attachments.model.PostAttachment pa = new com.ge.ren.attachments.model.PostAttachment("1", "2", "3", "4", new ArrayList<AttachmentData>());
		 AttachmentBase ab = new AttachmentBase(pa);
		 assertTrue(ab != null);
		 assertTrue(ab.getAttachments().isEmpty());
		ab = new AttachmentBase();
		ab.setAttachments(new ArrayList<AttachmentData>());
		ab.setDescription("description");
		ab.setDomainName("domainName");
		ab.setTitle("title");
		ab.setDomainId("id");
		
		assertEquals("id",ab.getDomainId());
		 
		 ab = new AttachmentBase("id", "domainName", 
				 "domainId", "tenantId", "title", "description", "creationDate", "updateDate", "createdBy", "updatedBy", 
				 new Timestamp(System.currentTimeMillis()), new Timestamp(System.currentTimeMillis()), null);
		 
		 assertFalse(ab.toString().isEmpty());
		 // com.ge.ren.attachments.model
		 com.ge.ren.attachments.model.Attachments ats = new com.ge.ren.attachments.model.Attachments();
		 List<com.ge.ren.attachments.model.Attachment> list = new ArrayList<>();
		 ats.setAttachments(list);
		 ats.setPagination(new Pagination(0,0,0,0));

		 assertFalse(ats.toString().isEmpty());
		 assertFalse(null == ats);
		 assertTrue(ats.getAttachments().isEmpty());
		 assertFalse(ats.getPagination() == null);
		 
		 		 // Attachment(PostAttachment pAttachment)
		 com.ge.ren.attachments.model.Attachment at = new com.ge.ren.attachments.model.Attachment(pa);
		 assertTrue( null != at);
		 assertEquals("domainId", ab.getDomainId());
		 assertEquals("domainName", ab.getDomainName());
		 
		 ats = new com.ge.ren.attachments.model.Attachments(new Pagination(), list);
		 
		 assertTrue(ats.getAttachments().isEmpty());
		 assertTrue(ats != null);
		 
		 //Pagination
		 Pagination pg = new Pagination();
		 pg.setCurrentPage(1);
		 pg.setPageSize(1);
		 pg.setTotalPages(10);
		 pg.setTotalRecords(10);
		 
		 assertNotNull(pg.getCurrentPage());
		 assertNotNull(pg.getPageSize());
		 assertNotNull(pg.getTotalPages());
		 assertNotNull(pg.getTotalRecords());
		 //at.setDomainId("1");
		 //assertFalse(at.toString().isEmpty());
		 try {   
        	pat.setDescription(null);
        	pat.setTitle(null);
	        //utils.validatePostRequest(pat, null, POST );
	        
        	com.ge.ren.attachments.dto.Attachment atd = new com.ge.ren.attachments.dto.Attachment();
        	atd.setAttachments(new ArrayList<AttachmentData>());
        	assertTrue(atd.getAttachments() != null);
        	atd.setCreatedBy("createdBy");
        	assertNotNull(atd.getCreatedBy());
        	atd.setCreationDate("10/10/25 10:10:10");
        	assertNotNull(atd.getCreationDate());
        	atd.setDescription("description");
        	assertNotNull(atd.getDescription());
        	atd.setDomainId("domainId");
        	assertNotNull(atd.getDomainId());
        	atd.setDomainName("domainName");
        	assertNotNull(atd.getDomainName());
        	atd.setId("id");
        	assertNotNull(atd.getId());
        	atd.setTenantId("tenantId");
        	assertNotNull(atd.getTenantId());
        	atd.setTimestampc(new Timestamp(System.currentTimeMillis()));
        	assertNotNull(atd.getTimestampc());
        	atd.setTimestampu(new Timestamp(System.currentTimeMillis()));
        	assertNotNull(atd.getTimestampu());
        	atd.setTitle("title");
        	assertNotNull(atd.getTitle());
        	atd.setUpdateDate("10/10/25 10:10:10");
        	assertNotNull(atd.getUpdateDate());
        	atd.setUpdatedBy("updatedBy");
        	assertNotNull(atd.getUpdatedBy());
        	assertTrue(atd.getAttachments().isEmpty());
        	assertEquals("createdBy", atd.getCreatedBy());
        	assertTrue(atd.toString() != null);
        	atd = new com.ge.ren.attachments.dto.Attachment("id", "domainName", "domainId", "tenantId", "title", "description",
        			"creationDate", "updateDate", "createdBy", "updatedBy", new Timestamp(System.currentTimeMillis()),
        			new Timestamp(System.currentTimeMillis()), new ArrayList<AttachmentData>());
        	
        	assertTrue(atd.getAttachments().isEmpty());
        	assertEquals("createdBy", atd.getCreatedBy());
        	assertTrue(atd.toString() != null);
        	
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
        try {
        	//Mockito.doThrow(ResourceNotValid.class).when(Utils..validatePostRequest(pat, null, PATCH ));
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}

        com.ge.ren.attachments.model.patch.Attachment atm = new com.ge.ren.attachments.model.patch.Attachment();
        atm.setOp("add");
        
        
        //validate  ren.ge.ren.attachments.dto.AttachmentBase
        
		 try {   
	        	pat.setDescription(null);
	        	pat.setTitle(null);
		        //utils.validatePostRequest(pat, null, POST );
		        
	        	com.ge.ren.attachments.dto.Base abs = new com.ge.ren.attachments.dto.Base();
	        	abs.setAttachments(new ArrayList<AttachmentData>());
	        	assertTrue(abs.getAttachments() != null);
	        	abs.setBcreatedBy("createdBy");
	        	assertNotNull(abs.getBcreatedBy());
	        	abs.setBcreationDate("10/10/25 10:10:10");
	        	assertNotNull(abs.getBcreationDate());
	        	abs.setBdescription("description");
	        	assertNotNull(abs.getBdescription());
	        	abs.setBdomainId("domainId");
	        	assertNotNull(abs.getBdomainId());
	        	abs.setBdomainName("domainName");
	        	assertNotNull(abs.getBdomainName());
	        	abs.setId("id");
	        	assertNotNull(abs.getId());
	        	abs.setBtenantId("tenantId");
	        	assertNotNull(abs.getBtenantId());
	        	abs.setBtimestampc(new Timestamp(System.currentTimeMillis()));
	        	assertNotNull(abs.getBtimestampc());
	        	abs.setBtimestampu(new Timestamp(System.currentTimeMillis()));
	        	assertNotNull(abs.getBtimestampu());
	        	abs.setBtitle("title");
	        	assertNotNull(abs.getBtitle());
	        	abs.setBupdateDate("10/10/25 10:10:10");
	        	assertNotNull(abs.getBupdateDate());
	        	abs.setBupdatedBy("updatedBy");
	        	abs.setBcategory("category");
	        	abs.setBpriority("HIGH");
	        	abs.setBstatus("active");
	        	abs.setBvalidDateBy("10/10/25 10:10:10");
	        	assertNotNull(abs.getBcategory());
	        	assertNotNull(abs.getBpriority());
	        	assertNull(abs.getBscope());
	        	assertNotNull(abs.getBstatus());
	        	assertNotNull(abs.getBupdatedBy());
	        	assertTrue(abs.getAttachments().isEmpty());
	        	assertEquals("createdBy", abs.getBcreatedBy());
	        	assertTrue(abs.toString() != null);
	        	abs = new com.ge.ren.attachments.dto.Base("id", "domainName", "domainId", "tenantId", "title", "description",
	        			"creationDate", "updateDate", "createdBy", "updatedBy", new Timestamp(System.currentTimeMillis()),
	        			new Timestamp(System.currentTimeMillis()), new ArrayList<AttachmentData>());
	        	
	        	assertTrue(abs.getAttachments().isEmpty());
	        	assertEquals("createdBy", abs.getBcreatedBy());
	        	assertTrue(abs.toString() != null);
	        	
	        	assertFalse(abs.toString().isEmpty());
	        	
			} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
				thrown.expect(ResourceNotValid.class);
			}
        

    }
	
	@org.junit.jupiter.api.Test
	public void  testGetJsonPatch() {
    	JsonPatch jp = new JsonPatch();

    	com.ge.ren.attachments.model.patch.Attachment atts = new 
    			com.ge.ren.attachments.model.patch.Attachment("add", (AWS_PATH1+System.getenv("spring.profiles.active")+AWS_PATH2)+"attachments", "test1.txt");
    	Patch patch = new Patch("add", "note", "new note value");
    	List<Patch> plist = new ArrayList<>();
    	plist.add(patch);
    	List<com.ge.ren.attachments.model.patch.Attachment> alist = new ArrayList<>();
    	alist.add(atts);
    	jp.setAttachments(alist);
    	jp.setPatch(plist);

    	assertTrue(jp != null);
    	assertTrue(jp.getAttachments().get(0).getOp() != null);
    	assertTrue(jp.getPatch().get(0).getOp() != null);
    	assertTrue(plist != null);
    	assertTrue(alist != null);
    	assertTrue(patch.op != null);
    	assertTrue(jp.toString() != null);
    	assertTrue(atts.toString() != null);
    	patch = new Patch();
    	patch.setOp("add");
    	patch.setPath("/title");
    	patch.setValue("new value");
    	atts = new com.ge.ren.attachments.model.patch.Attachment();
    	assertTrue(patch != null);
    	assertTrue(atts != null);

    	//PatchAttachment
    	PatchAttachment pa = new PatchAttachment();
    	
    	pa.setOp("op");
    	pa.setPath("/path");
    	pa.setValue("value");
    	assertTrue(pa.getPath() != null);
    	assertTrue(pa.getOp() != null);
    	assertTrue(pa.getValue() != null);
    	assertTrue(pa.toString() != null);
    	pa = new PatchAttachment("op", "/path", "value");
    	assertTrue(pa.getPath() != null);
    	assertTrue(pa.getOp() != null);
    	assertTrue(pa.getValue() != null);
    	
    	// JsonPatch all
    	jp = new JsonPatch(new ArrayList<Patch>(), new ArrayList<com.ge.ren.attachments.model.patch.Attachment>());
    	assertTrue(jp != null);
    	
    	atts = new com.ge.ren.attachments.model.patch.Attachment("op", "path", "value");
    	assertNotNull(atts.getPath());
    	assertNotNull(atts.getValue());
    	
	}
    
	@org.junit.jupiter.api.Test
    public void validatePatchNoteTest() {
    	PatchNote pn = new PatchNote();
    	pn.setAttachments(new ArrayList<AttachmentData>());
    	pn.setCategory("category");
    	pn.setNote("note");
    	pn.setPriority("HIGH");
    	pn.setScope("internal");
    	pn.setStatus("active");
    	pn.setTitle("title");
    	pn.setUpdatedBy("updatedBy");
    	pn.setValidDateBy("08/22/25 22:22:22");
    	
    	assertTrue(pn != null);
    }
    
	
	   @org.junit.jupiter.api.Test 
		public void getAttachmentDtoNotesValidatedTest() throws AttributeNotFound, IOException{
			log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			int nameSize=10;
			int	titleSize=5;
			log.info("Start getNotesValidated Test " + new Date(System.currentTimeMillis()));
			com.ge.ren.attachments.dto.NoteBase notes = new com.ge.ren.attachments.dto.NoteBase(); 
			notes.setNoteCategory("category");
			notes.setNoteCreatedBy("createdBy");
			assertNotNull(notes.getNoteCreatedBy());
			notes.setNoteCreationDate("12/12/25 11:11:11");
			assertNotNull(notes.getNoteCreationDate());
			notes.setNoteDeleted(false);

			notes.setId("id");
			assertNotNull(notes.getId());
			notes.setNotePriority("HIGH");
			notes.setNoteScope("external");
			notes.setNoteStatus("active");
			notes.setTenantId("tenantId");
			assertNotNull(notes.getTenantId());
			notes.setNoteTitle("title");
			notes.setNoteUpdateDate("12/12/25 11:11:11");
			assertNotNull(notes.getNoteUpdateDate());
			notes.setNoteUpdatedBy("DK");
			notes.setNoteValidDateBy("12/12/25 11:11:11");
			notes.setNoteTimestampc(new Timestamp(nameSize));
			notes.setNoteTimestampu(new Timestamp(nameSize));
			assertNotNull(notes.getNoteTimestampc());
			assertNotNull(notes.getNoteTimestampu());
			notes.setAttachments(new ArrayList<AttachmentData>());
			assertNotNull(notes.getAttachments());
			assertNotNull(notes.toString());
			
	        Optional<String> optionalStr = Optional.empty();
	        Optional<Integer> optionalInt = Optional.empty();
	        NotesRequest noteR = new NotesRequest();
	        noteR.setDomain("sites");
	        noteR.setDomainIds("domainIds");
	        assertNull(notes.getNoteDomainId());
	        noteR.setFilter("id,title,note,domainId,category,updatedBy");
	        noteR.setPageIdx(0);
	        noteR.setPageSize(5);
	        noteR.setTenantId("tenantId");
	        noteR.setQuery("priority==MEDIUM;category==category");
	        noteR.setBody(notes);
			
	        notes = new com.ge.ren.attachments.dto.NoteBase("id", "domainId", "tenantId","title", "note", "06/09/2021 12:45:55", "06/10/2021 1:40:55",  "06/11/2021 2:00:00", "HIGH", "503206931", "503206931", "category", "sttus",  "scope", 
	        		new Timestamp(nameSize), 
	        		new Timestamp(nameSize), false, new ArrayList<AttachmentData>());
	        assertNotNull(notes);
	        

	        	SiteNotes sn = new SiteNotes();
	    		sn.setId("id");
	    		sn.setDomainId("domainId");
	    		sn.setTenantId("tenantId");
	    		sn.setTitle("title"); 
	    		sn.setNote("note");
	    		sn.setCreationDate("06/10/2021 1:40:55");
	    		sn.setUpdateDate("06/10/2021 1:40:55");
	    		sn.setValidDateBy("vb");
	    		sn.setPriority("priority");
	    		sn.setCreatedBy("cb");
	    		sn.setUpdatedBy("ub");
	    		sn.setCategory("cat");
	    		sn.setStatus("active");
	    		sn.setScope("internal");
	    		sn.setDeleted(false);
	    		notes = new com.ge.ren.attachments.dto.NoteBase(sn);
	    		assertNotNull(notes);
	    		assertNotNull(notes.getNoteDeleted());
	    		
	    		PostNote pn = new PostNote();
	    		pn.setDomainId("id");
	    		pn.setAttachments(new ArrayList<AttachmentData>());
	    		pn.setCategory("category");
	    		pn.setNote("note");
	    		pn.setPriority("HIGH");
	    		pn.setScope("internal");
	    		pn.setStatus("active");
	    		pn.setTitle("title");
	    		pn.setValidDateBy("06/10/2021 1:40:55");
	    		notes = new com.ge.ren.attachments.dto.NoteBase(pn);
	    		assertNotNull(notes);
	    		assertNotNull(notes.getNoteValidDateBy());
	    		
	    		PatchNote pp = new PatchNote();
	    		pp.setTitle("title");
	    		pp.setCategory("category");
	    		pp.setNote("note");
	    		pp.setPriority("HIGH");
	    		pp.setPriority("HIGH");
	    		pp.setScope("internal");
	    		pp.setStatus("active");
	    		pp.setUpdatedBy("dk");
	    		notes = new com.ge.ren.attachments.dto.NoteBase(pp);
	    		assertNotNull(notes);
	    		assertNull(notes.getNoteUpdatedBy());
	   }	    		
	    		

	//helpers
	private Optional<MultipartFile[]> createMultipartFile() throws IOException {
		File file = new File("src/main/resources/attachments/test-image.png");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file",
		            file.getName(), "text/plain", IOUtils.toByteArray(input));
		MultipartFile[] mf = {multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, 
				multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile,
				multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile};
		Optional<MultipartFile[]> mfo = Optional.of(mf);
		return mfo;  
	}
    
    private AttachmentData getAttachmentData() {
    	AttachmentData attachment = new AttachmentData();
		//"id", "domainId", "tenantId", "title", "note", 
		//"06/09/2021 12:45:55", "06/10/2021 1:40:55", "06/11/2021 2:00:00", 
		//"HIGH", "503206931", "503206931", "category", "status", "internal", false);
		attachment.setContentType("type");
		attachment.setFile("file");
    	return attachment;
    }	
	private Optional<MultipartFile[]> getMultipartFiles() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] fileso = {file};
	    Optional<MultipartFile[]> files = Optional.of(fileso);
	    return files;
	}
	
	private MultipartFile[] getFiles() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] files = {file};
	    return files;
	}
	
    private Attachment getAttachment() {
    	Attachment attachment = new Attachment();
		attachment.setCreatedBy("createdBy");
		attachment.setCreationDate("creationDate");
		attachment.setDescription("description");
		attachment.setDomainId("domainId");
		attachment.setId("id");
		attachment.setTenantId("tenantId");
		attachment.setTitle("title");
		attachment.setUpdateDate("updateDate");
		attachment.setUpdatedBy("updatedBy");
    	return attachment;
    }
    public static String asJsonString(final
            Note notes) {
    	try {
    		return new ObjectMapper().writeValueAsString(notes);
    	} catch (Exception e) {
    		throw new RuntimeException(e);
    	}
    }
    
    private PostAttachment getPost() {
	    	return new PostAttachment("id",  "domainName",  "sb.toString",  "title", Arrays.asList(new AttachmentData()));
    }
    // make text-part using MockMultipartFile
	private MockMultipartFile makeMultipartTextPart(String requestPartName, String value, String contentType) throws Exception {
	       return new MockMultipartFile(requestPartName, "", contentType,
	               value.getBytes(Charset.forName("UTF-8")));   
	}

	private byte[] readResourceFile(String pathOnClassPath) throws Exception {
	      return Files.readAllBytes(Paths.get(Thread.currentThread().getContextClassLoader()
	         .getResource(pathOnClassPath).toURI()));
	}
	private JsonPatch getJsonPatch() {
    	JsonPatch jp = new JsonPatch();

    	com.ge.ren.attachments.model.patch.Attachment atts = new 
    			com.ge.ren.attachments.model.patch.Attachment("add", (AWS_PATH1+System.getenv("spring.profiles.active")+AWS_PATH2)+"attachments", "test1.txt");
    	Patch patch = new Patch("add", "note", "new note value");
    	List<Patch> plist = new ArrayList<>();
    	plist.add(patch);
    	List<com.ge.ren.attachments.model.patch.Attachment> alist = new ArrayList<>();
    	alist.add(atts);
    	jp.setAttachments(alist);
    	jp.setPatch(plist);
    	return jp;
	}
	
    private Note getNote() {
    	Note note = new Note();
		note.setCategory("category");
		note.setCreatedBy("createdBy");
		note.setCreationDate("creationDate");
		note.setDeleted(false);
		note.setDomainId("domainId");
		note.setId("id");
		note.setNote("note");
		note.setPriority("priority");
		note.setScope(Scope.internal.toString());
		note.setStatus("active");
		note.setTenantId("tenantId");
		note.setTitle("title");
		note.setUpdateDate("updateDate");
		note.setUpdatedBy("updatedBy");
		note.setValidDateBy("validDateBy");
		note.setAttachments(new ArrayList<AttachmentData>());
    	return note;
    }
    
    private AssetNotes getAssetNote() {
    	AssetNotes note = new AssetNotes();
		note.setCategory("category");
		note.setCreatedBy("createdBy");
		note.setCreationDate("creationDate");
		note.setDeleted(false);
		note.setDomainId("domainId");
		note.setId("id");
		note.setNote("note");
		note.setPriority("priority");
		note.setScope(Scope.internal.toString());
		note.setStatus("active");
		note.setTenantId("tenantId");
		note.setTitle("title");
		note.setUpdateDate("updateDate");
		note.setUpdatedBy("updatedBy");
		note.setValidDateBy("validDateBy");
		note.setAttachments(new ArrayList<AttachmentData>());
    	return note;
    }	
}
