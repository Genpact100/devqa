package com.ge.ren.resource;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ge.ren.notes.model.ApplicationHealth;
import com.ge.ren.notes.model.ApplicationHealth.HealthCheckStatus;
import com.ge.ren.notes.resource.HealthCheckDetails;
import com.ge.ren.notes.resource.HealthCheckResourceImpl;

@SpringBootTest(classes=HealthCheckDetails.class)
@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
public class HealthCheckResourceTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	HealthCheckResourceImpl health = new HealthCheckResourceImpl();
	@Autowired
	HealthCheckDetails hs;
	
	@Test
	public void getHealthCheckTest() throws Exception {
		health.setHealthcheckDetails(hs);
		this.mockMvc.perform(get("/common/v1/notes/healthcheck")).andDo(print()).andReturn();
		System.out.println("get Health Test done.  " );
	}
	
	@Test
	public void getHealthCheckDeepTest() throws Exception {
		health.setHealthcheckDetails(hs);
		this.mockMvc.perform(get("/common/v1/notes/healthcheck/deep")).andDo(print()).andReturn();
		System.out.println("get Health Test Deep done.  " );
	}
	
	@Test 
	public void getEnumTest() {
		HealthCheckDetails hs=mock(HealthCheckDetails.class);
		health.setHealthcheckDetails(hs);
		ApplicationHealth applicationHealth = new ApplicationHealth();
	     when(hs.getApplicationHealth()).thenReturn(applicationHealth);
		
		ApplicationHealth ah = health.getHealthCheck();
		ah.setJavaVersion("javaVersion");
		ah.setApplicationVersion("applicationVersion");
		ah.setEnvironment("environment");
		ah.setPodName("podName");
		ah.setPodNameSpace("podNameSpace");
		ah.setStartDateTime(new Date());
		ah.setStatus(null);
		assertTrue(!ah.getApplicationVersion().isEmpty());
		assertTrue(!ah.getEnvironment().isEmpty());
		assertTrue(!ah.getJavaVersion().isEmpty());
		assertTrue(!ah.getPodName().isEmpty());
		assertTrue(ah.getStartDateTime().getTime() > 0);
		assertTrue(ah.getStatus().HEALTHY.toString().equalsIgnoreCase("HEALTHY"));
		ah = new ApplicationHealth("a","a",new Date(), null, "a","a","a");
		assertTrue(!ah.getApplicationVersion().isEmpty());
		assertTrue(!ah.getEnvironment().isEmpty());
		assertTrue(!ah.getJavaVersion().isEmpty());
		assertTrue(!ah.getPodName().isEmpty());
		assertTrue(ah.getStartDateTime().getTime() > 0);
		assertTrue(ah.getStatus().UNHEALTHY.toString().equalsIgnoreCase("UNHEALTHY"));
		
		assertTrue(HealthCheckResourceImpl.ErrorSeverity.MAJOR.toString().equalsIgnoreCase("MAJOR"));
		assertTrue(HealthCheckResourceImpl.ErrorSeverity.MINOR.toString().equalsIgnoreCase("MINOR"));
		
		assertTrue(HealthCheckResourceImpl.AppErrorCode.DI_NULL_500.toString().equalsIgnoreCase("DI_NULL_500"));
		assertTrue(HealthCheckResourceImpl.AppErrorCode.DI_NULL_501.toString().equalsIgnoreCase("DI_NULL_501"));
	}
	

}
