package com.ge.ren.notes.utils;

import static com.ge.ren.notes.constants.Constants.DELETED;
import static com.ge.ren.notes.constants.Constants.PAGE_SEARCH_SORT_KEY;
import static com.ge.ren.notes.constants.Constants.TENANTID;
import static com.ge.ren.notes.constants.Constants.AWS_PATH1;
import static com.ge.ren.notes.constants.Constants.AWS_PATH2;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.NativeWebRequest;

import com.fasterxml.jackson.core.JsonParseException;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.model.patch.Patch;
import com.ge.ren.attachments.service.impl.AttachmentServiceImpl;
import com.ge.ren.attachments.utils.AwsUploader;
import com.ge.ren.common.keycloak.exception.TokenVerifyException;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.constants.Constants;
import com.ge.ren.notes.controller.NotesApiController;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.NotFoundException;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.service.NotesService;
import com.ge.ren.notes.utils.ApiUtil;
import com.ge.ren.notes.utils.JacksonConfiguration;
import com.ge.ren.notes.utils.ValidateUtil;
@RunWith(SpringRunner.class)
@SpringBootTest(classes= {ApiUtil.class}, properties = {"bucket=attachments","descriptionSize=20", "titleSize=10", "storageType=fyleSystem", "searchLimit=1"}) 
//, properties = {"bucket=attachments","descriptionSize=20", "titleSize=10", "storageType=fyleSystem", "searchLimit=1"}) //,MongoConfig.class 
@TestPropertySource(locations = "/application.properties") 

@AutoConfigureMockMvc
public class ApiUtilTest {

 	@MockBean
 	MongoTemplate mongoTemplate;
 
    @MockBean
    RequestInterceptor requestInterceptor;
 	
	@MockBean
	AwsUploader awsUploader;
	
	@Autowired
	ApiUtil apiUtil;
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
    Note note;
    
    @BeforeEach
    public void setup() throws TokenVerifyException {
    	MockitoAnnotations.initMocks(this);
        when(requestInterceptor.getTenantId()).thenReturn("tenantid");
        when(requestInterceptor.getUsername()).thenReturn("name");
        //when(requestInterceptor.preHandle(any(), any(), any())).thenReturn(true);
        //when(requestInterceptor.isTenantAdmin()).thenReturn(true);
        //when(requestInterceptor.isSiteManager()).thenReturn(true);
        List<Object> notes = new ArrayList<>();
        when(mongoTemplate.find(any(), any())).thenReturn(notes);
        

        List<String> capabilitiesList = new ArrayList<>();
        capabilitiesList.add(Constants.NOTES_AND_ATTACHMENTS);
        capabilitiesList.add(Constants.INTERNAL_ACCESS);
        List<String> roleList = new ArrayList<>();
        roleList.add(Constants.ROLE_SUPER_ADMIN);
        when(requestInterceptor.getUserCapabilities()).thenReturn(capabilitiesList);
        when(requestInterceptor.getUserRoles()).thenReturn(roleList);
    }
    
	@Test
	public void getCriteriaFromQueryParserTest() {
		//public Query getCriteriaFromRsqlParser(String squery, Query query) throws ApiException {
		Query q = new Query();
		assertTrue(null != q);
		q = apiUtil.getCriteriaFromQueryParser("category==category;priority==HIGH", new Query());
		assertTrue(!q.isSorted());
		q.fields().include("id");
		assertTrue(!q.fields().getFieldsObject().containsValue("id"));
	}
    
    @Test
    public void ApiUtilbaseTest() throws Exception {
    	System.out.println(">>> get ApiUtil Test started....  " + new Date());
		List<Note> notes = new ArrayList <Note>(); 
		
		Query query = new Query();
		NotesRequest request = new NotesRequest();
		request.setDomain("siteNotes");
    	//when(util.getNotesByDomain(any(NotesRequest.class), any(Query.class))).thenReturn(notes);
       	notes = (List<Note>)apiUtil.getNotesByDomain(request, query);
    	assertTrue(notes.isEmpty());

		request.setDomain("assetNotes");
		//when(util.getNotesByDomain(any(NotesRequest.class), any(Query.class))).thenReturn(notes);
    	
		notes = (List<Note>)apiUtil.getNotesByDomain(request, query);
    	assertTrue(notes.isEmpty());

		request.setDomain("caseNotes");
		//when(util.getNotesByDomain(any(NotesRequest.class), any(Query.class))).thenReturn(notes);
		notes = (List<Note>)apiUtil.getNotesByDomain(request, query);
    	assertTrue(notes.isEmpty());

		request.setDomain("eventNotes");
		//when(util.getNotesByDomain(any(NotesRequest.class), any(Query.class))).thenReturn(notes);
    	notes = (List<Note>)apiUtil.getNotesByDomain(request, query);
    	assertTrue(notes.isEmpty());

		request.setDomain("taskNotes");
		//when(apiUtil.getNotesByDomain(any(NotesRequest.class), any(Query.class))).thenReturn(notes);
		notes = (List<Note>)apiUtil.getNotesByDomain(request, query);
    	assertTrue(notes.isEmpty());

		request.setDomain("case");
		//when(util.getNotesByDomain(request, query)).thenThrow(new ResourceNotValid("Domain Name is not valid"));
        //Assertions.assertThrows(ResourceNotValid.class, () -> {
        try {
        	apiUtil.getNotesByDomain(request, query);
        //});
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
    	
    	
    	 //when(mock.isOk()).thenReturn(true);
    	 //when(mock.isOk()).thenThrow(exception);
    	 //doThrow(exception).when(mock).someVoidMethod();
    	 
    	 //missing thenReturn()
//    	Mockito.doCallRealMethod().when(util).retrieveUserName(requestInterceptor);
    	//Mockito.doReturn(util.validateRequest(request,  "siteNotes"));
		query.addCriteria(Criteria.where(TENANTID).is("geservdrZp").and("id").is(request.getId()).and(DELETED).ne(true));
		
    	Mockito.verify(mongoTemplate, Mockito.times(0)).count(query, "siteNotes");
    	
    	//Mockito.doCallRealMethod().when(util.retrieveUserName(requestInterceptor));
  //  	Mockito.doCallRealMethod().when(util).retrieveTenantId(requestInterceptor);
    	
    	//Mockito.doCallRealMethod().when(util.retrieveUserName(requestInterceptor));
       
		
	  when(requestInterceptor.getUsername()).thenReturn(null);
	  Assertions.assertThrows(ResourceNotValid.class, () -> {
		  apiUtil.retrieveUserName(requestInterceptor);
	  });
	  
	  when(requestInterceptor.getTenantId()).thenReturn(null);
	  Assertions.assertThrows(NotFoundException.class, () -> {
		  apiUtil.retrieveTenantId(requestInterceptor);
	  });
		
        try {
        	when(requestInterceptor.getUsername()).thenReturn("user");
        	String name = apiUtil.retrieveUserName(requestInterceptor);
        	assertTrue(name != null);
        }catch(Exception e) {
        	System.out.println(e.getMessage());
        }
    	try {
    		when(requestInterceptor.getTenantId()).thenReturn("id");
    		String id = apiUtil.retrieveTenantId(requestInterceptor); 
    		assertTrue(id != null);
        }catch(Exception e) {
        	System.out.println(e.getMessage());
        }		            
    	System.out.println(">>> get ApiUtil Test done.  " + new Date());
    }
    
    @Test
	public void removeLinksTest() {
		when(awsUploader.removeS3Object(any())).thenReturn(true);
		//Mockito.doNothing().when(Files).delete(any());
		Assertions.assertThrows(ApiException.class, () -> {
			List<com.ge.ren.attachments.model.patch.Attachment> attachmentList = getJsonPatch().getAttachments();
			List<AttachmentData> attachments = new ArrayList<>();
			AttachmentData ad = new AttachmentData("attachments/test1.txt", "text/txt", "test1.txt");
			attachments.add(ad);

			List<AttachmentData> atachments = apiUtil.removeLinks(attachmentList, attachments);
			assertTrue(attachments != null);
		});
		

	}
    
    @Test
    public void processQueryTest() { 
    	Map<String,Object>  result = apiUtil.processQuery("tenantId", "siteNotes", Optional.of("priority==MEDIUM;category==category"), Optional.of("id,title,domainId"), Optional.of(1), 
			Optional.of(2), Optional.of("id"), Optional.of("DESC"), MediaType.APPLICATION_JSON_VALUE);
    	assertTrue(result.containsKey("direction"));
    	result = apiUtil.processQuery("tenantId", "site", Optional.of("priority==MEDIUM;category==category"), Optional.of("id,title,domainId"), Optional.of(1), 
			Optional.of(2), Optional.of("id"), Optional.of("DESC"), MediaType.APPLICATION_JSON_VALUE);
    	result = apiUtil.processQuery("tenantId", "caseNotes", Optional.of("priority==MEDIUM;category==category"), Optional.of("id,title,domainId"), Optional.of(1), 
			Optional.of(2), Optional.of("id"), Optional.of("DESC"), MediaType.APPLICATION_JSON_VALUE);

    	assertTrue(result.containsKey("pageSortKey"));
    	result = apiUtil.processQuery("tenantId", "assetNotes", Optional.of("priority==MEDIUM;category==category"), Optional.of("id,title,domainId"), Optional.of(1), 
			Optional.of(2), Optional.of("id"), Optional.of("DESC"), MediaType.APPLICATION_JSON_VALUE);

    	assertTrue(result.containsKey("pageSearchInx"));
    	result = apiUtil.processQuery("tenantId", "eventNotes", Optional.of("priority==MEDIUM;category==category"), Optional.of("id,title,domainId"), Optional.of(1), 
			Optional.of(2), Optional.of("id"), Optional.of("DESC"), MediaType.APPLICATION_JSON_VALUE);
    	
    	assertTrue(result.containsKey("pageSearchSize"));
    	result = apiUtil.processQuery("tenantId", "taskNotes", Optional.of("priority==MEDIUM;category==category"), Optional.of("id,title,domainId"), Optional.of(1), 
			Optional.of(2), Optional.of("id"), Optional.of("DESC"), MediaType.APPLICATION_JSON_VALUE);

    	assertTrue(result.containsKey("pageRequest"));
    	result = apiUtil.processQuery("tenantId", "taskNotes", Optional.of("priority==MEDIUM;category==category"), Optional.of("id,title,domainId"), Optional.of(1), 
			Optional.of(2), Optional.of("id"), Optional.of("DESC"), "");

    	assertTrue(result.containsKey("responseType"));
    	
    	result = apiUtil.processQuery("tenantId", "taskNotes", Optional.of("priority==MEDIUM;category==category"), Optional.of("id,title,domainId"), Optional.empty(), 
			Optional.empty(), Optional.of("id"), Optional.of("DESC"), MediaType.APPLICATION_JSON_VALUE);

    	result = apiUtil.processQuery("tenantId", "taskNotes", Optional.of("priority==MEDIUM;category==category"), Optional.of("id,title,domainId"), Optional.empty(), 
			Optional.empty(), Optional.of("id"), Optional.empty(), MediaType.APPLICATION_JSON_VALUE);
    	assertTrue(!result.get("direction").equals("ASC"));
    	
    	result = apiUtil.processQuery("tenantId", "", Optional.of("priority==MEDIUM;category==category"), Optional.of("id,title,domainId"), Optional.empty(), 
			Optional.empty(), Optional.empty(), Optional.empty(), MediaType.APPLICATION_JSON_VALUE);
    	assertTrue(result.get("pageSortKey").equals("id"));
    	
    }
	
	//helpers
	private JsonPatch getJsonPatch() {
    	JsonPatch jp = new JsonPatch();
    	com.ge.ren.attachments.model.patch.Attachment atts = new com.ge.ren.attachments.model.patch.Attachment("add", (AWS_PATH1+"dev"+AWS_PATH2)+"attachments", "test1.txt");
    	Patch patch = new Patch("add", "note", "new note value");
    	List<Patch> plist = new ArrayList<>();
    	plist.add(patch);
    	patch = new Patch("add", "validDateBy", "08/22/25 22:22:22");
    	plist.add(patch);
    	List<com.ge.ren.attachments.model.patch.Attachment> alist = new ArrayList<>();
    	alist.add(atts);
    	jp.setAttachments(alist);
    	jp.setPatch(plist);
    	return jp;
	}
	
	@Test
    public void determineNotesScopeFromCapabilitiesAndRolesTest() {
		String scopeAccess = apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor);
		assertTrue(scopeAccess.equals("both"));
		
		List<String> capabilitiesList = new ArrayList<>();
        capabilitiesList.add(Constants.NOTES_AND_ATTACHMENTS);
        List<String> roleList = new ArrayList<>();
        roleList.add("Field_Planner");
        when(requestInterceptor.getUserCapabilities()).thenReturn(capabilitiesList);
        when(requestInterceptor.getUserRoles()).thenReturn(roleList);
        
        String scopeAccess1 = apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor);
		assertTrue(scopeAccess1.equals("external"));
		
		List<String> capabilitiesList1 = new ArrayList<>();
        capabilitiesList1.add(Constants.INTERNAL_ACCESS);
        when(requestInterceptor.getUserCapabilities()).thenReturn(capabilitiesList1);
        when(requestInterceptor.getUserRoles()).thenReturn(roleList);
        String scopeAccess2 = apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor);
		assertTrue(scopeAccess2.equals("both"));
	}
	
	@Test
    public void checkScopeInPatchTest() {
		List<String> capabilitiesList = new ArrayList<>();
        capabilitiesList.add(Constants.NOTES_AND_ATTACHMENTS);
        List<String> roleList = new ArrayList<>();
        roleList.add("Field_Planner");
        when(requestInterceptor.getUserCapabilities()).thenReturn(capabilitiesList);
        when(requestInterceptor.getUserRoles()).thenReturn(roleList);
		List<Patch> patchList = new ArrayList<>();
		Patch patch = new Patch();
		patch.setOp("replace");
		patch.setPath("/scope");
		patch.setValue("internal");
		patchList.add(patch);
		boolean flag = apiUtil.checkScopeInPatch(patchList, requestInterceptor);
		assertTrue(flag);
	}
	@Test
	public void convertToISODateStringTest() {
		String squery="timestampu>='2021-10-25 01:20:30'";
		String isoString =apiUtil.convertToISODateString(squery);
		String expected ="timestampu>='2021-10-25T01:20:30.000Z'";
		assertEquals(expected, isoString);
	}
	
	@Test
	public void normalizeMillisTest() {
		String expected =apiUtil.normalizeMillis("");
		assertEquals(expected,".000" );
	}
}
