package com.ge.ren.notes.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ren.notes.utils.JacksonConfiguration;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

public class JacksonConfigurationTest {
    private MockMvc mockMvc;    



    HttpServletRequest  request = Mockito.mock(HttpServletRequest.class);    
	@Autowired 
	JacksonConfiguration jc  = new JacksonConfiguration();
	
    @Test
    public void jacksonConfTest() {
        ObjectMapper objectMapper = new ObjectMapper();
        jc.getOMconfiguration(objectMapper);
        assertNotNull(objectMapper);
        System.out.println("testjacksonConf... done ");
    }
    
    @Test
    public void JCResponseTest() throws IOException {
    	String result =  jc.getResponseBody(request);
    	assertNotNull(result);
    	System.out.println("test JC Respose done...  " + result);
    }
}
