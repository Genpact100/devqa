package com.ge.ren.attachments.service.impl;

import static com.ge.ren.notes.constants.Constants.AWS_PATH1;
import static com.ge.ren.notes.constants.Constants.AWS_PATH2;
import static com.ge.ren.notes.constants.Constants.PATCH;
import static com.ge.ren.notes.constants.Constants.POST;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Optional;

import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.data.mongo.AutoConfigureDataMongo;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultHandler;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.multipart.MultipartFile;

import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.amazonaws.util.IOUtils;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ren.attachments.dto.NoteBase;
import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.Attachments;
import com.ge.ren.attachments.model.GetAttachments;
import com.ge.ren.attachments.model.PostAttachment;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.model.patch.Patch;
import com.ge.ren.attachments.service.impl.AttachmentServiceImpl;
import com.ge.ren.attachments.utils.AwsUploader;
import com.ge.ren.attachments.utils.FileUploader;
import com.ge.ren.attachments.utils.PatchHelper;
import com.ge.ren.attachments.utils.Autils;
import com.ge.ren.notes.dto.AttachmentBase;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.PatchNote;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.model.SiteNotes;
import com.ge.ren.notes.constants.Priority;
import com.ge.ren.notes.constants.Scope;
import com.ge.ren.notes.constants.Status;
import com.ge.ren.notes.utils.ApiUtil;
import com.ge.ren.notes.utils.DateFormatMS;
import com.ge.ren.notes.utils.JacksonConfiguration;
import com.ge.ren.notes.utils.ValidateUtil;
import com.github.fge.jsonpatch.JsonPatchException;
import com.mongodb.client.result.DeleteResult;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest (classes = {AttachmentServiceImpl.class}, properties = {"bucket=attachments","descriptionSize=20", "titleSize=10", "storageType=fyleSystem", "searchLimit=1"}) 
 
@TestPropertySource(locations = "/application.properties") 
@TestInstance(Lifecycle.PER_CLASS)
//@RunWith(SpringRunner.class)

public class AttachmentsServiceTest {

    @MockBean
    WebApplicationContext webApplicationContext;
    
	@Rule
	public ExpectedException thrown = ExpectedException.none();

    @MockBean
    JacksonConfiguration jc;   
    
    @MockBean
    PatchHelper patchHelper;
    
    @MockBean
    ApiUtil apiUtil;

    @MockBean
    Autils utils;
    
    @MockBean
    FileUploader fileUploader;
    
    @MockBean
    AwsUploader awsUploader;
    
    @MockBean
    ObjectMapper objectMapper;

    @MockBean
 	MongoTemplate mongoTemplate;
    
    @MockBean
    DateFormatMS dateFormat;

    @Autowired
    AttachmentServiceImpl service;

	@Autowired
	private WebApplicationContext wac;

    static final String ROOT_URL = "/common/v1/attachments";

    String baseUrl;
    
    String queryString = "domainId==500023;domain==case";
    
	PostAttachment pn = new PostAttachment();
	Note attachment = new Note();
	NotesRequest noteR = new NotesRequest();

    @Value("${storageType}")
    private String s3Bucket;
    
    StringBuilder sb = new StringBuilder(); 
    
	@BeforeAll
    void setUp() throws IOException, JsonPatchException {
		System.setProperty("spring.profiles.active", "dev");
		MockitoAnnotations.initMocks(this);
        List<AttachmentData> attachments = new ArrayList<>();
		pn = new PostAttachment( "domainId","domainName","description","title",attachments);
	    when(jc.getOMconfiguration(any())).thenReturn(objectMapper);
		List<Note> notes = new ArrayList <>();
		when(apiUtil.getNotesByDomain(any(), any())).thenReturn(notes);
		when(dateFormat.getCurrentDateFormated()).thenReturn("01/01/22");
		List<AttachmentData> list = new ArrayList<>();
		when(fileUploader.uploadFiles( anyString(), any())).thenReturn(list);
		
		
		when(objectMapper.writeValueAsString(any())).thenReturn("{}");

		when(utils.compileBucketPath(anyString())).thenReturn("bucket");
		when(utils.getDescriptionSizeCheck(any(), anyString())).thenReturn(true);
		when(utils.getNotesByDomain(anyString())).thenReturn(true);
		when(utils.getTitleSizeCheck(any(), anyString())).thenReturn(true);
		when(utils.setPaginationMetadata(any(), any())).thenReturn(new GetAttachments());
		when(utils.validateForFileSize(any())).thenReturn(true);
		doNothing().when(utils).validateForFileType(any());
		when(utils.validatePathExists(any())).thenReturn(true);
		
		when(mongoTemplate.count(any(), anyString())).thenReturn(new Long(1));
		when(mongoTemplate.save(any(Attachment.class), anyString())).thenReturn(getAttachment());
		
		when(patchHelper.applyPatch(any(), anyString())).thenReturn(getAttachment());
    }

    @AfterAll
    void tearDown() throws IOException {
    }

    
    @BeforeEach
    public void setup() throws IOException, JsonPatchException {
    	List<AttachmentData> attachments = new ArrayList<>();
		pn = new PostAttachment( "domainId","domainName","description","title",attachments);
	    when(jc.getOMconfiguration(any())).thenReturn(objectMapper);
		List<Note> notes = new ArrayList <>();
		when(apiUtil.getNotesByDomain(any(), any())).thenReturn(notes);
		when(dateFormat.getCurrentDateFormated()).thenReturn("01/01/22");
		List<AttachmentData> list = new ArrayList<>();
		when(fileUploader.uploadFiles( anyString(), any())).thenReturn(list);
		
		
		when(objectMapper.writeValueAsString(any())).thenReturn("{}");

		when(utils.compileBucketPath(anyString())).thenReturn("bucket");
		when(utils.getDescriptionSizeCheck(any(), anyString())).thenReturn(true);
		when(utils.getNotesByDomain(anyString())).thenReturn(true);
		when(utils.getTitleSizeCheck(any(), anyString())).thenReturn(true);
		when(utils.setPaginationMetadata(any(), any())).thenReturn(new GetAttachments());
		when(utils.validateForFileSize(any())).thenReturn(true);
		doNothing().when(utils).validateForFileType(any());
		when(utils.validatePathExists(any())).thenReturn(true);
		
		when(mongoTemplate.count(any(), anyString())).thenReturn(new Long(1));
		when(patchHelper.applyPatch(any(), anyString())).thenReturn(getAttachment());
		
		when(mongoTemplate.find(any(), any())).thenReturn(new ArrayList<Object>());

		
		when(awsUploader.removeS3Object(anyString())).thenReturn(true);

		List<Attachment> listAt = new ArrayList<>();
		listAt.add(getAttachment());
	//	when(service.processUpdateLinks(anyString(), any(), any())).thenReturn(listAt);
    }
 
	@Test
	void NotesServiceBaseTest() throws Exception {
		System.out.println(">>>> get Notes Service Test start...  " + new Date() );
		Attachment attachment = getAttachment();
		assertTrue(!attachment.getCreatedBy().isEmpty());
		assertTrue(!attachment.getCreationDate().isEmpty());
		assertTrue(!attachment.getDomainId().isEmpty());
		assertTrue(!attachment.getId().isEmpty());
		assertTrue(!attachment.getDescription().isEmpty());
		assertTrue(!attachment.getTenantId().isEmpty());
		assertTrue(!attachment.getTitle().isEmpty());
		assertTrue(!attachment.getUpdateDate().isEmpty());
		assertTrue(!attachment.getUpdatedBy().isEmpty());

		assertTrue(null != attachment);
		assertFalse(attachment.toString().isEmpty());
		
        Optional<String> optionalStr = Optional.empty();
        Optional<Integer> optionalInt = Optional.empty();
        NotesRequest noteR = new NotesRequest();
        noteR.setDomain("sites");
        noteR.setDomainIds("domainIds");
        noteR.setFilter("id,title,note,domainId,category,updatedBy");
        noteR.setPageIdx(0);
        noteR.setPageSize(5);
        noteR.setTenantId("tenantId");
        noteR.setBody(attachment);
        noteR.setQuery("priority==MEDIUM;category==category");
        
        List<Note> noteL = new ArrayList<>();
        //get all

        log.info(">>>> Notes Request >>"+ noteR);
        assertTrue(null != service);

        try {
        	noteR.setBody(pn);
        	noteR.setPageSize(10);
        	SiteNotes sn = new SiteNotes();
        	sn.setId("id");
        	ResponseEntity<Object> value = new ResponseEntity<Object> ("1", HttpStatus.CREATED);

        	
        	assertTrue(null != value);
        	String id = "id";
            
            ResponseEntity<Object> idr = service.processDeleteRequest(noteR, SiteNotes.class);
            assertThat(!idr.getStatusCode().is2xxSuccessful() );

            String snote = service.processGetRequest("case", id, 0, 10, queryString, "attachments/");
            assertFalse(null == snote);
            
        } catch (NullPointerException e){
            assertThat(null == e);

        }catch(IOException ex) {
            assertThat(ex.getMessage().contains("IO")).isTrue();
        }
        //GET
        
        //get 1
        noteR.setDomainIds("domainIds");
        // get by domainid
        noteR.setId("id");
        //when(servicen.processGetRequest(noteR)).thenReturn(noteL.toString());
        //new ResponseEntity<Object>
        //when(service.processDeleteRequest(noteR, SiteNotes.class)).thenThrow(new ApiException("500", "error"));
        //POST
        //when(servicen.processPostRequest(noteR)).thenReturn(new ResponseEntity<> ( HttpStatus.OK)); //.thenReturn(new ResponseEntity<> (attachment.getId(), HttpStatus.OK) ); //.getStatusCode().is2xxSuccessful()); //.thenReturn(new ArrayList<>());
        //PATCH
        //when(servicen.processPatchRequest(noteR, SiteNotes.class)).thenReturn(new ResponseEntity<> ( HttpStatus.OK)); //.thenReturn(new ResponseEntity<> (attachment.getId(), HttpStatus.OK) ); //.getStatusCode().is2xxSuccessful()); //.thenReturn(new ArrayList<>());
        //DELETE
        //when(servicen.processDeleteRequest(noteR, SiteNotes.class)).thenReturn(new ResponseEntity<> ( HttpStatus.OK)); //.thenReturn(new ResponseEntity<> (attachment.getId(), HttpStatus.OK) ); //.getStatusCode().is2xxSuccessful()); //.thenReturn(new ArrayList<>());
        //doNothing().when(repository).delete(any());
        try {
	        ResponseEntity<Object> ret = service.processDeleteRequest(noteR, SiteNotes.class);
	        assertThat(null == ret).isFalse();
        }catch(ResourceNotValid e) {
        	 assertThat(e.getMessage().contains("Resource")).isTrue();
        }
        Optional<SiteNotes> sn = Optional.empty();
        System.out.println(" >>>> get Notes Service Test done...  " + new Date() );
	}
	
	@Test
	public void processUpdateAttachmentLinksTest() throws MalformedURLException {

		List<Attachment> list = new ArrayList<>();
		list.add(getAttachment());
		list = service.processUpdateLinks( "id", list, SiteNotes.class);
		assertTrue(!list.isEmpty());
		Assertions.assertThrows(ApiException.class, () -> {
			service.processUpdateLinks( null , null, null);
		});
	}

	
	@Test
	void requestNoteRequestTest() {
	    Optional<String> optionalStr = Optional.empty();
	    Optional<Integer> optionalInt = Optional.empty();
        NotesRequest noteR = new NotesRequest();
        NotesRequest r1 =  noteR;
        assertTrue(noteR.equals(r1));
		assertTrue(noteR.toString().length() > 0);
        noteR.setDomain("siteNotes");
        noteR.setDomainIds("domainIds");
        noteR.setFilter("id,title,note,domainId,category,updatedBy");
        noteR.setPageIdx(0);
        noteR.setPageSize(5);
        noteR.setTenantId("tenantId");
        noteR.setBody(attachment);
        noteR.setQuery("priority==MEDIUM;category==category");
		assertFalse(noteR.equals(new NotesRequest()));
        noteR = new NotesRequest("sites", null, "tenantId", null, null, "Dmitry");
		assertFalse(noteR.equals(new NotesRequest()));
		noteR = new NotesRequest("1","1","1","1", 1,1,new Object(), "1","1","1","1","1",1,null, null);
		assertFalse(noteR.equals(new NotesRequest()));
	}

	@Test
	public void processGetAttachmentTest() throws IOException {
		try {
			String ret = service.processGetRequest("case", "id", 0, 0, "domainId==500023", null);
			assertFalse(ret.isEmpty());
		}catch(NullPointerException e) {
			thrown.expect(NullPointerException.class);
		}
		
		//List<Attachment> processUpdateLinks(String id, List<Attachment> attachments, Class<T> entityClass) 
		//when(service.processUpdateLinks(anyString(), any(), any())).thenThrow(new ApiException("500", "Error"));
    	Assertions.assertThrows(NullPointerException.class, () -> {
    		service.processGetRequest(null);
    	});
	}
	
	@Test
	public void testProcessUpdateLinks(){
		List<Attachment> notes = new ArrayList<>();
		notes.add(getAttachment());
		List<Attachment> list = service.processUpdateLinks("id", notes, SiteNotes.class);
		assertFalse(list.isEmpty());
		List<Attachment> notes2 = new ArrayList<>();
		Attachment a = new Attachment();
		a = getAttachment();
		AttachmentData ad = new AttachmentData("attachments/test?X-Amz-Date=20220521.txt", "file/txt", "test?X-Amz-Date=20220521.txt");
		List<AttachmentData> lst = new ArrayList<>();
		lst.add(ad);
		a.setAttachments(lst);

		notes2.add(a);
		try {
			List<Attachment> list2 = service.processUpdateLinks("id", notes2, SiteNotes.class);
		}
		catch(RuntimeException e){

		}
	}
	
	@Test
	public void processPostAttachmentTest() throws IOException {
		noteR.setId("id");
		noteR.setDomain("attachment");
        try {
            ResponseEntity<?> ret = service.processPostRequest(noteR, null);
            assertFalse(ret.getBody().toString().isEmpty());
        }
        catch (ApiException e){
            assertThat(e.getMessage().contains("Note")).isFalse();
        }catch(Exception e) {
        	assertThat(null == e);
        }
    	//doNothing().when(validation).validateId(anyString(), anyString(), any());
        Optional<MultipartFile[]> optionalFile = Optional.empty();
        List ats = Arrays.asList(new Attachments());
		PostAttachment attachment = new PostAttachment(
				"domainId",
			    "domainName",
			    "description",
			    "title",
				ats);
	    noteR.setBody(attachment);
		try {
		    MockMultipartFile file = new MockMultipartFile(
		        "file", 
		        "hello.txt", 
		        MediaType.TEXT_PLAIN_VALUE, 
		        "Hello, World!".getBytes()
		      );

		    MultipartFile[] files = {file};
		    
		    //TODO Fix below
		}catch(ResourceNotValid e) {
			assertThat(e.getMessage().contains("Scope"));
		}
		
		PostAttachment pn = ((PostAttachment) noteR.getBody());
		pn.setTitle(ValidateUtil.validateForSpecChars(pn.getTitle(), "title"));
		pn.setDescription(ValidateUtil.validateForSpecChars(pn.getDescription(), "note"));
		noteR = null;
		try {
			ResponseEntity<?> ret = service.processPostRequest(noteR, null);	
		}catch(Exception e) {
			assertThat(null == e);
		}
		
		
		
		
		// validate for Error
        try {
        	//
        }
        catch(Exception ex) {
            assertThat(ex.getMessage().contains("NULL")).isTrue();
        }

		StringBuilder sb = new StringBuilder("aaa");
		PostAttachment pat = new PostAttachment(   
				null,  "domainName",  "description",  "title", ats);
		try {
			PostAttachment pa =  service.validatePostRequest(pat, getMultipartFiles().get(), POST);
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		try {
			PostAttachment pa =  service.validatePostRequest(pat, getMultipartFiles().get(), "patch");
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		pat.setDomainId("domainId");
		try {
			pat.setDomainName(null);
			PostAttachment pa =  service.validatePostRequest(pat, getMultipartFiles().get(), "post");
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}

		try {
			pat.setTitle("w");
			pat.setDomainName("domainName");
			pat.setDomainId("domainId");
			pat.setDescription("description");
			  
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		service.validatePostRequest(new PostAttachment(), getMultipartFiles().get(), "post");
	    	});        
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}


		try {

	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	        	PostAttachment pa =  new PostAttachment("id",  null,  "sb.toString",  "title", Arrays.asList(new AttachmentData()));
	    		service.validatePostRequest(pa, getMultipartFiles().get(), "post");
	    	});        
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		try {
			for(int i=0; i<2505; i++ ) {sb.append("1");	}
			pat.setDescription(sb.toString());

    		PostAttachment pa =  new PostAttachment("id",  "domain",  null,  "title", Arrays.asList(new AttachmentData("at", "data", "test1.txt")));
    		service.validatePostRequest(pa, getMultipartFiles().get(), "post");
		} catch(NullPointerException e) {
			thrown.expect(NullPointerException.class);
		}

		try {
			for(int i=0; i<250; i++ ) {
				sb.append("1");
			}
			pat.setDescription("Description");
			pat.setTitle(sb.toString());
    		service.validatePostRequest(getPost(), null, "patch");
		} catch(NullPointerException e) {
			thrown.expect(NullPointerException.class);
		}
		try {
			pat.setTitle("title");
		} catch(NullPointerException e) {
			thrown.expect(NullPointerException.class);
		}		

		when(mongoTemplate.save(any(Attachment.class), anyString())).thenReturn(getAttachment());
		when(jc.getOMconfiguration(any())).thenReturn( new ObjectMapper());
		Assertions.assertThrows(ApiException.class, () -> {	
			ResponseEntity<Object> o = service.processPostRequest(noteR, null);
			Attachment at = (Attachment) o.getBody();
			assertEquals(null, at.getTimestampc());
			assertEquals(null, at.getTimestampu());
			assertNotNull(o.getStatusCode());

		});
		Attachment a = getAttachment();
		
		Assertions.assertThrows(AttributeNotFound.class, () -> {	
			PostAttachment pa =  new PostAttachment("id",  "domain",  null,  null, Arrays.asList(new AttachmentData("at", "data", "test1.txt")));
			pa =  service.validatePostRequest(pa, null, "post");
			assertTrue(pa != null);
		});

		Assertions.assertThrows(AttributeNotFound.class, () -> {	
			PostAttachment pa =  new PostAttachment("id",  "domain",  null,  null, Arrays.asList(new AttachmentData("at", "data", "test1.txt")));
			pa =  service.validatePostRequest(pa, null, "patch");
			assertTrue(pa != null);
		});

	}
	
	

	@Test
	public void testPostAttachment() throws Exception {
          String jsonStr = "{" + "\"domainId\": \"500023\"," + "\"domainName\": \"case\"," + "\"description\": \"This placeholder is for Description\"," +"\"title\": \"text for title\"" + "}";
          MultipartFile multipartFile = new MockMultipartFile("test1.txt", "Hello World".getBytes());
          File file = new File("attachments/test1.txt");
          try (OutputStream os = new FileOutputStream(file)) {
              os.write(multipartFile.getBytes());
          }
          assertThat(FileUtils.readFileToString(file, "UTF-8"))
            .isEqualTo("Hello World");
          
          Resource fileResource = new ClassPathResource(
                  file.getPath());

          assertNotNull(fileResource);

          MockMultipartFile firstFile = new MockMultipartFile("attachments",fileResource.getFilename(), MediaType.MULTIPART_FORM_DATA_VALUE, fileResource.getInputStream());  
                      assertNotNull(firstFile);
          MockMultipartFile file2 = new MockMultipartFile("data", "filename.txt", "text/plain", "some xml".getBytes());
          ResultMatcher ok = MockMvcResultMatchers.status().isOk();  
          MockMultipartFile mockMultipartFile = new MockMultipartFile("file",file.getName(),
                  "text/plain", "test data".getBytes());

          MockHttpServletRequestBuilder builder =             MockMvcRequestBuilders.multipart(ROOT_URL).file(mockMultipartFile);
          assertTrue(file.exists());
          
	      	NotesRequest noteR = new NotesRequest();
	  		noteR.setDomainIds("500023,100001");
	  		noteR.setCreatedBy("createdBy");
	  		noteR.setUpdateDate("08/22/25 22:22:22");
	  		noteR.setCategory("category");
	  		noteR.setDomain("siteNotes");
	  		noteR.setId("1");
	        List ats = Arrays.asList(new Attachments());
	  		PostAttachment attachment = new PostAttachment(
  				"domainId",
  			    "domainName",
  			    "description",
  			    "title",
  			    null);
	  	    noteR.setBody(attachment);
	  	    try {
		  	  
				  Assertions.assertThrows(ApiException.class, () -> {
				  		service.processPostRequest(noteR, getMultipartFiles());
			      });
				  ResponseEntity<Object> res = service.processPostRequest(noteR, Optional.empty());
		          assertTrue(res.getBody() != null);
		          assertTrue(!res.getStatusCode().is2xxSuccessful());
		          assertTrue(((Attachment)res.getBody()).attachments.isEmpty());
		          

		          
		          res = service.processPostRequest(noteR, getMultipartFiles());
		          
		          res = service.processPostRequest(noteR, null);
		          
		          
		          file.delete();
		          MockMultipartFile filem = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
		  	      MockMultipartFile[] fileso = {filem};
				  Attachment note =  new Attachment(null,
							attachment.getDomainName(),
							attachment.getDomainId(),
							"TenantId",
							attachment.getTitle(),
							attachment.getDescription(),
							dateFormat.getCurrentDateFormated(),
							dateFormat.getCurrentDateFormated(),
							"getCreatedBy",
							"getUpdatedBy",
							new Timestamp(System.currentTimeMillis()),
							new Timestamp(System.currentTimeMillis()),
							ats);
				  
				  assertTrue(note != null);
				  note.setTimestampc(null);
				  assertNull(note.getTimestampc());
				  note.setTimestampu(null);
				  assertNull(note.getTimestampu());


	  	    }catch(ApiException e) {
	  	    	thrown.expect(ApiException.class);
	  	    }catch(RuntimeException e) {
	  	    	thrown.expect(RuntimeException.class);
	  	    }
	   }


		@Test
		public void deleteAttachmentTest() throws Exception {
			noteR.setId("id");
			noteR.setDomain("siteNotes");

			when(mongoTemplate.remove(any(), any(), anyString())).thenReturn(null);
			
			ResponseEntity<Object> id = service.processDeleteRequest(noteR, Attachment.class);
			assertFalse(id.getStatusCode().is2xxSuccessful());
			
			when(awsUploader.removeS3Object(anyString())).thenReturn(true);
	
			try {
				id = service.processDeleteRequest(null, SiteNotes.class);
				assertFalse(id.getStatusCode().is2xxSuccessful());
			}catch(Exception e) {
				assertFalse(null == e);
			}
			// verify error
			id = service.processDeleteRequest(noteR, SiteNotes.class);
			assertFalse(id.getStatusCode().is5xxServerError());
			
			Query query = new Query();
			query.addCriteria(Criteria.where("id").is(noteR.getId()));
			query.fields().include("deleted");
			
			when(mongoTemplate.findOne(any(), any())).thenReturn(getAttachment());
			id = service.processDeleteRequest(noteR, Attachment.class);
			
			assertNotNull(id.getBody());
			
			
			
			when(mongoTemplate.remove(any(), any(), anyString())).thenThrow(new ApiException("500", baseUrl)); 
			id = service.processDeleteRequest(noteR, Attachment.class);
			assertNotNull(id);
			when(awsUploader.removeS3Object(anyString())).thenReturn(true);
			Assertions.assertThrows(ApiException.class, () -> {
				when(mongoTemplate.remove(any(), any(), anyString())).thenReturn(null);
			});
			id = service.processDeleteRequest(noteR, Attachment.class);
			
			assertNotNull(id);
			
			
	
		}
		
		@Test
		public void processPatchRequestTest() throws JsonParseException, ApiException, IOException {
			try {

				ResponseEntity<Object> id = service.processPatchRequest(noteR, Attachments.class,  Optional.empty());
				assertFalse(id.getStatusCode().is2xxSuccessful());
				
		          noteR.setBody(getJsonPatch());
				  Assertions.assertThrows(ApiException.class, () -> {
				  		service.processPatchRequest(noteR, Attachments.class, getMultipartFiles());
			      });
			}catch(Exception e) {
				assertFalse(null == e);
			}
			
			when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(getAttachment());

	        Assertions.assertThrows(ApiException.class, () -> {
		        noteR = new NotesRequest();
		        noteR.setDomain("attachments");
		        noteR.setDomainIds("domainIds");
		        noteR.setFilter("id,title,note,domainId,category,updatedBy");
		        noteR.setPageIdx(0);
		        noteR.setPageSize(5);
		        noteR.setTenantId("tenantId");
		        noteR.setBody(getJsonPatch());
		        noteR.setQuery("priority==MEDIUM;category==category");
	        	service.processPatchRequest(noteR, Attachments.class, getMultipartFiles());
	        });
	        
	        when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(null);
	        ResponseEntity<Object> res = service.processPatchRequest(noteR, Attachments.class, getMultipartFiles());
	        assertTrue(res.getBody() != null);
	        when(awsUploader.removeS3Object(anyString())).thenReturn(true);
	        
	        noteR.setBody(getJsonPatch());




			when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(getAttachment());

			Assertions.assertThrows(ApiException.class, () -> {
				noteR = new NotesRequest();
				noteR.setDomain("attachments");
				noteR.setDomainIds("domainIds");
				noteR.setFilter("id,title,note,domainId,category,updatedBy");
				noteR.setPageIdx(0);
				noteR.setPageSize(5);
				noteR.setTenantId("tenantId");
				noteR.setBody(getJsonPatch());
				noteR.setQuery("priority==MEDIUM;category==category");
				noteR.setBody(getJsonPatch());
				service.processPatchRequest(noteR, Attachments.class, getMultipartFiles());
			});
			// res = service.processPatchRequest(noteR, Attachments.class, getMultipartFiles());
		}
	
		@Test
		public void processGetRequestTest() throws JsonParseException, ApiException, IOException {
			noteR = new NotesRequest();
			when(mongoTemplate.count(any(), anyString())).thenReturn((long) 1);
			when(mongoTemplate.find(any(), any())).thenReturn(new ArrayList<Object>());
			
			
			noteR.setDomainIds("500023");
			noteR.setCreatedBy("createdBy");
			noteR.setBody("500023");
			noteR.setUpdateDate("2025-08-02T11:11:11.555Z");
			noteR.setCategory("category");
			noteR.setDomain("siteNotes");
			noteR.setId("id");
			noteR.setTenantId("tenantId1");
			String resp = null;
			try {


				resp = service.processGetRequest(noteR);
				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
				assertFalse(resp.isEmpty());
			}catch(Exception e) {
				assertFalse(null == e);
			}
			
			noteR.setQuery("category==category;priority==HIGH");
			try {
				resp = service.processGetRequest(noteR);
				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
			}catch(Exception e) {
				assertFalse(null == e);
			}
	
			try {
				resp = service.processGetRequest(noteR);
				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
			}catch(Exception e) {
				assertFalse(null == e);
			}
			try {
	
				noteR.setDomainIds("500023");
				resp = service.processGetRequest(noteR);
				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
				assertFalse(resp.isEmpty());
			}catch(NullPointerException e) {
				thrown.expect(NullPointerException.class);
				//throw new  ResourceNotValid("spec Chars included");
			}
	
			try {
				noteR.setDomainIds(null);
				resp = service.processGetRequest(noteR);
				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
			}catch(Exception e) {
				assertFalse(null == e);
			}
			try {
				noteR.setCreatedBy(null);
				resp = service.processGetRequest(noteR);
				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
			}catch(Exception e) {
				assertFalse(null == e);
			}
	
			noteR.setBody(null);
			try {
				resp = service.processGetRequest(noteR);
				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
			}catch(Exception e) {
				assertFalse(null == e);
			}
			noteR.setUpdateDate(null);
			try {
				resp = service.processGetRequest(noteR);
				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
			}catch(Exception e) {
				assertFalse(null == e);
			}
			try {
				noteR.setCategory(null);
				resp = service.processGetRequest(noteR);
				resp =service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
				
				assertFalse(resp.isEmpty());
				noteR.setQuery(null);

				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
				resp = service.processGetRequest(noteR);
			}catch(Exception e) {
				assertFalse(null == e);
			}
			Query query = new Query();
			query.fields().exclude("timestampc").exclude("timestampu");

			try {
				noteR = new NotesRequest();
				noteR.setTenantId("tenantId");
				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
				resp = service.processGetRequest(noteR);
				assertTrue(resp != null);
				resp = service.processGetRequest("case", null, 0, 10, queryString, "attachments/");
				resp = service.processGetRequest(noteR);
				assertTrue(resp != null);
			}catch(Exception e) {
				assertFalse(null == e);
			}
			try {

				Query query2 = new Query();
				query2.fields().exclude("timestampc").exclude("timestampu");
				when(apiUtil.getCriteriaFromQueryParser(anyString(), any())).thenReturn(query2);
				List<Attachment> listAt = new ArrayList<>();
				listAt.add(getAttachment());
		//		when(service.processUpdateLinks(anyString(), any(), any())).thenReturn(listAt);
				noteR.setFilter("id,title,note,domainId,category,updatedBy");
				resp = service.processGetRequest(noteR);
				resp = service.processGetRequest("case", "id", 0, 10, queryString, "attachments/");
			//	assertFalse(resp.isEmpty());
			}catch(Exception e) {
				assertFalse(null == e);
			}
			
		}
	
	
		@Test
		public void postAttachmentTest() {
			noteR = new NotesRequest();
			noteR.setBody(new PostNote());
	
			PostNote pn = new PostNote();
			pn.setCategory("category");
			pn.setDomainId("domainId");
			pn.setNote("note");
			pn.setPriority("priority");
			pn.setScope("scope");
			pn.setStatus("status");
			pn.setTitle("title");
			pn.setValidDateBy("validDateBy");
			pn.getCategory();
			pn.getDomainId();
			pn.getNote();
			pn.getPriority();
			pn.getScope();
			pn.getStatus();
			pn.getTitle();
			pn.getValidDateBy();
			PostNote pn1 = pn;
			assertTrue(pn.equals(pn1));
			pn = new PostNote("1","1","1","1","1","1","1","1", new ArrayList<AttachmentData>());
			assertFalse(pn.equals(pn1));
			
			assertTrue(pn.toString().length() != 0);
			pn.setTitle(ValidateUtil.validateForSpecChars(pn.getTitle(), "title"));
			pn.setNote(ValidateUtil.validateForSpecChars(pn.getNote(), "note"));
			Note note = new Note();
				  note.setDomainId(pn.getDomainId()); note.setTenantId("tenantId"); note.setTitle(pn.getTitle()); note.setNote(pn.getNote()); note.setCreationDate(dateFormat.getCurrentDateFormated()); note.setUpdateDate(dateFormat.getCurrentDateFormated());  note.setValidDateBy(pn.getValidDateBy()); note.setPriority(((null != pn.getPriority()) ? pn.getPriority(): Priority.LOW.toString() )); note.setCreatedBy("503206931"); note.setUpdatedBy("503206931"); note.setCategory(pn.getCategory());  note.setStatus(((null != pn.getStatus()) ? pn.getStatus(): Status.active.toString())); note.setScope(((null != pn.getScope()) ? pn.getScope(): Scope.internal.toString()));  note.setDeleted(Boolean.FALSE);  note.setTimestampc(new Timestamp(System.currentTimeMillis()));  note.setTimestampu(new Timestamp(System.currentTimeMillis()));
		}
			
			
	    @org.junit.jupiter.api.Test 
		public void processNewFieldsPatchTest() throws IOException {
	    	NotesRequest noteR = new NotesRequest();
			noteR.setDomainIds("500023,100001");
			noteR.setCreatedBy("createdBy");
			noteR.setUpdateDate("08/22/25 22:22:22");
			noteR.setCategory("category");
			noteR.setDomain("siteNotes");
			noteR.setId("1");
	        List ats = Arrays.asList(new Attachments());
			PostAttachment attachment = new PostAttachment(
					"domainId",
				    "domainName",
				    "description",
				    "title",
					ats);
		    noteR.setBody(getJsonPatch());
	    	Update update = new Update();
	    	ResponseEntity<Object> resp = null;
	    	try {
	    		resp = service.processPatchRequest(noteR, Attachment.class,  getMultipartFiles());
	    		assertTrue(resp.getStatusCode().is4xxClientError());
	    	} catch (Exception e){
	            assertEquals(e.getMessage(), "argument \"content\" is null");
	    	}
	    	try {
	    		resp = service.processPatchRequest(noteR, Attachment.class,  getMultipartFiles());
	    	} catch (Exception e){
	            assertNotNull(e.getMessage());
	    	}
	    	
	    	try {
		    	attachment.setDomainId(null);
		    	noteR.setBody(attachment);
		
		    	resp = service.processPatchRequest(noteR, Attachment.class,  getMultipartFiles());
		    	assertTrue(resp.getStatusCode().is4xxClientError());
	    	} catch (Exception e){
	            assertNotNull(e.getMessage());
	    	}
	
	
	    	update = service.validateAttachmentFields(getAttachment());
	    	assertTrue(update.getUpdateObject().size() > 0);
	    	
	    	pn = new PostAttachment();
	    	pn.setTitle("title");
	    	noteR.setBody(pn);
	    	update = service.validateAttachmentFields(getAttachment());
	    	assertTrue(!update.getUpdateObject().isEmpty());
	
	    	pn.setDescription("note");
	    	noteR.setBody(pn);
	    	try {
		    	resp = service.processPatchRequest(noteR, Attachment.class,  getMultipartFiles());
		    	assertTrue(resp.getStatusCode().is4xxClientError());
		    	update = service.validateAttachmentFields(getAttachment());
		    	assertTrue(!update.getUpdateObject().isEmpty()); //.getString("value").contains("note"));
		    
		    	pn.setDomainId("500023");
		    	pn.setDomainName(null);
		    	noteR.setBody(pn);
				System.out.println("update.getUpdateObject() -> "+ update.getUpdateObject().toString());
		    	resp = service.processPatchRequest(noteR, Attachment.class,  getMultipartFiles());
		    	assertTrue(resp.getStatusCode().is4xxClientError());
		    	update = service.validateAttachmentFields(getAttachment());
		    	assertTrue(!update.getUpdateObject().isEmpty()); //.toJson().contains("priority"));
		
		    	
		    	pn.setDomainName("case");
		    	pn.setDescription(null);
		    	noteR.setBody(pn);
		    	resp = service.processPatchRequest(noteR, Attachment.class,  getMultipartFiles());
		    	assertTrue(resp.getStatusCode().is4xxClientError());
		    	update = service.validateAttachmentFields(getAttachment());
		    	assertTrue(!update.getUpdateObject().isEmpty());
		    	
		
		    	assertTrue(!update.getUpdateObject().isEmpty());
		    	
				noteR.setBody(getJsonPatch());
					ResponseEntity<Object> id = service.processPatchRequest(noteR, Attachment.class,  Optional.empty());
					assertTrue(id.getBody()!= null);

				
				
				//Adding Patch cover
				AttachmentData ad = new AttachmentData("text/txt","attachments/test1.txt", "test1.txt");
				List<AttachmentData> list = new ArrayList<>();
				list.add(ad);
				Attachment note = getAttachment();
				note.setAttachments(list);
				when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(note);
					id = service.processPatchRequest(noteR, Attachment.class,  Optional.empty());
					assertNotNull(id.getBody());

					noteR = getNoteRequest(); noteR.setBody(null);
					id = service.processPatchRequest(noteR, Attachment.class,  Optional.empty());
					assertNotNull(id.getBody());
				
				when(awsUploader.removeS3Object("attachments/test1.txt")).thenReturn(true);
					noteR.setBody(getJsonPatch());
					ResponseEntity<Object> i = service.processPatchRequest(noteR, Attachment.class,  Optional.empty());
					assertNotNull(i.getBody());

				when(awsUploader.removeS3Object("attachments/test1.txt")).thenReturn(false);
					noteR.setBody(getJsonPatch());
					i = service.processPatchRequest(noteR, Attachment.class,  Optional.empty());
					assertNotNull(i.getBody());
				
				when(awsUploader.removeS3Object("attachments/test1.txt")).thenThrow(ApiException.class);
					noteR.setBody(getJsonPatch());
					i = service.processPatchRequest(noteR, Attachment.class,  Optional.empty());
					assertNotNull(i.getBody());
				
				when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(null);
					id = service.processPatchRequest(noteR, Attachment.class,  Optional.empty());
					assertNotNull(id.getBody());

				
				noteR.setBody(getJsonPatch());
				when(apiUtil.removeLinks(any(), any())).thenReturn(new ArrayList<AttachmentData>());
				id = service.processPatchRequest(noteR, Attachment.class,  Optional.empty());
				assertNotNull(id.getBody());
			
				when(mongoTemplate.findOne(any(), any(), anyString())).thenThrow(RuntimeException.class);
				Assertions.assertThrows(ApiException.class, () -> {
					service.processPatchRequest(getNoteRequest(), Attachment.class,  Optional.empty());
				});
	       	} catch (Exception e){
	            assertFalse(null == e.getMessage());
	    	}    	
	    }
	    //Validate PATCH request:
		@Test
		public void validatePatchRequestTest() throws JsonMappingException, JsonProcessingException {
			// at = null;
			Assertions.assertThrows(ResourceNotValid.class, () -> {		
				Attachment at = service.validatePatchRequest(getAttachment(), getMultipartFile(), "post");
	    		assertNotNull(at.getDomainName());
	    		assertTrue(at.getDescription().contains("d"));
	    		assertNotNull(at.getTitle());
	    	});

			Attachment at = getAttachment(); 
			at.setDescription(null);
			Assertions.assertThrows(ResourceNotValid.class, () -> {
				Attachment ats = getAttachment(); 
				ats.setDescription(null);
				ats = service.validatePatchRequest(ats, getMultipartFile(), "patch");
			});
			Assertions.assertThrows(ResourceNotValid.class, () -> {
				Attachment ats = getAttachment(); 
				ats.setDescription(null);
				ats = service.validatePatchRequest(at, getMultipartFile(), "post");
			});
			
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		final Attachment a = getAttachment();
	    		a.setDescription("##");
	    		service.validatePatchRequest(a, getMultipartFile(), "post");
	    	});
	    	
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		final Attachment a = getAttachment();
	    		a.setDescription("##");
	    		service.validatePatchRequest(a, getMultipartFile(), "patch");
	    	});
		    for(int i=0; i<2505; i++ ) {
				sb.append("1");
			}
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		Attachment a = getAttachment();
	    		a.setDescription(sb.toString());
	    		service.validatePatchRequest(a, getMultipartFile(), "post");
	    	});
	    	
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		Attachment a = getAttachment();
	    		a.setDescription(sb.toString());
	    		service.validatePatchRequest(a, getMultipartFile(), "patch");
	    	});

	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		Attachment a = getAttachment();
	    		a.setDescription("d");
	        	a.setTitle(sb.toString());
	        	service.validatePatchRequest(a, getMultipartFile(), "post");
	    	});
	    	
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		Attachment a = getAttachment();
	    		a.setDescription("d");
	        	a.setTitle(sb.toString());
	        	service.validatePatchRequest(a, getMultipartFile(), "patch");
	    	}); 
	    	
	    	//spec chars
	       	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		Attachment a = getAttachment();
	    		a.setDescription("d");
	        	a.setTitle("##");
	        	service.validatePatchRequest(a, getMultipartFile(), "post");
	    	});
	    	
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		Attachment a = getAttachment();
	    		a.setDescription("d");
	        	a.setTitle("##");
	        	service.validatePatchRequest(a, getMultipartFile(), "patch");
	    	});   	
	    	
    
	       	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		Attachment a = getAttachment();
	    		a.setDescription(null);
	        	a.setTitle(null);
	        	a.setAttachments(null);
	        	service.validatePatchRequest(a, null, "post");
	    	});
	    	
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		Attachment a = getAttachment();
	       		a.setDescription(null);
	        	a.setTitle(null);
	        	service.validatePatchRequest(a, null, "patch");
	    	});  
	    	
	    	//Addition
	    	StringBuilder sb = new StringBuilder();
	    	for(int i=0; i<2505; i++ ) {sb.append("1");}
	    	Attachment a = getAttachment();
	    	a.setDomainId(null);
    		try {
    			service.validatePatchRequest(a, getMultipartFile(), POST); 
    		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
    			thrown.expect(ResourceNotValid.class);
    		}
    		a = getAttachment();
    		a.setDomainName("domainName");
	    	try {
    			service.validatePatchRequest(a, getMultipartFile(), POST); 
 
	    	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    	   			Attachment ab = getAttachment();
	        			ab.setTitle(null);
	    	    		service.validatePatchRequest(ab, null, POST);
	    	    	});
	    			
	    	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    	   			Attachment ab = getAttachment();
	        			ab.setTitle(null);
	    	    		service.validatePatchRequest(ab, null, PATCH);
	    	    	});
	    	    	
	    	    	//Assertions.assertThrows(ResourceNotValid.class, () -> {
	    	    	assertTrue(!ValidateUtil.validateForSpecChars("#$%", "title").isEmpty());
	    	    		
	    	    	//});

	    		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
	    			thrown.expect(ResourceNotValid.class);
	    		} catch(AttributeNotFound e) {
	    	        thrown.expect(AttributeNotFound.class);
	    		} catch(Exception e) {
	    			thrown.expect(Exception.class);
	    		}
	    		try {
	    			// title missing
	    			a.setTitle("");
	    			service.validatePatchRequest(a, getMultipartFile(), POST);
	    		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
	    			thrown.expect(AttributeNotFound.class);

	    		}
	    		try {
	    			a.setTitle("title");
	    		}catch(ResourceNotValid e) {
	    			thrown.expect(ResourceNotValid.class);
	    			//throw new  ResourceNotValid("spec Chars included");
	    		}
	    			
	    		service.validatePatchRequest(a, getMultipartFile(), POST);
	    		try {
	    			a.setDescription("note#");
	    			ValidateUtil.validateForSpecChars(a.getDescription(), "attachment");
	    		}catch(ResourceNotValid e) {
	    			thrown.expect(ResourceNotValid.class);
	    		}
	    		
	    		try {
	    			a.setDescription(" ");
	    			service.validatePatchRequest(a, getMultipartFile(), POST); 
	    		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
	    			thrown.expect(ResourceNotValid.class);
	    		}


	    		try {
	    			a.setDescription(sb.toString());
	    			service.validatePatchRequest(a, getMultipartFile(), POST); 
	    		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
	    			thrown.expect(ResourceNotValid.class);
	    		}
	    		a.setDescription("note");
	            a.setTitle(sb.toString());
	    		try {
	    			service.validatePatchRequest(a, getMultipartFile(), POST); 
	    		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
	    			thrown.expect(ResourceNotValid.class);
	    		}
	    		a.setTitle("#");
	            try {
	    			ValidateUtil.validateForSpecChars(a.getTitle(), "title");
	    			service.validatePatchRequest(a, getMultipartFile(), POST);
	            } catch(ResourceNotValid e) {
	    	        thrown.expect(ResourceNotValid.class);
	            }
	            try {
	            	service.validatePatchRequest(a, getMultipartFile(), PATCH);
	                a.setTitle(sb.toString());
	                service.validatePatchRequest(a, getMultipartFile(), PATCH);
	            }catch(ResourceNotValid e) {
	            	thrown.expect(ResourceNotValid.class);
	            }
	            a.setTitle("title");
	    		try {
	    			service.validatePatchRequest(a, getMultipartFile(), PATCH);
	            }catch(ResourceNotValid e) {
	            	thrown.expect(ResourceNotValid.class);
	            }

	            try {
	    			service.validatePatchRequest(a, getMultipartFile(), POST);        	
	            }catch(ResourceNotValid e) {
	            	thrown.expect(ResourceNotValid.class);
	            }
	            
        	
	        	// test files:
	            try {
	            	Assertions.assertThrows(ResourceNotValid.class, () -> {
	            		Attachment ab = getAttachment();
	            		ab.setDescription(null);
	            		ab.setTitle(null);
		    			service.validatePatchRequest(ab, null, POST);
	            	});
	            }catch(ResourceNotValid e) {
	            	thrown.expect(ResourceNotValid.class);
	            }
	        	
	            try {
	            	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    	   			Attachment ab = getAttachment();
	    	   			ab.setDescription(null);
	        			ab.setTitle(null);
		    			service.validatePatchRequest(ab, null, PATCH);
	            	});
	            }catch(ResourceNotValid e) {
	            	thrown.expect(ResourceNotValid.class);
	            }

		}

	    @org.junit.jupiter.api.Test 
	    public void validateFieldsTestNew() throws Exception {
		   	SiteNotes note =  new SiteNotes();
		   	NotesRequest noteR = new NotesRequest();
				noteR.setDomainIds("500023,100001");
				noteR.setCreatedBy("createdBy");
				noteR.setUpdateDate("08/22/25 22:22:22");
				noteR.setCategory("category");
				noteR.setDomain("siteNotes");
				noteR.setId("1");
		   	PatchNote pn = new PatchNote(
		   			"title",
		   			"note",
		   		    "HIGH",
		   		    "category",
		   		    "internal",
		   		    "active",
		   		    null,
		   		    "updatedBy",
		   		    new ArrayList<AttachmentData>());
		   	Update update = new Update();
		   	
		   	noteR.setDomainIds("500203");
		   	//getJsonPatch()
		   	noteR.setBody(getJsonPatch());
		   	update = service.validateNewFields(getNote());
		   	//when(validateUtil.validateNewFields(noteR)).thenReturn(update);
		   	assertTrue(update.getUpdateObject().size() > 0);
		   	
		   	noteR.setBody(getJsonPatch());
		   	update = service.validateNewFields(getNote());
		   	assertTrue(!update.getUpdateObject().isEmpty());

		   	//update.set("note", "note"); 
				//when(validateUtil.validateNewFields(noteR)).thenReturn(update);
		   	noteR.setBody(getJsonPatch());
		   	update = service.validateNewFields(getNote());
		   	assertTrue(!update.getUpdateObject().isEmpty()); 

		   	noteR.setBody(getJsonPatch());
		   	//update.set("priority", "HIGH");
				//when(validateUtil.validateNewFields(noteR)).thenReturn(update);
				System.out.println("update.getUpdateObject() -> "+ update.getUpdateObject().toString());
		   	update = service.validateNewFields(getNote());
		   	assertTrue(!update.getUpdateObject().isEmpty()); //.toJson().contains("priority"));

		   	
		   	noteR.setBody(getJsonPatch());
		   	update.set("category", "category");
		   	update = service.validateNewFields(getNote());
				//when(validateUtil.validateNewFields(noteR)).thenReturn(update);
		   	//assertTrue(update.getUpdateObject().toJson().contains("category"));
		   	assertTrue(!update.getUpdateObject().isEmpty());
		   	
		   	JsonPatch jp = getJsonPatch();
		   	List<Patch> lp = new ArrayList<>();
		   	lp.add(new Patch("add", "/scope", "internal"));
		   	jp.setPatch(lp);
		   	noteR.setBody(jp);
		   	update = service.validateNewFields(getNote());
		   	assertTrue(!update.getUpdateObject().isEmpty());

	    	JsonPatch jps = getJsonPatch();
	    	List<Patch> lps = new ArrayList<>();
	    	lp.add(new Patch("replace", "/scope", "Wrong"));
	    	jp.setPatch(lp);
	    	NotesRequest noter = new NotesRequest();
			noter.setDomainIds("500023");
			noter.setCreatedBy("createdBy");
			noter.setUpdateDate("08/22/25 22:22:22");
			noter.setDomain("siteNotes");
			noter.setId("1");
	    	noter.setBody(jps);
		   	update = service.validateNewFields(getNote());
		   	assertTrue(!update.getUpdateObject().isEmpty());

		   	noteR.setBody(getJsonPatch());
		   	update = service.validateNewFields(getNote());
		   	assertTrue(!update.getUpdateObject().isEmpty());
		   	
		   	//PostNote
		   	PostNote pon = new PostNote();
		   	pon.setAttachments(null);
		   	assertTrue(null == pon.attachments);
		   	List ats = Arrays.asList(new Attachments());
		   	pon.setAttachments(ats);
		   	assertTrue(null != pon.attachments);
		   	//Note Request
		   	MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
		   	noteR = new NotesRequest("domain", "domainIds", "tenantId", "body", "id", "createdBy",  file);
		   	
		   	assertTrue(noteR.getFile().getBytes().length > 0 );
		   	assertNotNull(noteR);
		   	NoteBase not = new NoteBase();
		   	update = service.validateNewFields(not);
		   	assertTrue(update.getUpdateObject() != null);
		   	
		   }
		   	    
	    
		//helpers
		private Optional<MultipartFile[]> getOptionalFiles() {
		    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
		    MockMultipartFile[] fileso = {file};
		    Optional<MultipartFile[]> files = Optional.of(fileso);
		    return files;
		}
		private Optional<MultipartFile[]> createMultipartFile() throws IOException {
			File file = new File("src/main/resources/attachments/test-image.png");
			FileInputStream input = new FileInputStream(file);
			MultipartFile multipartFile = new MockMultipartFile("file",
			            file.getName(), "text/plain", IOUtils.toByteArray(input));
			MultipartFile[] mf = {multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, 
					multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile,
					multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile};
			Optional<MultipartFile[]> mfo = Optional.of(mf);
			return mfo;  
		}
	    

	    
		private Optional<MultipartFile[]> getMultipartFiles() {
		    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
		    MockMultipartFile[] fileso = {file};
		    Optional<MultipartFile[]> files = Optional.of(fileso);
		    return files;
		}
		
	    private Attachment getAttachment() {
	    	Attachment attachment = new Attachment();
			attachment.setCreatedBy("createdBy");
			attachment.setCreationDate("creationDate");
			attachment.setDescription("description");
			attachment.setDomainId("domainId");
			attachment.setId("id");
			attachment.setTenantId("tenantId");
			attachment.setTitle("title");
			attachment.setUpdateDate("updateDate");
			attachment.setUpdatedBy("updatedBy");
			List<AttachmentData> list = new ArrayList<>();
			AttachmentData ad = new AttachmentData("attachments/test1.txt", "file/txt", "test1.txt");
			list.add(ad);
			attachment.setAttachments(list);
	    	return attachment;
	    }
	    public static String asJsonString(final Note notes) {
	    	try {
	    		return new ObjectMapper().writeValueAsString(notes);
	    	} catch (Exception e) {
	    		throw new RuntimeException(e);
	    	}
	    }
	    public static String attachmentToString(final  Attachment at) {
	    	try {
	    		return new ObjectMapper().writeValueAsString(at);
	    	} catch (Exception e) {
	    		throw new RuntimeException(e);
	    	}
	    }
	    
	    private NoteBase getNote() {
	    	NoteBase note = new NoteBase();
			note.setNoteCategory("category");
			note.setNoteCreatedBy("createdBy");
			note.setNoteCreationDate("creationDate");
			note.setNoteDeleted(false);
			note.setNoteDomainId("domainId");
			note.setId("id");
			note.setNote("note");
			note.setNotePriority("priority");
			note.setNoteScope(Scope.internal.toString());
			note.setNoteStatus("active");
			note.setTenantId("tenantId");
			note.setNoteTitle("title");
			note.setNoteUpdateDate("updateDate");
			note.setNoteUpdatedBy("updatedBy");
			note.setNoteValidDateBy("validDateBy");
			note.setNoteTimestampc(new Timestamp(new Date().getTime()));
			note.setNoteTimestampu(new Timestamp(new Date().getTime()));
			note.setAttachments(new ArrayList<AttachmentData>());
	    	return note;
	    }	
	    
	    private PostAttachment getPost() {
		    	return new PostAttachment("id",  "domainName",  "sb.toString",  "title", Arrays.asList(new AttachmentData()));
	    }
        // make text-part using MockMultipartFile
		private MockMultipartFile makeMultipartTextPart(String requestPartName, String value, String contentType) throws Exception {
		       return new MockMultipartFile(requestPartName, "", contentType,
		               value.getBytes(Charset.forName("UTF-8")));   
		}

		private byte[] readResourceFile(String pathOnClassPath) throws Exception {
		      return Files.readAllBytes(Paths.get(Thread.currentThread().getContextClassLoader()
		         .getResource(pathOnClassPath).toURI()));
		}
		private JsonPatch getJsonPatch() {
	    	JsonPatch jp = new JsonPatch();

	    	com.ge.ren.attachments.model.patch.Attachment atts = new 
	    			com.ge.ren.attachments.model.patch.Attachment("add", (AWS_PATH1+System.getenv("spring.profiles.active")+AWS_PATH2)+"attachments", "test1.txt");
	    	Patch patch = new Patch("add", "note", "new note value");
	    	List<Patch> plist = new ArrayList<>();
	    	plist.add(patch);
	    	List<com.ge.ren.attachments.model.patch.Attachment> alist = new ArrayList<>();
	    	alist.add(atts);
	    	jp.setAttachments(alist);
	    	jp.setPatch(plist);
	    	return jp;
		}
		
		private MultipartFile[] getMultipartFile() {
		    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
		    MockMultipartFile[] fileso = {file};
		    return fileso;
		}
		
		private NotesRequest getNoteRequest() {
	        NotesRequest noteR = new NotesRequest();
	        noteR.setDomain("case");
	        noteR.setDomainIds("domainIds");
	        noteR.setFilter("id,title,note,domainId");
	        noteR.setPageIdx(0);
	        noteR.setPageSize(5);
	        noteR.setTenantId("tenantId");
	        noteR.setBody(getJsonPatch());
	        noteR.setQuery("priority==MEDIUM;category==category");
	        return noteR;
		}
}
