package com.ge.ren.notes.rqe.conversions.parsers;


import com.github.rutledgepaulv.rqe.conversions.parsers.StringToObjectBestEffortConverter;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.Assert.assertEquals;
@SpringBootTest(classes =StringToObjectBestEffortConverter.class)
//@AutoConfigureMockMvc
public class StringToObjectBestEffortConverterTest {

    private static final StringToObjectBestEffortConverter it = new StringToObjectBestEffortConverter();

    @Test
    public void itConvertsBooleans() throws Exception {
        assertEquals(true, it.convert("true"));
        assertEquals(false, it.convert("false"));
    }

    @Test
    public void itConvertsLongs() throws Exception {
        assertEquals(1L, it.convert("1"));
        assertEquals(1111L, it.convert("1111"));
        assertEquals(-10L, it.convert("-10"));
    }

    @Test
    public void itConvertsDoubles() throws Exception {
        assertEquals(30.1, it.convert("30.1"));
        assertEquals(3.1415926, it.convert("3.1415926"));
        assertEquals(-1113333.111, it.convert("-1113333.111"));
    }

    @Test
    public void itConvertsDatesInIsoFormat() throws Exception {
        Instant inst = Instant.EPOCH.plus(35, ChronoUnit.HOURS).plus(3, ChronoUnit.DAYS);
        Instant inst2 = Instant.EPOCH.plus(35, ChronoUnit.MINUTES).plus(3, ChronoUnit.HALF_DAYS);
        Instant now = Instant.now();
        assertEquals(inst, it.convert("1970-01-05T11:00:00Z"));
        assertEquals(inst2, it.convert("1970-01-02T12:35:00Z"));
        assertEquals(now, it.convert(now.toString()));
    }

    @Test
    public void ifItCantConvertToSomethingElseItJustReturnsTheString() throws Exception {
        assertEquals("test", it.convert("test"));
        assertEquals("alpha", it.convert("alpha"));
        assertEquals("pig", it.convert("pig"));
    }

}
