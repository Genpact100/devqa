package com.ge.ren.notes.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.common.keycloak.exception.TokenVerifyException;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.constants.Constants;
import com.ge.ren.notes.constants.Scope;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.service.impl.NotesServiceImpl;
import com.ge.ren.notes.utils.ApiUtil;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest (classes = NotesApiController.class)
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@EnableWebMvc
public class NotesApiControllerTest extends  AbstractTest{
    private String DOMAIN_SERVICE = "/common/v1";
    
    @Autowired
    private MockMvc mockMvc;
    
	@MockBean
    NotesServiceImpl service;

    @MockBean
	RequestInterceptor requestInterceptor;
    @MockBean
    ApiUtil apiUtil;

    ObjectMapper objectMapper = new ObjectMapper(); 

	Note notes = new Note();
	NotesRequest noteRequest = new NotesRequest();
	String tenantId = "tenantId";

	
	@MockBean
	com.ge.ren.attachments.utils.Autils utils;
	
	@BeforeEach
    public void setup() throws TokenVerifyException, JsonParseException, IOException {
		super.setUp();
		MockitoAnnotations.initMocks(this);

        when(requestInterceptor.getTenantId()).thenReturn("tenantid");
        when(requestInterceptor.getUsername()).thenReturn("name");
        Note note = getNote();
  		when(service.processGetRequest(any())).thenReturn(objectMapper.writeValueAsString(note));

        when(apiUtil.retrieveTenantId(requestInterceptor)).thenReturn("tenantId");
        when(apiUtil.retrieveUserName(requestInterceptor)).thenReturn("tenantName");
        
        List<String> capabilitiesList = new ArrayList<>();
        capabilitiesList.add(Constants.NOTES_AND_ATTACHMENTS);
        capabilitiesList.add(Constants.INTERNAL_ACCESS);
        List<String> roleList = new ArrayList<>();
        roleList.add(Constants.ROLE_SUPER_ADMIN);
        when(requestInterceptor.getUserCapabilities()).thenReturn(capabilitiesList);
        when(requestInterceptor.getUserRoles()).thenReturn(roleList);        
        when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("internal");

 		when( utils.validateForFileSize( any())).thenReturn(true); 
 		ResponseEntity r= new ResponseEntity(mapToJson(getNote()), HttpStatus.ACCEPTED);
 		when(service.processPostRequest(any(NotesRequest.class), any())).thenReturn(r);  // new ResponseEntity<>("", HttpStatus.ACCEPTED));   //
 		r= new ResponseEntity(HttpStatus.OK);
 		when(service.processPatchRequest(any(NotesRequest.class), any(), any())).thenReturn(r); 
	}
	
    @AfterAll
    void tearDown() throws IOException {
    }
    @Test
	public void getNotesTest() throws Exception{
		System.out.println("get Notes Controller Test start...  " );

		notes = getNote(); 
		assertTrue(null != notes);
        
      
        NotesRequest nr = new NotesRequest();
        
        when(service.processGetRequest(any(NotesRequest.class))).thenReturn(objectMapper.writeValueAsString(notes));  // n any(Notes.class
        
        this.mockMvc.perform(get(DOMAIN_SERVICE  + "/site-notes")
                .param("pageIdx", String.valueOf(0))
                .param("pageSize", String.valueOf(10))
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk());
                

        this.mockMvc.perform(get(DOMAIN_SERVICE  + "/case-notes")
                .param("pageIdx", String.valueOf(0))
                .param("pageSize", String.valueOf(100))
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk());

	

        this.mockMvc.perform(get(DOMAIN_SERVICE  + "/task-notes")
                .param("pageIdx", String.valueOf(0))
                .param("pageSize", String.valueOf(100))
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk());

		
        this.mockMvc.perform(get(DOMAIN_SERVICE  + "/event-notes")
                .param("pageIdx", String.valueOf(0))
                .param("pageSize", String.valueOf(100))
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().is2xxSuccessful()); 

		
        this.mockMvc.perform(get(DOMAIN_SERVICE  + "/asset-notes")
                .param("pageIdx", String.valueOf(0))
                .param("pageSize", String.valueOf(100))
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk());
	
    }
    
    @Test
    public void ren204GetNotesTest() throws Exception{
        
    	log.info("Run 204 Get Notes test");
        /* setup mock */
        when(service.processGetRequest(any(NotesRequest.class))).thenReturn("");  // n any(Notes.class
        // Validate 204
        MvcResult  res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/site-notes").accept(MediaType.APPLICATION_JSON).content("")).andDo(MockMvcResultHandlers.print())
				.andExpect(status().is2xxSuccessful()).andReturn();

        assertTrue(res.getResponse().getStatus() >= 200);
        
        res =this.mockMvc.perform(get(DOMAIN_SERVICE  + "/case-notes").accept(MediaType.APPLICATION_JSON).content("")).andDo(MockMvcResultHandlers.print()).andExpect(status().is2xxSuccessful()).andReturn();
        assertTrue(res.getResponse().getStatus() >= 200);
        res =this.mockMvc.perform(get(DOMAIN_SERVICE  + "/asset-notes").accept(MediaType.APPLICATION_JSON).content("")).andDo(MockMvcResultHandlers.print()).andExpect(status().is2xxSuccessful()).andReturn();
        assertTrue(res.getResponse().getStatus() >= 200);
        res =this.mockMvc.perform(get(DOMAIN_SERVICE  + "/event-notes").accept(MediaType.APPLICATION_JSON).content("")).andDo(MockMvcResultHandlers.print()).andExpect(status().is2xxSuccessful()).andReturn();
        assertTrue(res.getResponse().getStatus() >= 200);
        res =this.mockMvc.perform(get(DOMAIN_SERVICE  + "/task-notes").accept(MediaType.APPLICATION_JSON).content("")).andDo(MockMvcResultHandlers.print()).andExpect(status().is2xxSuccessful()).andReturn();
        assertTrue(res.getResponse().getStatus() >= 200);
        
        when(service.processGetRequest(any(NotesRequest.class))).thenReturn(notes.toString());
        // validate Optionals
        // Cover NoteRequest Optionals
        this.mockMvc.perform(get(DOMAIN_SERVICE  + "/site-notes")
                .queryParam("domainId", "500023")
                .queryParam("filter", "id,title,note")
                .queryParam("query", "priority==MEDIUM;category==category")
        		.queryParam("createdBy", "Dmitry")
        		.queryParam("updatedBy", "updatedBy")
        		.queryParam("creationDate", "10/10/25 10:10:10")
        		.queryParam("updateDate", "10/10/25 10:10:10")
        		.queryParam("category", "category")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().is2xxSuccessful());
        
        this.mockMvc.perform(get(DOMAIN_SERVICE  + "/case-notes")
                .queryParam("domainId", "500023")
                .queryParam("filter", "id,title,note")
                .queryParam("query", "priority==MEDIUM;category==category")
        		.queryParam("createdBy", "Dmitry")
        		.queryParam("updatedBy", "updatedBy")
        		.queryParam("creationDate", "10/10/25 10:10:10")
        		.queryParam("updateDate", "10/10/25 10:10:10")
        		.queryParam("category", "category")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().is2xxSuccessful());
        
        this.mockMvc.perform(get(DOMAIN_SERVICE  + "/asset-notes")
                .queryParam("domainId", "500023")
                .queryParam("filter", "id,title,note")
                .queryParam("query", "priority==MEDIUM;category==category")
        		.queryParam("createdBy", "Dmitry")
        		.queryParam("updatedBy", "updatedBy")
        		.queryParam("creationDate", "10/10/25 10:10:10")
        		.queryParam("updateDate", "10/10/25 10:10:10")
        		.queryParam("category", "category")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().is2xxSuccessful());
        
        this.mockMvc.perform(get(DOMAIN_SERVICE  + "/event-notes")
                .queryParam("domainId", "500023")
                .queryParam("filter", "id,title,note")
                .queryParam("query", "priority==MEDIUM;category==category")
        		.queryParam("createdBy", "Dmitry")
        		.queryParam("updatedBy", "updatedBy")
        		.queryParam("creationDate", "10/10/25 10:10:10")
        		.queryParam("updateDate", "10/10/25 10:10:10")
        		.queryParam("category", "category")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().is2xxSuccessful());
        
        this.mockMvc.perform(get(DOMAIN_SERVICE  + "/task-notes")
                .queryParam("domainId", "500023")
                .queryParam("filter", "id,title,note")
                .queryParam("query", "priority==MEDIUM;category==category")
        		.queryParam("createdBy", "Dmitry")
        		.queryParam("updatedBy", "updatedBy")
        		.queryParam("creationDate", "10/10/25 10:10:10")
        		.queryParam("updateDate", "10/10/25 10:10:10")
        		.queryParam("category", "category")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().is2xxSuccessful());
        // end 
	
 
    }

    @Test
    public void processGetByIdNotes() throws Exception {

		notes = getNote(); 
        NotesRequest nr = new NotesRequest();
        String inputJson = mapToJson(notes);
        

        when(service.processGetRequest(any(NotesRequest.class))).thenReturn(notes.toString());
        
        MvcResult res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/site-notes/{id}", "1")
        		.queryParam("filter", "id,note,title")
        		.queryParam("pageIdx", "1")
        		.queryParam("pageSize", "1")
        		.queryParam("domainId", "id")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();

        assertTrue(res.getResponse().getStatus() >= 200);

 
        
        res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/case-notes/{id}", "1")
        		.queryParam("filter", "id,note,title")
        		.queryParam("pageIdx", "1")
        		.queryParam("pageSize", "1")
        		.queryParam("domainId", "id")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();

        assertTrue(res.getResponse().getStatus() >= 200);
        
        res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/task-notes/{id}", "1")
        		.queryParam("filter", "id,note,title")
        		.queryParam("pageIdx", "1")
        		.queryParam("pageSize", "1")
        		.queryParam("domainId", "id")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();

        assertTrue(res.getResponse().getStatus() >= 200);
        
        res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/event-notes/{id}", "1")
        		.queryParam("filter", "id,note,title")
        		.queryParam("pageIdx", "1")
        		.queryParam("pageSize", "1")
        		.queryParam("domainId", "id")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();

        assertTrue(res.getResponse().getStatus() >= 200);

        
        res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/asset-notes/{id}", "1")
        		.queryParam("filter", "id,note,title")
        		.queryParam("pageIdx", "1")
        		.queryParam("pageSize", "1")
        		.queryParam("domainId", "id")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();

        assertTrue(res.getResponse().getStatus() >= 200);


        // Process GET by ID >>>>>>>>>>>>>>>>
        // get by ID
        // 204
        when(service.processGetRequest(any(NotesRequest.class))).thenReturn("");  // n any(Notes.class
        // Validate 204
       res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/site-notes/{id}", "1").accept(MediaType.APPLICATION_JSON).content("")).andDo(MockMvcResultHandlers.print())
    		   .andExpect(MockMvcResultMatchers.status().is(204)).andReturn();

       res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/case-notes/{id}", "1").accept(MediaType.APPLICATION_JSON).content("")).andDo(MockMvcResultHandlers.print())
    		   .andExpect(MockMvcResultMatchers.status().is(204)).andReturn();

       res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/task-notes/{id}", "1").accept(MediaType.APPLICATION_JSON).content("")).andDo(MockMvcResultHandlers.print())
    		   .andExpect(MockMvcResultMatchers.status().is(204)).andReturn();

       res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/event-notes/{id}", "1").accept(MediaType.APPLICATION_JSON).content("")).andDo(MockMvcResultHandlers.print())
    		   .andExpect(MockMvcResultMatchers.status().is(204)).andReturn();

       res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/asset-notes/{id}", "1").accept(MediaType.APPLICATION_JSON).content("")).andDo(MockMvcResultHandlers.print())
    		   .andExpect(MockMvcResultMatchers.status().is(204)).andReturn();

       
       //GT with Json return
       res = this.mockMvc.perform(get(DOMAIN_SERVICE  +  "/site-notes/{id}", "1").accept(MediaType.APPLICATION_JSON).content(inputJson)).andDo(MockMvcResultHandlers.print())
				.andExpect(status().is(204)).andReturn();

        assertTrue(res.getResponse().getStatus() >= 200);
        
        res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/case-notes/{id}", "1").accept(MediaType.APPLICATION_JSON).content(inputJson)).andDo(MockMvcResultHandlers.print())
  				.andExpect(status().is(204)).andReturn();
        res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/task-notes/{id}", "1").accept(MediaType.APPLICATION_JSON).content(inputJson)).andDo(MockMvcResultHandlers.print())
  				.andExpect(status().is(204)).andReturn();
        res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/asset-notes").accept(MediaType.APPLICATION_JSON).content(inputJson)).andDo(MockMvcResultHandlers.print())
  				.andExpect(status().is(204)).andReturn();
        res = this.mockMvc.perform(get(DOMAIN_SERVICE  + "/event-notes/{id}", "1").accept(MediaType.APPLICATION_JSON).content(inputJson)).andDo(MockMvcResultHandlers.print())
  				.andExpect(status().is(204)).andReturn();
        
 
         System.out.println("get Notes Controller Test done.  " );
	}
	
    

    @Test
	// Test POST
	public void createPostNoteTest() throws Exception {
 	   String uri = DOMAIN_SERVICE + "/site-notes";
 	   String inputJson = mapToJson(notes);
 	   inputJson = "";
 	   ResponseEntity r = new ResponseEntity(mapToJson(getNote()), HttpStatus.ACCEPTED);
 	   
 	   
 	   when(service.processPostRequest(any(NotesRequest.class), any())).thenReturn(r);

    	MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
    	MockMultipartFile json = new MockMultipartFile("json", "", "application/json", mapToJson(getPostNote()).getBytes());
    	
    	MvcResult  mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri)

               .file(json)

 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
 	           .andExpect(status().is(202)).andReturn();


 	   assertTrue(mvcResult.getResponse().getStatus() >= 200);
    	
    	uri = DOMAIN_SERVICE + "/case-notes";
       mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri)
                //.file(file)
               .file(json)

  	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
  	           .andExpect(status().is(202)).andReturn();

	   assertTrue(mvcResult.getResponse().getStatus() >= 200);
	   
	   uri = DOMAIN_SERVICE + "/asset-notes";
       mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri)
               //.file(file)
               .file(json)

 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
 	           .andExpect(status().is(202)).andReturn();

	   assertTrue(mvcResult.getResponse().getStatus() >= 200);
	   
	   uri = DOMAIN_SERVICE + "/event-notes";
       mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri)
               //.file(file)
               .file(json)

 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
 	           .andExpect(status().is(202)).andReturn();

	   assertTrue(mvcResult.getResponse().getStatus() >= 200);
	   
	   uri = DOMAIN_SERVICE + "/task-notes";
       mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri)
               //.file(file)
               .file(json)
 			   .contentType(MediaType.APPLICATION_JSON)
 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
 	           .andExpect(status().is(202)).andReturn();

	   assertTrue(mvcResult.getResponse().getStatus() >= 200);
	   
	   //validate for file size=true
  	   when( utils.validateForFileSize( any())).thenReturn(true);
  	   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(DOMAIN_SERVICE + "/task-notes")
            .file(json)
	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
	           .andExpect(status().is2xxSuccessful()).andReturn();
	   assertTrue(mvcResult.getResponse().getStatus() >= 200);	   

	   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(DOMAIN_SERVICE + "/asset-notes")
  	            .file(json)
  		           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
  		           .andExpect(status().is2xxSuccessful()).andReturn();
  		   assertTrue(mvcResult.getResponse().getStatus() >= 200);	   
  	  	   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(DOMAIN_SERVICE + "/case-notes")
  	             .file(json)
  	 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
  	 	           .andExpect(status().is2xxSuccessful()).andReturn();
  	 	   assertTrue(mvcResult.getResponse().getStatus() >= 200);	   
  	  	   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(DOMAIN_SERVICE + "/event-notes")
  	             .file(json)
  	 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
  	 	           .andExpect(status().is2xxSuccessful()).andReturn();
  	 	   assertTrue(mvcResult.getResponse().getStatus() >= 200);	   
  	  	   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(DOMAIN_SERVICE + "/site-notes")
  	             .file(json)
  	 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
  	 	           .andExpect(status().is2xxSuccessful()).andReturn();
  	 	   assertTrue(mvcResult.getResponse().getStatus() >= 200);	   

	   
   
	   //Validate for Attached Files and throw:
	   when( utils.validateForFileSize( any())).thenReturn(false);
	   
		Assertions.assertThrows(org.springframework.web.util.NestedServletException.class, () -> {
			MvcResult mResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(DOMAIN_SERVICE + "/task-notes")
	               //.file(file)
	               .file(json)
	 			   .contentType(MediaType.APPLICATION_JSON)
	 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
	 	           .andExpect(status().is(202)).andReturn();
	
		   assertTrue(mResult.getResponse().getStatus() >= 200);
		}); 
		Assertions.assertThrows(org.springframework.web.util.NestedServletException.class, () -> {

			MvcResult mResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(DOMAIN_SERVICE + "/case-notes")
	               //.file(file)
	               .file(json)

	 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
	 	           .andExpect(status().is(202)).andReturn();
		   assertTrue(mResult.getResponse().getStatus() >= 200);
		});	   
		Assertions.assertThrows(org.springframework.web.util.NestedServletException.class, () -> {
		
			String uril = DOMAIN_SERVICE + "/asset-notes";
			MvcResult mResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uril)
               //.file(file)
               .file(json)

 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
 	           .andExpect(status().is(202)).andReturn();
	   		assertTrue(mResult.getResponse().getStatus() >= 200);
		});
		Assertions.assertThrows(org.springframework.web.util.NestedServletException.class, () -> {
			String  uril = DOMAIN_SERVICE + "/event-notes";
			MvcResult mResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uril)
               //.file(file)
               .file(json)

 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
 	           .andExpect(status().is(202)).andReturn();
			assertTrue(mResult.getResponse().getStatus() >= 200);
		});
		Assertions.assertThrows(org.springframework.web.util.NestedServletException.class, () -> {
			String uril = DOMAIN_SERVICE + "/task-notes";
			MvcResult mResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uril)
               //.file(file)
               .file(json)

 	           .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))
 	           .andExpect(status().is(202)).andReturn();
			assertTrue(mResult.getResponse().getStatus() >= 200);
		});
	   System.out.println("done create note test..");

	}
	
	
	@Test
	public void patchNoteTest() throws Exception {
		   String uri = DOMAIN_SERVICE + "/site-notes"; String response ="";

	
		   uri = DOMAIN_SERVICE + "/case-notes";
		   MvcResult mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri).header("Allow", "PATCH")
				   .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json"))

				   .andDo(MockMvcResultHandlers.print()).andReturn();
		   assertTrue(mvcResult.getResponse().getStatus() >= 200);
		   String content = mvcResult.getResponse().getContentAsString();
		   assertTrue(content.isEmpty());
	
		   uri = DOMAIN_SERVICE + "/event-notes";
		   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri).header("Allow", "PATCH")
				   .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json").content(mapToJson(notes)))
				   .andReturn();
		   assertTrue(mvcResult.getResponse().getStatus() >= 200);
		   content = mvcResult.getResponse().getContentAsString();
		   assertTrue(content.isEmpty());
	
		   uri = DOMAIN_SERVICE + "/asset-notes";
		   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri).header("Allow", "PATCH")
				   .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json")
				   .content(mapToJson(notes))).andReturn();
		   assertTrue(mvcResult.getResponse().getStatus() >= 200);
		   content = mvcResult.getResponse().getContentAsString();
		   assertTrue(content.isEmpty());
	
		   uri = DOMAIN_SERVICE + "/task-notes";
		   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri).header("Allow", "PATCH")
				   .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json")
				   .content(mapToJson(notes))).andReturn();
		   assertTrue(mvcResult.getResponse().getStatus()>= 200);
		   content = mvcResult.getResponse().getContentAsString();
		   assertTrue(content.isEmpty());
		   
		   System.out.println("patch test  done with atachment Files ..");
		   System.out.println(">>>>>>>>>>>>>>>>>");
		   System.out.println("patch test  started for No atachment Files ..");

		   //Validate for Attached Files and throw:
		   when( utils.validateForFileSize( any())).thenReturn(false);
	
		   uri = DOMAIN_SERVICE + "/case-notes";
		   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri).header("Allow", "PATCH")
				   .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json").content(mapToJson(notes))).andReturn();
		   assertEquals(400, mvcResult.getResponse().getStatus());
		   content = mvcResult.getResponse().getContentAsString();
		   assertTrue(content.isEmpty());
	
		   uri = DOMAIN_SERVICE + "/event-notes";
		   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri).header("Allow", "PATCH")
				   .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json").content(mapToJson(notes))).andReturn();
		   assertEquals(400, mvcResult.getResponse().getStatus());
		   content = mvcResult.getResponse().getContentAsString();
		   assertTrue(content.isEmpty());
	
		   uri = DOMAIN_SERVICE + "/asset-notes";
		   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri).header("Allow", "PATCH")
				   .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json").content(mapToJson(notes))).andReturn();
		   assertEquals(400, mvcResult.getResponse().getStatus());
		   content = mvcResult.getResponse().getContentAsString();
		   assertTrue(content.isEmpty());
	
		   uri = DOMAIN_SERVICE + "/task-notes";
		   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.multipart(uri).header("Allow", "PATCH")
				   .accept(MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json").content(mapToJson(notes))).andReturn();
		   assertEquals(400, mvcResult.getResponse().getStatus());
		   content = mvcResult.getResponse().getContentAsString();
		   assertTrue(content.isEmpty());
		   
		   System.out.println("done patch test ..");

	}


	   @Test
	   public void deleteNoteTest() throws Exception {
		      String uri = DOMAIN_SERVICE + "/site-notes";
		      when(apiUtil.retrieveTenantId(requestInterceptor)).thenReturn("tenantId");
		      
		  MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.delete(uri+"/{id}", "1")
	                .accept(MediaType.APPLICATION_JSON))
	                .andExpect(MockMvcResultMatchers.status().isOk())
	                .andDo(MockMvcResultHandlers.print())
	                .andReturn();

		  assertTrue( mvcResult.getResponse().getStatus() == 200);
		   

	      ResultActions result = this.mockMvc.perform(MockMvcRequestBuilders.delete(uri+"/{id}", "1")
	    		  .param("domainId", "500023")
	    		  .contentType(MediaType.APPLICATION_JSON).header("Allow", "DELETE")
	              .accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	      
	      uri = DOMAIN_SERVICE + "/case-notes";
	      mvcResult =  mockMvc.perform(MockMvcRequestBuilders.delete(uri+"/{id}", "1")
	    		  .param("domainId", "500023").header("Allow", "DELETE")).andReturn();
	      assertEquals(200, mvcResult.getResponse().getStatus());
	      String content = mvcResult.getResponse().getContentAsString();
	      assertTrue(content.isEmpty());

	      uri = DOMAIN_SERVICE + "/asset-notes";
	      mvcResult =  mockMvc.perform(MockMvcRequestBuilders.delete(uri+"/{id}", "1")
	    		  .param("domainId", "500023").header("Allow", "DELETE")).andReturn();
	      assertEquals(200, mvcResult.getResponse().getStatus());
	      content = mvcResult.getResponse().getContentAsString();
	      assertTrue(content.isEmpty());

	      uri = DOMAIN_SERVICE + "/event-notes";
	      mvcResult =  mockMvc.perform(MockMvcRequestBuilders.delete(uri+"/{id}", "1")
	    		  .param("domainId", "500023").header("Allow", "DELETE")).andReturn();
	      assertEquals(200, mvcResult.getResponse().getStatus());
	      content = mvcResult.getResponse().getContentAsString();
	      assertTrue(content.isEmpty());

	      uri = DOMAIN_SERVICE + "/task-notes";
	      mvcResult =  mockMvc.perform(MockMvcRequestBuilders.delete(uri+"/{id}", "1")
	    		  .param("domainId", "500023").header("Allow", "DELETE")).andReturn();
	      assertEquals(200, mvcResult.getResponse().getStatus());
	      content = mvcResult.getResponse().getContentAsString();
	      assertTrue(content.isEmpty());
	   
	   }

		//@Test
		public void getCaseNotesListTest() throws Exception {
			   String uri = DOMAIN_SERVICE +  "/case-notes";

			   MvcResult mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.get(uri)).andDo(print()).andReturn();
			   assertEquals(200, mvcResult.getResponse().getStatus());
			   String content = mvcResult.getResponse().getContentAsString();
			   Note[] notes = mapFromJson(content, Note[].class);
			   assertTrue(notes.length > 0);
			   uri = DOMAIN_SERVICE +  "/case-notes/1";
			   mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
			   assertEquals(200, mvcResult.getResponse().getStatus());
			   content = mvcResult.getResponse().getContentAsString();
			   notes = mapFromJson(content, Note[].class);
			   assertTrue(notes.length > 0);

		}
		private String  getNoteJson(){
			String noteJson = "{\"note\": \"Sit eote\",\n" + 
					"  \"title\":\"updat title\",\n" + 
					"  \"priority\": \"LOW\",\n" + 
					"  \"category\": \"patched category\",\n" + 
					"  \"scope\": \"internal\",\n" + 
					"  \"status\": \"active\"\n" + 
					"}";
			return noteJson;
		}
	    private Note getNote() {
	    	Note note = new Note();

			note.setCategory("category");
			note.setCreatedBy("createdBy");
			note.setCreationDate("creationDate");
			note.setDeleted(false);
			note.setDomainId("domainId");
			note.setId("id");
			note.setNote("note");
			note.setPriority("priority");
			note.setScope(Scope.internal.toString());
			note.setStatus("active");
			note.setTenantId("tenantId");
			note.setTitle("title");
			note.setUpdateDate("updateDate");
			note.setUpdatedBy("updatedBy");
			note.setValidDateBy("validDateBy");
	    	return note;
	    }	
	    private NotesRequest getNotesRequest() {
	    	List<AttachmentData> attachments = new ArrayList<>();
	        NotesRequest noteR = new NotesRequest();
	        noteR.setDomain("sites");
	        noteR.setDomainIds("domainId");
	        noteR.setFilter("id,title,note,domainId,category");
	        noteR.setPageIdx(0);
	        noteR.setPageSize(5);
	        noteR.setTenantId("tenantId");
	        noteR.setBody(attachments);
	        noteR.setQuery("priority==MEDIUM;category==category");
	        return noteR;	    	
	    }
	    private PostNote getPostNote() {
	    	PostNote post = new PostNote();
			post.setCategory("category");
			post.setDomainId("domainId");
			post.setNote("note");
			post.setDomainId("domainId");
			post.setPriority("priority");
			post.setScope("scope");
			post.setStatus("status");
			post.setTitle("title");
			post.setValidDateBy("validDateBy");
			//post.setAttachments(attachments);
	    	return post;
	    }
	    private static String asJsonString(final Note notes) {
	    	try {
	    		return new ObjectMapper().writeValueAsString(notes);
	    	} catch (Exception e) {
	    		throw new RuntimeException(e);
	    	}
	    }
	    
		private Optional<MultipartFile[]> getOptionalFiles() {
		    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
		    MockMultipartFile[] fileso = {file};
		    Optional<MultipartFile[]> files = Optional.of(fileso);
		    return files;
		}
		
}

