package com.ge.ren.attachments.utils;

import static com.ge.ren.notes.constants.Constants.AWS_PATH1;
import static com.ge.ren.notes.constants.Constants.AWS_PATH2;
import static com.ge.ren.notes.constants.Constants.DOT;
import static com.ge.ren.notes.constants.Constants.MAX_FILE_SIZE;
import static com.ge.ren.notes.constants.Constants.NOTE_SIZE;
import static com.ge.ren.notes.constants.Constants.POST;
import static com.ge.ren.notes.constants.Constants.POST;
import static com.ge.ren.notes.constants.Constants.PATCH;
import static com.ge.ren.notes.constants.Constants.SLASH;
import static com.ge.ren.notes.constants.Constants.TITLE_SIZE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.rules.ExpectedException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.rules.ExpectedException;

import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.mock.web.MockMultipartFile;

import com.amazonaws.util.IOUtils;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.Attachments;
import com.ge.ren.attachments.model.GetAttachments;
import com.ge.ren.attachments.model.PostAttachment;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.model.patch.Patch;
import com.ge.ren.notes.constants.ErrorConstants;
import com.ge.ren.notes.constants.Scope;
import com.ge.ren.notes.dto.AttachmentBase;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.Pagination;
import com.ge.ren.notes.utils.ValidateUtil;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
//import org.junit.Test;  
//import org.powermock.api.mockito.PowerMockito;  
//import org.powermock.core.classloader.annotations.PrepareForTest;  
//import org.powermock.modules.junit4.PowerMockRunner;  

import lombok.extern.slf4j.Slf4j;

@Slf4j
//@ActiveProfiles("dev")
@TestInstance(Lifecycle.PER_CLASS)
@RunWith(SpringRunner.class)
@SpringBootTest (classes = {Autils.class}, properties = {"descriptionSize=20", "titleSize=10", "storageType=fyleSystem"})
@TestPropertySource(locations = "/application.properties")
@AutoConfigureMockMvc
public class AutilsTest {


	@MockBean
	com.ge.ren.notes.utils.DateFormatMS dataFormat;
	
	@Autowired
	Autils utils;

	@Rule
    public ExpectedException thrown = ExpectedException.none();

    @Value("${storageType}")
	private String storageType;
    
    
    @Value("${aws.bucket.prefix:TODO_add_bucket_to_properties}")
	private String bucket;

	@Value("${descriptionSize}")
    private int descriptionSize;
    
    @Value("${titleSize}")
    private int titleSize;
    
    StringBuilder sb = new StringBuilder(); 
    
	@BeforeAll
    void setUp() throws IOException {
		MockitoAnnotations.initMocks(this);
		when(dataFormat.getCurrentDateFormated()).thenReturn("01/01/22");
		when(dataFormat.getTodayDateString()).thenReturn("01/01/22");
		List<AttachmentData> list = new ArrayList<>();
		 
	}
	
	private Optional<MultipartFile[]> getMultipartFiles() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] fileso = {file};
	    Optional<MultipartFile[]> files = Optional.of(fileso);
	    return files;
	}
	

	@Test
	public void utilsTest() {
	 	String bucket = "bucket";  
	    //String expectation = bucket; // + "/"+dataFormat.getCurrentDateFormated();  
	    //PowerMockito.mockStatic(Utils.class);  
	    
	    Autils fileMock = mock(Autils.class);
	    when(fileMock.compileBucketPath("bucket")).thenReturn("bucket");
	    assertTrue( utils.compileBucketPath("bucket").contains("bucket"));
	    when(fileMock.getDescriptionSizeCheck(any(), anyString())).thenReturn(true);
	    System.out.println("descriptionSize ->> " + descriptionSize);
	    //boolean result = utils.getDescriptionSizeCheck(new PostAttachment());
	    PostAttachment pa = new PostAttachment();
	    com.ge.ren.attachments.model.Attachment ap = new com.ge.ren.attachments.model.Attachment();
	   
	    for(int i=0; i<2505; i++ ) {
			sb.append("1");
		}
	   	Assertions.assertThrows(ResourceNotValid.class, () -> {
	   		pa.setDescription(sb.toString());
	   		utils.getDescriptionSizeCheck(pa, "post");
    	});
	   	
	   	Assertions.assertThrows(ResourceNotValid.class, () -> {
	   		ap.setDescription(sb.toString());
	   		utils.getDescriptionSizeCheck(ap, "patch");
    	});
	   	pa.setDescription(" ");
	    assertTrue(utils.getDescriptionSizeCheck(pa, "post"));
	    ap.setDescription("desc");
	    assertTrue(utils.getDescriptionSizeCheck(ap, "patch"));
	    NotesRequest request = new NotesRequest();
	    request.setCount(1);
	    request.setPageIdx(0);
	    request.setPageSize(1);
	    List<Attachment> attachments = Arrays.asList( new Attachment()); 
	   //when(utils.setPaginationMetadata(attachments, request )).thenReturn(new GetAttachments());
	    
	    GetAttachments ga = utils.setPaginationMetadata(attachments, request );
	    assertTrue(ga.pagination != null);
	    
	    when(fileMock.getErrorDescription("message", 500, "acode", "atype", "aid")).thenReturn("AWS");
	    
	    String msg = utils.getErrorDescription("message", 500, "acode", "atype", "aid");
	    assertTrue(msg.contains("AWS"));
	    
	    when(fileMock.validatePathExists(bucket) ).thenReturn(false);  
	    boolean doesExist = utils.validatePathExists("bucket");   
	    assertEquals(true, doesExist);  
		
	    //when(fileMock.getNotesByDomain("case") ).thenReturn(true);
	    try {
	    	boolean domain = utils.getNotesByDomain("case");
	    	assertEquals(true, domain);
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		utils.getNotesByDomain("case2");
	    	});
	    }catch(ResourceNotValid e) {
		    	log.debug("{}", e);
		    	assertTrue(e.getMessage().contains("valid"));
		    }
	    pa.setTitle(sb.toString());
	    try {
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		utils.getTitleSizeCheck(pa, "post");
	    	});
	    	ap.setTitle(sb.toString());
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		utils.getTitleSizeCheck(ap, "patch");
	    	});
	    	
	    }catch(ResourceNotValid e) {
	    	log.debug("{}", e);
	    	assertTrue(e.getMessage().contains("valid"));
	    }
	    ap.setTitle("title");
	    boolean b = utils.getTitleSizeCheck(ap, "patch");
	    assertTrue(b);
	    pa.setTitle("title");
	    b = utils.getTitleSizeCheck(pa, "post");
	    assertTrue(b);
	    
	    
///	    when(fileMock.validateForFileSize(null)).thenReturn(false);
//	    boolean size = fileMock.validateForFileSize(null);
//	    assertEquals(false, size );
		try {
			boolean size = utils.validateForFileSize(getMultipartFiles());
			assertEquals(true, size );
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}    	
	}
	

	@Test
	public void validateForFileType() throws JsonMappingException, JsonProcessingException{
		MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
		try {
			utils.validateForFileType(file);
			file = new MockMultipartFile("file",  "hello.py", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
			utils.validateForFileType(file);
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}    	
	}
	

	@Test
	public void getPaginationTest() {
		List<Attachment> attachments = new ArrayList<>();
        NotesRequest noteR = new NotesRequest();
        noteR.setDomain("sites");
        noteR.setDomainIds("domainIds");
        noteR.setFilter("id,title,note,domainId,category,updatedBy");
        noteR.setPageIdx(0);
        noteR.setPageSize(5);
        noteR.setTenantId("tenantId");
        noteR.setQuery("priority==MEDIUM;category==category");
		noteR.setCount(100);
        Pagination pagination = new Pagination(0,0,0,0);

		GetAttachments ga = new GetAttachments (pagination, attachments);
		
		ga = utils.setPaginationMetadata(attachments, noteR);
		
		assertTrue(ga.getPagination().currentPage == 0);
		assertTrue(ga.getPagination().getPageSize() > 0);
		assertTrue(ga.getPagination().getTotalPages() >= 0);
		assertTrue(ga.getPagination().getTotalRecords() >= 0);
		assertTrue(ga.getAttachments().size() >= 0);

	}
	
	@Test 
	public void removeDeletedFieldTest() throws JsonMappingException, JsonProcessingException {
		
		
		List<Patch> atlist = new ArrayList<>();
		com.ge.ren.attachments.model.patch.Patch at = new com.ge.ren.attachments.model.patch.Patch("remove", "/......", "");
		atlist.add(at);
		Attachment ob =  (Attachment) utils.removeDeletedField(getAttachment(), "attachment", atlist);
		assertNotEquals(null , ob.getDescription());
		atlist.clear();
		at = new com.ge.ren.attachments.model.patch.Patch("remove", "/title", "");
		atlist.add(at);
		ob =  (Attachment) utils.removeDeletedField(getAttachment(), "attachment", atlist);
		assertEquals(null , ob.getTitle());
		atlist.clear();

		at = new com.ge.ren.attachments.model.patch.Patch("remove", "/description", "");
		atlist.add(at);
		ob =  (Attachment) utils.removeDeletedField(getAttachment(), "attachment", atlist);
		assertEquals(null, ob.getDescription());
		atlist.clear();
		at = new com.ge.ren.attachments.model.patch.Patch("remove", "/domainName", "");
		atlist.add(at);
		ob =  (Attachment) utils.removeDeletedField(getAttachment(), "attachment", atlist);
		assertEquals(null, ob.getDomainName());
		atlist.clear();
		
		at = new com.ge.ren.attachments.model.patch.Patch("remove", "/title", "");
		atlist.add(at);
		Note obn =  (Note) utils.removeDeletedField(getNote(), "note", atlist);
		assertEquals(null, obn.getTitle());
		atlist.clear();
		at = new com.ge.ren.attachments.model.patch.Patch("remove", "/note", "");
		atlist.add(at);
		obn =  (Note) utils.removeDeletedField(getNote(), "note", atlist);
		assertEquals(null, obn.getNote());
		atlist.clear();
		
		at = new com.ge.ren.attachments.model.patch.Patch("remove", "/priority", "");
		atlist.add(at);
		obn =  (Note) utils.removeDeletedField(getNote(), "note", atlist);
		assertEquals(null, obn.getPriority());
		atlist.clear();
		at = new com.ge.ren.attachments.model.patch.Patch("remove", "/category", "");
		atlist.add(at);
		obn =  (Note) utils.removeDeletedField(getNote(), "note", atlist);
		assertNotEquals(null, obn.getCategory());
		atlist.clear();
		at = new com.ge.ren.attachments.model.patch.Patch("remove", "/status", "");
		atlist.add(at);
		obn =  (Note) utils.removeDeletedField(getNote(), "note", atlist);
		assertEquals(null, obn.getStatus());
		atlist.clear();
		at = new com.ge.ren.attachments.model.patch.Patch("remove", "/scope", "");
		atlist.add(at);
		obn =  (Note) utils.removeDeletedField(getNote(), "note", atlist);
		assertEquals(null, obn.getScope());
		atlist.clear();
	}
	

	@Test
	public void validatePatchRequest() throws JsonMappingException, JsonProcessingException {
	
		Attachment at = utils.validatePatchRequest(getAttachment(), getMultipartFile(), "post");
		assertNotNull(at.getDomainName());
		assertTrue(at.getDescription().contains("d"));
		assertNotNull(at.getTitle());

		at.setDescription(null);
		at = utils.validatePatchRequest(at, getMultipartFile(), "patch");
		assertNotNull(at.getTitle());
		at = utils.validatePatchRequest(at, getMultipartFile(), "post");
		assertNotNull(at.getTitle());

		
    	//Assertions.assertThrows(ResourceNotValid.class, () -> {
    		at = getAttachment();
    		at.setDescription("##");
    		assertNotNull(utils.validatePatchRequest(at, getMultipartFile(), "post") );
    	//});
    	

		at = getAttachment();
		at.setDescription("##");
		assertNotNull(utils.validatePatchRequest(at, getMultipartFile(), "patch"));
	    for(int i=0; i<2505; i++ ) {
			sb.append("1");
		}
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		Attachment a = getAttachment();
    		a.setDescription(sb.toString());
    		utils.validatePatchRequest(a, getMultipartFile(), "post");
    	});
    	
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		Attachment a = getAttachment();
    		a.setDescription(sb.toString());
    		assertNotNull(utils.validatePatchRequest(a, getMultipartFile(), "patch"));
    	});

    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		Attachment a = getAttachment();
    		a.setDescription("d");
        	a.setTitle(sb.toString());
    		utils.validatePatchRequest(a, getMultipartFile(), "post");
    	});
    	
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		Attachment a = getAttachment();
    		a.setDescription("d");
        	a.setTitle(sb.toString());
    		utils.validatePatchRequest(a, getMultipartFile(), "patch");
    	}); 
    	
    	//spec chars
       	//Assertions.assertThrows(ResourceNotValid.class, () -> {
		at = getAttachment();
		at.setDescription("d");
    	at.setTitle("##");
		utils.validatePatchRequest(at, getMultipartFile(), "post");
    	//});
    	
		at = getAttachment();
		at.setDescription("d");
    	at.setTitle("##");
		assertTrue(!utils.validatePatchRequest(at, getMultipartFile(), "patch").getId().isEmpty());
   	
    	
		/*
		 * Assertions.assertThrows(ResourceNotValid.class, () -> { Attachment a =
		 * getAttachment(); a.setDescription(null); a.setTitle(null); MultipartFile[]
		 * file = createMultipartFile(); utils.validatePatchRequest(a, file, "patch");
		 * }); Assertions.assertThrows(ResourceNotValid.class, () -> { Attachment a =
		 * getAttachment(); a.setDescription(null); a.setTitle(null); MultipartFile[]
		 * file = createMultipartFile(); utils.validatePatchRequest(a, file, "post");
		 * });
		 */
    
       	Assertions.assertThrows(AttributeNotFound.class, () -> {
    		Attachment a = getAttachment();
    		a.setDescription(null);
        	a.setTitle(null);
        	a.setAttachments(null);
    		utils.validatePatchRequest(a, null, "post");
    	});
    	
    	Assertions.assertThrows(AttributeNotFound.class, () -> {
    		Attachment a = getAttachment();
       		a.setDescription(null);
        	a.setTitle(null);
    		utils.validatePatchRequest(a, null, "patch");
    	});  

    	
	}
	

	
	private MultipartFile[] createMultipartFile() throws IOException {
		File file = new File("src/main/resources/attachments/test-image.png");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file",
		            file.getName(), "text/plain", IOUtils.toByteArray(input));
		MultipartFile[] mf = {multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, 
				multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile,
				multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile}; 
		return mf;  
	}
	
	//helpers

	
	private Attachment getAttachment() {
    	Attachment attachment = new Attachment();
    	attachment.setTitle("title");
		attachment.setCreatedBy("createdBy");
		attachment.setCreationDate("creationDate");
		attachment.setDescription("description");
		attachment.setDomainName("domainName");
		attachment.setDomainId("domainId");
		attachment.setId("id");
		attachment.setTenantId("tenantId");
		attachment.setUpdateDate("updateDate");
		attachment.setUpdatedBy("updatedBy");
    	return attachment;
    }
    public static String asJsonString(final
            Note notes) {
    	try {
    		return new ObjectMapper().writeValueAsString(notes);
    	} catch (Exception e) {
    		throw new RuntimeException(e);
    	}
    }
    
    private Note getNote() {
    	Note note = new Note();
		note.setCategory("category");
		note.setCreatedBy("createdBy");
		note.setCreationDate("creationDate");
		note.setDeleted(false);
		note.setDomainId("domainId");
		note.setId("id");
		note.setNote("note");
		note.setPriority("priority");
		note.setScope(Scope.internal.toString());
		note.setStatus("active");
		note.setTenantId("tenantId");
		note.setTitle("title");
		note.setUpdateDate("updateDate");
		note.setUpdatedBy("updatedBy");
		note.setValidDateBy("validDateBy");
		note.setAttachments(new ArrayList<AttachmentData>());
    	return note;
    }	
    
	private MultipartFile[] getMultipartFile() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] fileso = {file};
	    return fileso;
	}
}
