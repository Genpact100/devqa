package com.ge.ren.notes.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;


import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;

import org.assertj.core.util.Arrays;
import org.hamcrest.Matcher;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.verification.VerificationMode;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.VerificationModeFactory;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.notes.constants.Domain;
import com.ge.ren.notes.constants.Domain.DOMAIN;
import com.ge.ren.notes.constants.Scope;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.CaseNotes;
import com.ge.ren.notes.model.GetNotes;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.Pagination;
import com.ge.ren.notes.model.PatchNote;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.model.SiteNotes;
import com.ge.ren.notes.model.TaskNotes;

import lombok.extern.slf4j.Slf4j;

import static com.ge.ren.notes.constants.Constants.*;
@Slf4j
//@ActiveProfiles("dev")
@TestInstance(Lifecycle.PER_CLASS)
//@RunWith(SpringRunner.class)
//@SpringBootTest //(classes = ValidateUtil.class)
//@AutoConfigureMockMvc
public class ValidateUtilsTest {
	
    @Rule
    public ExpectedException thrown = ExpectedException.none();
	
    @Autowired
    ValidateUtil validateUtil;
	Note notes = new Note(); 

	String json = null;
	StringBuilder nt = new StringBuilder("aaa");

	@BeforeAll
    public void setup() {
		for(int i=0; i<4005; i++ ) {
			nt.append("1");
		}
        MockitoAnnotations.initMocks(this);
        ValidateUtil utils = Mockito.mock(ValidateUtil.class);
        json = "{ \"domainId\": \"500023\", \"note\": \"Si teote\", \"title\": \"Sit etle\", \"priority\": \"MEDIUM\",  \"category\": \"category\", \"scope\": \"internal\", \"status\": \"active\", \"validDateBy\": \"07/30/21 01:01:01\"}";
		notes.setCategory("category");
		notes.setCreatedBy("createdBy");
		notes.setCreationDate("12/12/39 11:11:11");
		notes.setDeleted(false);

		notes.setId("id");
		notes.setPriority("HIGH");
		notes.setScope("external");
		notes.setStatus("active");
		notes.setTenantId("tenantId");
		//notes.setTitle("title");
		notes.setUpdateDate("12/12/39 11:11:11");
		notes.setUpdatedBy("DK");
		notes.setValidDateBy("12/12/39 11:11:11");
    }
	int nameSize=10;
	int	titleSize=5;
    @After
    public void tearDown() {}
    @Test
    public void validateForJsonTest() {
    	
    	try {
        	String str = ValidateUtil.validateForSpecChars("{}", "field");
        	assertTrue(!str.isEmpty());
        	json = "{ \"domainId\": \"500023\", \"note\": \"Si teote\", \"title\": \"Sit etle\", \"priority\": \"MEDIUM\",  \"category\": \"category\", \"scope\": \"internal\", \"status\": \"active\", \"validDateBy\": \"07/30/21 01:01:01\"}";
        	
			ValidateUtil.validateJsonString("{}");
			json+= "123";
			ValidateUtil.validateJsonString(json);
		} catch (IOException e) {
			thrown.expect(IOException.class);
			thrown.expect(ResourceNotValid.class);
			thrown.expect(JsonParseException.class);
		}
    	
    }
    
    @org.junit.jupiter.api.Test 
	public void getNotesValidatedPostTest() throws AttributeNotFound, IOException{
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		log.info("Start getNotesValidated Test " + new Date(System.currentTimeMillis()));
		notes.setCategory("category");
		notes.setCreatedBy("createdBy");
		notes.setCreationDate("12/12/39 11:11:11");
		notes.setDeleted(false);

		notes.setId("id");
		notes.setPriority("HIGH");
		notes.setScope("external");
		notes.setStatus("active");
		notes.setTenantId("tenantId");
		notes.setTitle("title");
		notes.setUpdateDate("12/12/39 11:11:11");
		notes.setUpdatedBy("DK");
		notes.setValidDateBy("12/12/39 11:11:11");
		
        Optional<String> optionalStr = Optional.empty();
        Optional<Integer> optionalInt = Optional.empty();
        NotesRequest noteR = new NotesRequest();
        noteR.setDomain("sites");
        noteR.setDomainIds("domainIds");
        noteR.setFilter("id,title,note,domainId,category,updatedBy");
        noteR.setPageIdx(0);
        noteR.setPageSize(5);
        noteR.setTenantId("tenantId");
        noteR.setQuery("priority==MEDIUM;category==category");
        noteR.setBody(notes);
		
        notes = new Note("id", "domainId", "tenantId","title", "note", "06/09/2021 12:45:55", "06/10/2021 1:40:55",  "06/11/2021 2:00:00", "HIGH", "503206931", "503206931", "category", "sttus",  "scope", 
        		new Timestamp(nameSize), 
        		new Timestamp(nameSize), false, new ArrayList<AttachmentData>());
        assertNotNull(notes);
        

        	SiteNotes sn = new SiteNotes();
    		sn.setId("id");
    		sn.setDomainId("domainId");
    		sn.setTenantId("tenantId");
    		sn.setTitle("title"); 
    		sn.setNote("note");
    		sn.setCreationDate("06/10/2021 1:40:55");
    		sn.setUpdateDate("06/10/2021 1:40:55");
    		sn.setValidDateBy("vb");
    		sn.setPriority("priority");
    		sn.setCreatedBy("cb");
    		sn.setUpdatedBy("ub");
    		sn.setCategory("cat");
    		sn.setStatus("active");
    		sn.setScope("internal");
    		sn.setDeleted(false);
    		notes = new Note(sn);
    		assertNotNull(notes);
    		
    		PostNote pn = new PostNote();
    		pn.setDomainId("id");
    		pn.setAttachments(new ArrayList<AttachmentData>());
    		pn.setCategory("category");
    		pn.setNote("note");
    		pn.setPriority("HIGH");
    		pn.setScope("internal");
    		pn.setStatus("active");
    		pn.setTitle("title");
    		pn.setValidDateBy("06/10/2021 1:40:55");
    		notes = new Note(pn);
    		assertNotNull(notes);
    		
    		PatchNote pp = new PatchNote();
    		pp.setTitle("title");
    		pp.setCategory("category");
    		pp.setNote("note");
    		pp.setPriority("HIGH");
    		pp.setPriority("HIGH");
    		pp.setScope("internal");
    		pp.setStatus("active");
    		pp.setUpdatedBy("dk");
    		notes = new Note(pp);
    		assertNotNull(notes);
    		
    		

		try {
			notes.setDomainId("");
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST); 
		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);
		}
		notes.setDomainId("domainId");
		try {// domain missing
			//Optional<MultipartFile[]> multipartFiles
			
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
			notes.setDomainId("");
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		} catch(AttributeNotFound e) {
	        thrown.expect(AttributeNotFound.class);
		} catch(Exception e) {
			thrown.expect(Exception.class);
		}
		try {
			// title missing
			notes.setTitle("");
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);

		}
		notes.setTitle("title");
		notes.setNote("note");
		try {
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
		}catch(AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);
		}
		notes.setDomainId("domainId");	
		try {
			notes.setNote("note#");
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
		}catch(ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
			//throw new  ResourceNotValid("spec Chars included");
		}
		
		try {
			notes.setNote(" ");
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}


		try {
			for(int i=0; i<4005; i++ ) {nt.append("1");}
			notes.setNote(nt.toString());
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		notes.setNote("note");
        notes.setTitle(nt.toString());
		try {
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}

        try {
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
        } catch(ResourceNotValid e) {
	        thrown.expect(ResourceNotValid.class);
        }
        notes.setTitle("title");
        

        try {
        	ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
            notes.setTitle(nt.toString());
        	ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setTitle("title");
		notes.setScope("internal");
		try {
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
		

		try {
			notes.setScope(null);
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
			notes.setScope("scope");
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }		
        notes.setStatus("");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		ValidateUtil.validateStatus(notes);
    	});        
        notes.setStatus("inactive2");
        try {
            ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        

        try {
            notes.setStatus("inactive");
            ValidateUtil.validateStatus(notes);
            notes.setStatus("");
            ValidateUtil.validateStatus(notes);
            notes.setScope("inactive2");
            ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setScope("internal");
        notes.setValidDateBy("12/12/15 11:11:11");
        try {
            ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setValidDateBy("12/12/39 11:11:11");
        notes.setStatus("active");
        ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
        
        try {
        	for(int i=0; i<250; i++ ) {nt.append("1");}
			notes.setTitle(nt.toString());
        	boolean b =  ValidateUtil.getTitleSizeChecked(notes);
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setTitle(" ");
        try {
        	for(int i=0; i<4000; i++ ) {nt.append("1");}
			notes.setNote(nt.toString());
        	boolean b =  ValidateUtil.getNoteSizeChecked(notes);
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        
	        //utils.validateJsonString("{{}");
	        //thrown.expect(JsonProcessingException.class);	        
	        //thrown.expect(JsonMappingException.class);
        
	        //thrown.expect((Matcher<?>) derivedProperties.getWindSiteControllers());
	    	//Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		assertNotNull(ValidateUtil.validateForSpecChars("$", "note"));
	    	//});
	        //thrown.expect(ResourceNotValid.class);

	        ArgumentCaptor<Long> idCapture = ArgumentCaptor.forClass(Long.class);
	        ArgumentCaptor<String> nameCapture = ArgumentCaptor.forClass(String.class);

	        List<Note> notesl = new ArrayList<>();
	        //Mockito.when(mutils.setPaginationMetadata(notesl, noteR)).thenReturn(map) ;
	        
	        //Mockito.doThrow(new AttributeNotFound("title")).when(mutils).validatePostRequest(notes);
		        //when(mock.isOK()).thenReturn(true);
		        //when(mock.isOK()).thenThrow(exception);
		        //doThrow(exception).when(mock).someVoidMethod();
	        //Mockito.doCallRealMethod().when(mutils).validatePostRequest(notes);
	        //Mockito.doThrow(ResourceNotValid.class).when(mutils).validatePostRequest(notes);
	        
	        //Mockito.doCallRealMethod().when(mutils).validatePostRequest(notes);

	        GetNotes gn = new GetNotes();
	        assertTrue(gn != null);
	        gn.setNotes(new ArrayList<>());
	        gn.setPagination(new Pagination());
	        
	        assertTrue(gn.getNotes().isEmpty());
	        assertTrue(gn.getPagination() != null);
        	
	        GetNotes map = ValidateUtil.setPaginationMetadata(notesl, noteR);
	        assertFalse(map.getPagination().getCurrentPage() > 0);
	        assertFalse(map.getPagination().getTotalRecords() > 0);
	        assertFalse(map.getPagination().getTotalPages() > 0);
	        assertTrue(map.getNotes().equals(notesl));

	        //Mockito.doNothing().when(utils).validateJsonString("{}");
	        //org.mockito.verification.VerificationMode
	        //Mockito.verify(mutils, VerificationModeFactory.noInteractions()).validateJsonString("{}");
	        
/*	        Mockito.doNothing().when(mutils).validateDateBy("11/11/11 11:11:11", "updateDate");
	        Mockito.doNothing().when(mutils).validatePostRequest(notes);
	        Mockito.doNothing().when(mutils).validateJsonString("{}");
	        Mockito.doNothing().when(mutils).validatePriority(notes);
*/	        
	        Optional<String> filter = Optional.of("id,domainId,note,title");
	        Optional<String> fields = Optional.of("id,tenantId,name,timeZone,countryCode,subdivisionCode,grParkId,siteId");
	        Optional<Integer> pageIdx = Optional.of(0);
	        Optional<Integer> pageSize = Optional.of(1);
	        Optional<String> sortKey = Optional.of("id");
	        Optional<String> orderDirection = Optional.of("DESC");

	        Note note = new Note();
	        note.setPriority("p");
	        Assertions.assertThrows(ResourceNotValid.class, () -> {
	        	ValidateUtil.validatePriority(note);
			});
	        note.setPriority("HIGH");
	        ValidateUtil.validatePriority(note);
	        note.setPriority("MEDIUM");
	        ValidateUtil.validatePriority(note);
	        note.setPriority("LOW");
	        ValidateUtil.validatePriority(note);
	        
	        note.setPriority(null);
	        note.setStatus(null);
	        Assertions.assertThrows(AttributeNotFound.class, () -> {
	        	ValidateUtil.validatePostRequest(note, null, POST);
	        });
	        note.setDomainId("id");
	        note.setTitle("title");
	        ValidateUtil.validatePostRequest(note, null, POST);
	        ValidateUtil.validatePostRequest(note, getMultipartFiles(), POST);
	        
	        log.info(" getNotesValidated Test done -> " + new Date(System.currentTimeMillis()));
	}
    
    @Test
    public void validatePatchRequestTest() throws AttributeNotFound, IOException{
    	for(int i=0; i<4005; i++ ) {nt.append("1");}
		notes.setCategory("category");
		notes.setCreatedBy("createdBy");
		notes.setCreationDate("12/12/39 11:11:11");
		notes.setDeleted(false);

		notes.setId("id");
		notes.setPriority("HIGH");
		notes.setScope("external");
		notes.setStatus("active");
		notes.setTenantId("tenantId");
		notes.setTitle("title");
		notes.setUpdateDate("12/12/39 11:11:11");
		notes.setUpdatedBy("DK");
		notes.setValidDateBy("12/12/39 11:11:11");
		Optional<MultipartFile[]> optionalFile = Optional.empty();
		try {
			notes.setDomainId("");
			notes.setNote(null);
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST); 
		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);
		}

		try {// domain missing
			notes.setDomainId("domainId");
			notes.setTitle(null);
	    	Assertions.assertThrows(AttributeNotFound.class, () -> {
	    		ValidateUtil.validatePostRequest(notes, null, POST);
	    	});
			
	    	Assertions.assertThrows(AttributeNotFound.class, () -> {
	    		ValidateUtil.validatePostRequest(notes, null, PATCH);
	    	});
	    	
	    	//Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		assertNotNull(ValidateUtil.validateForSpecChars("#$%", "title"));
	    	//});

		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		} catch(AttributeNotFound e) {
	        thrown.expect(AttributeNotFound.class);
		} catch(Exception e) {
			thrown.expect(Exception.class);
		}
		try {
			// title missing
			notes.setTitle("");
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);

		}
		try {
			notes.setTitle("title");
			notes.setNote("note");
		}catch(ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
			//throw new  ResourceNotValid("spec Chars included");
		}
			
		ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
		try {
			notes.setNote("note#");
			ValidateUtil.validateForSpecChars(notes.getNote(), "note");
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
		}catch(ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
			//throw new  ResourceNotValid("spec Chars included");
		}
		
		try {
			notes.setNote(" ");
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}


		try {
			notes.setNote(nt.toString());
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		notes.setNote("note");
        notes.setTitle(nt.toString());
		try {
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		notes.setTitle("#");
        try {
			ValidateUtil.validateForSpecChars(notes.getNote(), "title");
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
        } catch(ResourceNotValid e) {
	        thrown.expect(ResourceNotValid.class);
        }
        try {
        	ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
            notes.setTitle(nt.toString());
        	ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setTitle("title");
		notes.setScope("internal");
		try {
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }

        notes.setStatus("");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		ValidateUtil.validateStatus(notes);
    	});        
        notes.setStatus("inactive2");
        try {
            ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        try {
            notes.setStatus("inactive");
            ValidateUtil.validateStatus(notes);
            notes.setStatus("");
            ValidateUtil.validateStatus(notes);
            notes.setScope("#nactive2");
            ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setScope("internal");
        notes.setValidDateBy("12/12/15 11:11:11");
        try {
            ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setValidDateBy("12/12/39 11:11:11");
        notes.setStatus("active");
        ValidateUtil.validatePostRequest(notes, getMultipartFiles(), POST);
        

        assertTrue(!ValidateUtil.validateForSpecChars("$", "note").isEmpty());
    	
    	// test files:
        try {
        	Assertions.assertThrows(AttributeNotFound.class, () -> {
        		notes.setNote(null);
        		notes.setTitle(null);
        		ValidateUtil.validatePostRequest(notes, null, POST);
        	});
        }catch(AttributeNotFound e) {
        	thrown.expect(AttributeNotFound.class);
        }
    	
        try {
        	Assertions.assertThrows(AttributeNotFound.class, () -> {
                ValidateUtil.validatePostRequest(notes, null, PATCH);
        	});
        }catch(AttributeNotFound e) {
        	thrown.expect(AttributeNotFound.class);
        }
    	
    	
        Note note = new Note();
        note.setPriority("p");
        try {
        	ValidateUtil.validatePriority(note);
        }catch(ResourceNotValid e) {
            Assertions.assertThrows(ResourceNotValid.class, () -> {
            	ValidateUtil.validatePriority(note);
    		});
        }
        note.setPriority("HIGH");
        ValidateUtil.validatePriority(note);
        note.setPriority("MEDIUM");
        ValidateUtil.validatePriority(note);
        note.setPriority("LOW");
        ValidateUtil.validatePriority(note);
	}
	
    //@org.junit.jupiter.api.Test //@Test //   (expected = ResourceNotValid.class)
	//public void resourceNoteValidExceptionTest() {
		//log.info("Test ResourceNoteValidExceptionTest");
       // Mockito.doThrow(new ResourceNotValid("title")).doReturn(new Notes()).when(mutils).validateForSpecChars("$", "title");
        //Mockito.doThrow(new ResourceNotValid("note")).when(mutils).validateForSpecChars("$", "title");
	//}
	
    @org.junit.jupiter.api.Test //@Test //   (expected = AttributeNotFound.class)
	public void attributeNotFoundExceptionTest() {
		log.info("Test validateDateBy(String date, String name)");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		ValidateUtil.validateDateBy("date", "name");
    	});
        	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		ValidateUtil.validateDateBy("01/01/21", "date short");
        	});
    		
    	ValidateUtil.validateDateBy("01/01/39 22:22:22", "date full");

		//Mockito.doThrow(new AttributeNotFound("title")).when(mutils).validateForSpecChars("$", "title");
	}


   @Test  //  (expected = JsonMappingException.class)
	public void jsonMappingExceptionTest(){
		log.info("Test JsonParseException");
    	//Assertions.assertThrows(ResourceNotValid.class, () -> {
			assertNotNull(ValidateUtil.validateForSpecChars("{[#@#$%&^]}", "note"));
		//});
		// Validate for script
		Assertions.assertThrows(ResourceNotValid.class, () -> {
			ValidateUtil.validateForSpecChars("javascript", "note");
		});

		//Mockito.doThrow(new JsonMappingException("json")).when(mutils).validateJsonString("{{{");
	}
	
    @Test  //  (expected = AttributeNotFound.class)
	public void jsonProcessingExceptionTest() {
		log.info("Test JsonParsingException");
		Assertions.assertThrows(JsonParseException.class, () -> {
			ValidateUtil.validateJsonString("dfghdafrgd");
		});
		Assertions.assertThrows(JsonParseException.class, () -> {
			ValidateUtil.validateJsonString("zcxfbzf");
		});
		//Mockito.doThrow(new AttributeNotFound("msg")).when(mutils).validateJsonString("{{{");
	}
    
    @Test
    public void domainTest() {
    	Domain domain = new Domain();
    	assertNotNull(domain.toString());
    	assertTrue(Domain.DOMAIN.ASSET.toString().equals("ASSET"));
    	assertFalse(Domain.DOMAIN.CASE.toString().equals("ASSET"));
    	assertFalse(Domain.DOMAIN.EVENT.toString().equals("ASSET"));
    	assertFalse(Domain.DOMAIN.TASK.toString().equals("ASSET"));
    	assertFalse(Domain.DOMAIN.SITE.toString().equals("ASSET"));
    }
    
    @Test
    public void caseAndTaskNoteTest(){
    	CaseNotes sn = new CaseNotes();
    	sn.setAttachments(new ArrayList<AttachmentData>());
    	assertTrue(sn.getAttachments().isEmpty());
    	sn = getCaseNote();
    	assertFalse(sn.getCategory().isEmpty());
    	assertFalse(sn == null);
    	
       	TaskNotes tn = new TaskNotes();
    	tn.setAttachments(new ArrayList<AttachmentData>());
    	assertTrue(tn.getAttachments().isEmpty());
    	tn =  getTaskNote();
    	assertFalse(tn.getCategory().isEmpty());
    	assertFalse(tn == null);
    }
    
	private Optional<MultipartFile[]> getMultipartFilesOptional() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] fileso = {file};
	    Optional<MultipartFile[]> files = Optional.of(fileso);
	    return files;
	}
	private MultipartFile[] getMultipartFiles() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] files = {file};
	    return files;
	}
    private Note getNote() {
    	Note attachment = new Note();
		attachment = new Note(); //"id", "domainId", "tenantId", "title", "note", 
		//"06/09/2021 12:45:55", "06/10/2021 1:40:55", "06/11/2021 2:00:00", 
		//"HIGH", "503206931", "503206931", "category", "status", "internal", false);
		attachment.setCategory("category");
		attachment.setCreatedBy("createdBy");
		attachment.setCreationDate("creationDate");
		attachment.setDeleted(false);
		attachment.setDomainId("domainId");
		attachment.setId("id");
		attachment.setNote("note");
		attachment.setPriority("priority");
		attachment.setScope(Scope.internal.toString());
		attachment.setStatus("active");
		attachment.setTenantId("tenantId");
		attachment.setTitle("title");
		attachment.setUpdateDate("updateDate");
		attachment.setUpdatedBy("updatedBy");
		attachment.setValidDateBy("validDateBy");
    	return attachment;
    }	
    private CaseNotes getCaseNote() {
    	CaseNotes attachment = new CaseNotes();
		attachment.setCategory("category");
		attachment.setCreatedBy("createdBy");
		attachment.setCreationDate("creationDate");
		attachment.setDeleted(false);
		attachment.setDomainId("domainId");
		attachment.setId("id");
		attachment.setNote("note");
		attachment.setPriority("priority");
		attachment.setScope(Scope.internal.toString());
		attachment.setStatus("active");
		attachment.setTenantId("tenantId");
		attachment.setTitle("title");
		attachment.setUpdateDate("updateDate");
		attachment.setUpdatedBy("updatedBy");
		attachment.setValidDateBy("validDateBy");
    	return attachment;
    }
    private TaskNotes getTaskNote() {
    	TaskNotes attachment = new TaskNotes();
		attachment.setCategory("category");
		attachment.setCreatedBy("createdBy");
		attachment.setCreationDate("creationDate");
		attachment.setDeleted(false);
		attachment.setDomainId("domainId");
		attachment.setId("id");
		attachment.setNote("note");
		attachment.setPriority("priority");
		attachment.setScope(Scope.internal.toString());
		attachment.setStatus("active");
		attachment.setTenantId("tenantId");
		attachment.setTitle("title");
		attachment.setUpdateDate("updateDate");
		attachment.setUpdatedBy("updatedBy");
		attachment.setValidDateBy("validDateBy");
    	return attachment;
    }	

}
