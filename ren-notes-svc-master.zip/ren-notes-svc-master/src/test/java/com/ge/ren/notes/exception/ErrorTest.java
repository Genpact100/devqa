package com.ge.ren.notes.exception;


import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

//import cucumber.api.java.gl.E;
import org.junit.jupiter.api.Test;

import com.ge.ren.notes.exception.Error;

public class ErrorTest {
    @Test
    void codeTest(){
        Error e = new Error();
        e.setErrorCode("code");
        assertEquals("code", e.getErrorCode());
    }

    @Test
    void titleTest() {
        Error e = new Error();
        e.setErrorTitle("title");
        assertEquals("title", e.getErrorTitle());
    }


    @Test
    void detailTest() {
        Error e = new Error();
        e.setErrorDescription("detail");
        assertEquals("detail", e.getErrorDescription());

    }

    @Test
    void errorTest() {
        Error e1 = new Error();
        e1.setTimestamp("System.currentTimeMillis()");
        e1.setErrorCode("code");
        e1.setErrorTitle("title");
        e1.setErrorDescription("detail");
        assertTrue(!e1.equals(null));
        assertTrue(!e1.equals("hello"));
        Error ee = new Error( "System.currentTimeMillis()", "code","title", "detail");
        assertFalse(e1.equals(ee));

    }

}
