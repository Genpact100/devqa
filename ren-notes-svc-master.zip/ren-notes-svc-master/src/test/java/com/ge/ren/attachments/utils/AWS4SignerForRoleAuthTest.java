package com.ge.ren.attachments.utils;

import static com.ge.ren.notes.constants.Constants.REGION;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.ren.notes.utils.ErrorConstantsTest;

import lombok.extern.slf4j.Slf4j;

//@Slf4j
//@SpringBootTest (classes = {AWS4SignerForRoleAuth.class}) 
@TestInstance(Lifecycle.PER_CLASS)
@RunWith(SpringRunner.class)
public class AWS4SignerForRoleAuthTest {

	//@Autowired
	//AWS4SignerForRoleAuth aws;
	
    /** Put access key here **/
    private static final String awsAccessKey = "AKIASMTKVJDF44EXOVFG";
    /** Put secret key here **/
    private static final String awsSecretKey = "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";

	private static final String URL = "https://renewables-uai3031357-attachments-dev.s3.us-east-1.amazonaws.com/attachments/siteNotes/2022-02-10/16445107452791791931615-test-image.png";

    public static final String EMPTY_BODY_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
    public static final String UNSIGNED_PAYLOAD = "UNSIGNED-PAYLOAD";
    
    public static final String SCHEME = "AWS4";
    //public static final String ALGORITHM = "HMAC-SHA512";
    public static final String ALGORITHM = "HMAC-SHA256";
    public static final String TERMINATOR = "aws4_request";
    public static final String HmacSHA512 = "HmacSHA512";
    
    /** format strings for the date/time and date stamps required during signing **/
    public static final String ISO8601BasicFormat = "yyyyMMdd'T'HHmmss'Z'";
    public static final String DateStringFormat = "yyyyMMdd";
    
    protected URL endpointUrl;
    protected String httpMethod;
    protected String serviceName;
    protected String regionName;
    
    protected SimpleDateFormat dateTimeFormat;
    protected SimpleDateFormat dateStampFormat;

	@Test
    public void computeSignatureTest() throws MalformedURLException { 
		//AWS4SignerBase abstractCls = Mockito.mock(
		//		AWS4SignerBase.class, 
		//		Mockito.RETURNS_MOCKS); //.CALLS_REAL_METHODS);
		AWS4SignerForRoleAuth signer = new AWS4SignerForRoleAuth( new URL(URL), "GET", "s3", REGION);
        String result = signer.computeSignature(new HashMap<String, String>(), 
        												new HashMap<String, String>(),
                                                        AWS4SignerBase.UNSIGNED_PAYLOAD, 
                                                        awsAccessKey, 
                                                        awsSecretKey);

		assertFalse(result.isEmpty());
	}
	
	@Test
	public void  getStringToSignTest() throws MalformedURLException {
		AWS4SignerForRoleAuth signer = new AWS4SignerForRoleAuth( new URL(URL), "GET", "s3", REGION);
		
        Date now = new Date();
        String dateTimeStamp = new SimpleDateFormat().format(now);
        endpointUrl = new URL(URL);
        String hostHeader = endpointUrl.getHost();
        if ( endpointUrl.getPort() > -1 ) {
        	hostHeader = hostHeader.concat(":" + Integer.toString(endpointUrl.getPort()));
        }
        Map<String, String> headers =  new HashMap<String, String>();
        headers.put("Host", hostHeader);
        String canonicalizedHeaderNames = signer.getCanonicalizeHeaderNames(headers);
        String canonicalizedHeaders = signer.getCanonicalizedHeaderString(headers);
        String dateStamp = new SimpleDateFormat().format(now);
        String scope =  dateStamp + "/" + regionName + "/" + serviceName + "/" + TERMINATOR;
        Map<String, String> queryParameters = new HashMap<>();
        queryParameters.put("X-Amz-Algorithm", SCHEME + "-" + ALGORITHM);
        queryParameters.put("X-Amz-Credential", awsAccessKey + "/" + scope);
        queryParameters.put("X-Amz-Date", dateTimeStamp);
        queryParameters.put("X-Amz-SignedHeaders", canonicalizedHeaderNames);
        
        // Signature Version 4 ->  the max expiry in seconds for a presigned url = 7 days,
        int expiresIn = 7 * 24 * 60 * 60;
        queryParameters.put("X-Amz-Expires", "" + expiresIn);
        String canonicalizedQueryParameters = signer.getCanonicalizedQueryString(queryParameters);
        
        new AWS4SignerForRoleAuth( new URL(URL), "GET", "s3", REGION);
		String canonicalRequest = AWS4SignerBase.getCanonicalRequest(new URL(URL), "GET",
                canonicalizedQueryParameters, canonicalizedHeaderNames,
                canonicalizedHeaders, UNSIGNED_PAYLOAD);
        // construct the string to be signed
        String result = AWS4SignerBase.getStringToSign(SCHEME, ALGORITHM, dateTimeStamp, scope, canonicalRequest);
        assertFalse(result.isEmpty());
 
	}
	
	
	@Test
	public void getCanonicalizedHeaderStringTest() throws MalformedURLException {
		AWS4SignerForRoleAuth signer = new AWS4SignerForRoleAuth( new URL(URL), "GET", "s3", REGION);
		Map<String, String> headers =  new HashMap<String, String>();
		URL endPointUrl = new URL(URL);
		String hostHeader = endpointUrl.getHost();
        headers.put("Host", hostHeader);
		String result = AWS4SignerBase.getCanonicalizedHeaderString(headers);
		assertFalse(result.isEmpty());
	}
	
}
