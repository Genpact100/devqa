package com.ge.ren.attachments.utils;

import static org.junit.jupiter.api.Assertions.assertFalse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.amazonaws.util.IOUtils;
import lombok.extern.slf4j.Slf4j;

//@Slf4j
@SpringBootTest (classes = {BinaryUtils.class}) 
@TestInstance(Lifecycle.PER_CLASS)
@RunWith(SpringRunner.class)
public class BinaryUtilsTest {
	
	BinaryUtils binaryUtils1;
    
    @BeforeAll
    public void setup() {
    	binaryUtils1 = new BinaryUtils();
    }
    
    @Test
    public void toHexTest() throws IOException {
    	
	    FileInputStream input = new FileInputStream(new File("src/main/resources/attachments/test-image.png"));
        byte[] data = IOUtils.toByteArray(input);
        String th =  BinaryUtils.toHex (data);    
        assertFalse(th.isEmpty());
    }
    
    @Test
    public void fromHexTest() {
    	
    	 byte[] bite =  BinaryUtils.fromHex("8adbb2b0c3161ce41dba3b24d868e29c21060a109b0519113c2d26e2af2b5c3d");
    	 assertFalse(bite.toString().isEmpty());
    }
    
    

}
