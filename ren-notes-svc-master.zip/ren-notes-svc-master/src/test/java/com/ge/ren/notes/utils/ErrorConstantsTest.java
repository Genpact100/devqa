package com.ge.ren.notes.utils;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import org.junit.Ignore;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.ge.ren.notes.constants.ErrorConstants;

import lombok.extern.slf4j.Slf4j;
//@Ignore
@Slf4j
@TestInstance(Lifecycle.PER_CLASS)
//@ActiveProfiles("test")
@SpringBootTest(classes = ErrorConstants.class)
public class ErrorConstantsTest {
	
	@BeforeAll
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }
	
    @AfterAll
    public void tearDown() {}

    @InjectMocks
	DateFormatMS df;
	
    @Test
    public void testConstants() {
    	
    	assertEquals("Authorization_Error : ", ErrorConstants.ErrorCodes.AUTHORIZATION_ERROR.errordescription());
    	assertEquals("Exception_Error_500 : ", ErrorConstants.ErrorCodes.EXCEPTION_ERROR_500.errordescription());
    	assertEquals("Internal server error occurred : ", ErrorConstants.ErrorCodes.INTERNAL_SERVER_ERROR.errordescription());
    	assertEquals("Received Invalid json : ", ErrorConstants.ErrorCodes.JSON_PARSE_FAIL.errordescription());    	
    	assertEquals("MongoClient_Error_500 : ", ErrorConstants.ErrorCodes.MONGOCLIENT_ERROR_500.errordescription());
    	assertEquals("MongoServer_Error_500 : ", ErrorConstants.ErrorCodes.MONGOSERVER_ERROR_500.errordescription());
    	assertEquals("Failed at site group lookup : ", ErrorConstants.ErrorCodes.SITE_GROUP_LOOKUP_ERROR.errordescription());
    	assertEquals("Validation_Error_400 : ", ErrorConstants.ErrorCodes.VALIDATION_ERROR_400.errordescription());
    	
    	assertEquals("Duplicate id's in BomAsRunning : ", ErrorConstants.ErrorCodes.DUPLICATE_IDS.errordescription());
    	assertEquals("Invalid Component Id's : ", ErrorConstants.ErrorCodes.INVALID_COMPONENT_IDS.errordescription());
    	assertEquals("Invalid Component Types : ", ErrorConstants.ErrorCodes.INVALID_COMPONENT_TYPES.errordescription());
    	assertEquals("Invalid Hierarchy Id : ", ErrorConstants.ErrorCodes.INVALID_HIERARCHY_ID.errordescription());
    	
    	assertEquals("[{}] [{}] - {}", ErrorConstants.LOG_PLACE_HOLDER);
    }
    

	@Test 
	public void getCurrentDateFormatedTest() {
		log.info(">> getCurrentDateFormatedTest started");
		String str = df.getCurrentDateFormated();
		assertTrue(!str.isEmpty());
		
		Timestamp ts = df.getcurrentTimestamp();
		assertTrue(ts.getTime() > 0);
		
		ts =  df.covertStringToTimestamp("2021-11-11 11:11:11");
		assertTrue(ts.getTime() > 0);
		ts = df.covertToTimestamp("11/11/11 11:11:11");
		assertTrue(ts.getTime() > 0);
		
		
		ts = df.covertToTimestamp("2021/11/11");
		assertTrue(ts.getTime() > 0);
		log.info(">> getCurrentDateFormatedTest ended");
	}
	
	
	
}
