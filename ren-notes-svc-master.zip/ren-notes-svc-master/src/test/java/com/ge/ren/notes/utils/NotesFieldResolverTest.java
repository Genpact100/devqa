package com.ge.ren.notes.utils;

import static org.apache.commons.lang3.reflect.FieldUtils.getField;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.notes.controller.NotesApiController;
import com.ge.ren.notes.model.Attachment;
import com.ge.ren.notes.model.EventNotes;
import com.ge.ren.notes.model.SiteNotes;
import com.github.rutledgepaulv.qbuilders.structures.FieldPath;

@SpringBootTest(classes = NotesFieldResolver.class)
@AutoConfigureMockMvc
public class NotesFieldResolverTest {
	
	NotesFieldResolver resolver = new NotesFieldResolver();
    //@Autowired
	//private MockMvc mockMvc;   
    @MockBean
    NotesFieldResolver resolv;
    //@MockBean
    //com.ge.ren.common.keycloak.intercept.RequestInterceptor requestInterceptor;
    
	@Test
	public void noteTestResolverTest() {
		String path = "priority==MEDIUM;category==category";
		FieldPath fp = new FieldPath(path);
		//Mockito.when(resolver.apply(fp, SiteNotes.class)).thenReturn( new SiteNotes());
		Class<?> sn = resolver.apply(fp, SiteNotes.class);
		assertFalse(sn.desiredAssertionStatus());
		fp = new FieldPath("note.priority==MEDIUM;category==category");
		//Mockito.when(resolver.apply(fp, SiteNotes.class)).thenReturn( new SiteNotes());
		sn = resolver.apply(fp, SiteNotes.class);
		assertFalse(sn.desiredAssertionStatus());

		//Mockito.verify(resolv.apply(fp, SiteNotes.class));
	}
	
	@Test
	public void noteTestResolverNormalizeTest() {
		Field field = getField(SiteNotes.class, "note.priority", true);
		Class<?> sn = resolver.normalize(field);
		Mockito.when(resolv.normalize(field)).thenReturn(null);
		//Mockito.verify(resolv, Mockito.atLeastOnce()).normalize(field);

		assertTrue(!sn.getCanonicalName().isEmpty());
	}

	@Test
	public void noteTestResolverFirstTypeParamTest() {
		Field field = getField(SiteNotes.class, "priority", true);
		Mockito.when(resolv.getFirstTypeParameterOf(field)).thenReturn(Mockito.any()); //Mockito.any() requestInterceptor); //(Mockito.anyMap());
		//Mockito.verify(resolv, Mockito.atLeastOnce()).getFirstTypeParameterOf(field);
		assertTrue(null == resolv.getFirstTypeParameterOf(field));

	}
	
	@Test
	public void AttachmentTest() {
		Attachment at = new com.ge.ren.notes.model.Attachment();
		at.setContentType("Type");
		at.setFile("file");
		assertNotNull(at);
		assertTrue(at.toString().length() > 0);
		
		EventNotes note = new EventNotes();
		List<AttachmentData> attachments = new ArrayList<>();
		note.setAttachments(attachments);
		assertTrue(note.attachments != null);
		
		
	}

	
}
