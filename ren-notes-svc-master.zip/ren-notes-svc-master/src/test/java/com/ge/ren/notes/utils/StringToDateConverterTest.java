package com.ge.ren.notes.utils;

import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.core.JsonParseException;
import com.ge.ren.notes.exception.ResourceNotValid;

@SpringBootTest(classes = StringToDateConverter.class)
public class StringToDateConverterTest {
	
	@Test
	public void stringConverterTest() {
		
		StringToDateConverter sc = new StringToDateConverter();
		String dateInString = "2021-08-01T11:11:02.000Z";
		Date date =  sc.convert(dateInString);
		
		assertTrue(date.getTime() >0);
		String dateIn = "32021-01-01'T'11:11:11.111'Z'";
		Assertions.assertThrows(ResourceNotValid.class, () -> {
			sc.convert(dateIn);
		});
	}
}
