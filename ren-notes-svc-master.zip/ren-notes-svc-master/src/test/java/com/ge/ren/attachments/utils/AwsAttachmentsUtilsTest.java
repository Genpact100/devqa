package com.ge.ren.attachments.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;
import org.assertj.core.util.Arrays;
import org.hamcrest.Matcher;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.verification.VerificationMode;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.VerificationModeFactory;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.PostAttachment;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.utils.DateFormatMS;

import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import static com.ge.ren.notes.constants.Constants.*;
@Slf4j
//@ActiveProfiles("dev")
@TestInstance(Lifecycle.PER_CLASS)
@RunWith(SpringRunner.class)
@SpringBootTest (classes = AwsUploader.class)
@AutoConfigureMockMvc
public class AwsAttachmentsUtilsTest {
	
    @Rule
    public ExpectedException thrown = ExpectedException.none();
	
	@MockBean
    DateFormatMS dateFormat; 

    @MockBean
    Autils utils;
    
    @MockBean
    com.ge.ren.attachments.utils.FileUploader fielUploader;
    @Autowired
    AwsUploader awsUploader;
	
    @Value("${storage.type:s3aws}")
	private String storageType;
    
    @Value("${aws.bucket.prefix:TODO_add_to_properties}")
	private String bucket;
    
    @Value("${aws.region:us-east-1}")
    private String region;
	
    @Value("${aws.folder:attachments}")
    private String folder;
    
    @Value("${AWS_S3_KMS_KEY:TODO_ADD_KMS_KEY_TO_PROPS}")
    private String kmsKey;

	String json = null;
    
	@BeforeAll
    public void setup() {
		StringBuilder nt = new StringBuilder("aaa");

		Note notes = new Note();
		for(int i=0; i<2505; i++ ) {
			nt.append("1");
		}
        MockitoAnnotations.initMocks(this);
        AttachmentUtilHelper utils2 = Mockito.mock(AttachmentUtilHelper.class);
        json = "{ \"domainId\": \"500023\", \"note\": \"Si teote\", \"title\": \"Sit etle\", \"priority\": \"MEDIUM\",  \"category\": \"category\", \"scope\": \"internal\", \"status\": \"active\", \"validDateBy\": \"07/30/21 01:01:01\"}";
		notes.setCategory("category");
		notes.setCreatedBy("createdBy");
		notes.setCreationDate("12/12/39 11:11:11");
		notes.setDeleted(false);

		notes.setId("id");
		notes.setPriority("HIGH");
		notes.setScope("external");
		notes.setStatus("active");
		notes.setTenantId("tenantId");
		//notes.setTitle("title");
		notes.setUpdateDate("12/12/39 11:11:11");
		notes.setUpdatedBy("DK");
		notes.setValidDateBy("12/12/39 11:11:11");
    }
	int nameSize=10;
	int	titleSize=5;
    @After
    public void tearDown() {}
    
    private static ByteBuffer getRandomByteBuffer(int size) throws IOException {
        byte[] b = new byte[size];
        new Random().nextBytes(b);
        return ByteBuffer.wrap(b);
    }
    

    
    @Test
    public void awsUploadAttachmentTest() throws IOException {
    	String fileName = "test1.txt";  
       // S3Client s3 = S3Client.builder().region(software.amazon.awssdk.regions.Region.US_EAST_1).build();
        log.debug("save test file into aws3");
        
        MultipartFile multipartFile = new MockMultipartFile("test1.txt", "Hello World".getBytes());
        File file = new File("attachments/test1.txt");
        try (OutputStream os = new FileOutputStream(file)) {
            os.write(multipartFile.getBytes());
        }
        FileInputStream inputFile = new FileInputStream( "attachments/test1.txt");  
        MockMultipartFile mfile = new MockMultipartFile("file", "NameOfTheFile", "multipart/form-data", inputFile); 
        mfile = new MockMultipartFile("data", "filename.kml", "text/plain", "some kml".getBytes());
    	byte[] bytes = mfile.getBytes();
        try (InputStream inputStream = new ByteArrayInputStream(bytes)) {
	        file = new File(fileName);
        	byte[] byteArray = IOUtils.toByteArray(inputStream);
	        PutObjectRequest putRequest = PutObjectRequest.builder().bucket(bucket).key(fileName + "test").build();
	        Optional<MultipartFile[]> optionalFile = Optional.empty();
	        //List<AttachmentData> list = awsUploader.uploadFiles("case", optionalFile.get() );  //.getObject(bucket, "README.md");
	        ObjectMetadata objectMetaData = new ObjectMetadata();
	        objectMetaData.setSSEAlgorithm("aws:kms");
	    	objectMetaData.setContentLength(byteArray.length);
	    	objectMetaData.addUserMetadata("x-amx-meta-title", "2,2");
	        
	        byte[] resultByte = DigestUtils.md5(byteArray);
	        String streamMD5 = new String(Base64.encodeBase64(resultByte));
	        objectMetaData.setContentMD5(streamMD5);
	        log.debug(">>>>>>>>>>>>> awsUploadAttachmentTest DONE!  <<<<<<<<<<<<<<<< " );
        }catch(Exception e) {
        	e.getStackTrace();
        }
    }


    @Test
    public void validateForJsonTest() {
    	
    	try {
        	String str = AttachmentUtilHelper.validateForSpecChars("{}", "field");
        	assertTrue(!str.isEmpty());
        	json = "{ \"domainId\": \"500023\", \"note\": \"Si teote\", \"title\": \"Sit etle\", \"priority\": \"MEDIUM\",  \"category\": \"category\", \"scope\": \"internal\", \"status\": \"active\", \"validDateBy\": \"07/30/21 01:01:01\"}";
        	
			AttachmentUtilHelper.validateJsonString("{}");
			json+= "123";
			AttachmentUtilHelper.validateJsonString(json);
		} catch (IOException e) {
			thrown.expect(IOException.class);
			thrown.expect(ResourceNotValid.class);
			thrown.expect(JsonParseException.class);
		}
    	
    }
    
    @org.junit.jupiter.api.Test 
	public void getNotesValidatedPostTest() throws AttributeNotFound, IOException{
		StringBuilder nt = new StringBuilder("aaa");
		Note notes = new Note();

		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		log.info("Start getNotesValidated Test " + new Date(System.currentTimeMillis()));
		notes.setCategory("category");
		notes.setCreatedBy("createdBy");
		notes.setCreationDate("12/12/39 11:11:11");
		notes.setDeleted(false);

		notes.setId("id");
		notes.setPriority("HIGH");
		notes.setScope("external");
		notes.setStatus("active");
		notes.setTenantId("tenantId");
		notes.setTitle("title");
		notes.setUpdateDate("12/12/39 11:11:11");
		notes.setUpdatedBy("DK");
		notes.setValidDateBy("12/12/39 11:11:11");
		
        Optional<String> optionalStr = Optional.empty();
        Optional<Integer> optionalInt = Optional.empty();
        NotesRequest noteR = new NotesRequest();
        noteR.setDomain("sites");
        noteR.setDomainIds("domainIds");
        noteR.setFilter("id,title,note,domainId,category,updatedBy");
        noteR.setPageIdx(0);
        noteR.setPageSize(5);
        noteR.setTenantId("tenantId");
        noteR.setQuery("priority==MEDIUM;category==category");
        noteR.setBody(notes);
		
        
		
		try {
			notes.setDomainId("");
			AttachmentUtilHelper.validatePostRequest(notes, "post"); 
		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);
		}
		notes.setDomainId("domainId");
		try {// domain missing
			
			AttachmentUtilHelper.validatePostRequest(notes, "post");
			notes.setDomainId("");
			AttachmentUtilHelper.validatePostRequest(notes, "post"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		} catch(AttributeNotFound e) {
	        thrown.expect(AttributeNotFound.class);
		} catch(Exception e) {
			thrown.expect(Exception.class);
		}
		try {
			// title missing
			notes.setTitle("");
			AttachmentUtilHelper.validatePostRequest(notes, "post");
		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);

		}
		notes.setTitle("title");
		notes.setNote("note");
		try {
			AttachmentUtilHelper.validatePostRequest(notes, "post");
		}catch(AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);
		}
		notes.setDomainId("domainId");	
		try {
			notes.setNote("note#");
			AttachmentUtilHelper.validatePostRequest(notes, "post");
		}catch(ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
			//throw new  ResourceNotValid("spec Chars included");
		}
		
		try {
			notes.setNote(" ");
			AttachmentUtilHelper.validatePostRequest(notes, "post"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}


		try {
			for(int i=0; i<2505; i++ ) {nt.append("1");}
			notes.setNote(nt.toString());
			AttachmentUtilHelper.validatePostRequest(notes, "post"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		notes.setNote("note");
        notes.setTitle(nt.toString());
		try {
			AttachmentUtilHelper.validatePostRequest(notes, "post"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}

        try {
			AttachmentUtilHelper.validatePostRequest(notes, "post");
        } catch(ResourceNotValid e) {
	        thrown.expect(ResourceNotValid.class);
        }
        notes.setTitle("title");
        

        try {
        	AttachmentUtilHelper.validatePostRequest(notes, "post");
            notes.setTitle(nt.toString());
        	AttachmentUtilHelper.validatePostRequest(notes, "post");
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setTitle("title");
		notes.setScope("internal");
		try {
			AttachmentUtilHelper.validatePostRequest(notes, "post");
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }

        notes.setStatus("");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		AttachmentUtilHelper.validateStatus(notes);
    	});        
        notes.setStatus("inactive2");
        try {
            AttachmentUtilHelper.validatePostRequest(notes, "post");        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        

        try {
            notes.setStatus("inactive");
            AttachmentUtilHelper.validateStatus(notes);
            notes.setStatus("");
            AttachmentUtilHelper.validateStatus(notes);
            notes.setScope("inactive2");
            AttachmentUtilHelper.validatePostRequest(notes, "post");        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setScope("internal");
        notes.setValidDateBy("12/12/15 11:11:11");
        try {
            AttachmentUtilHelper.validatePostRequest(notes, "post");        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setValidDateBy("12/12/39 11:11:11");
        notes.setStatus("active");
        AttachmentUtilHelper.validatePostRequest(notes, "post");
        
        
	        //utils.validateJsonString("{{}");
	        //thrown.expect(JsonProcessingException.class);	        
	        //thrown.expect(JsonMappingException.class);
        
	        //thrown.expect((Matcher<?>) derivedProperties.getWindSiteControllers());
	    	Assertions.assertThrows(ResourceNotValid.class, () -> {
	    		AttachmentUtilHelper.validateForSpecChars("$", "note");
	    	});
	        //thrown.expect(ResourceNotValid.class);

	        ArgumentCaptor<Long> idCapture = ArgumentCaptor.forClass(Long.class);
	        ArgumentCaptor<String> nameCapture = ArgumentCaptor.forClass(String.class);


	        //Mockito.when(mutils.setPaginationMetadata(notesl, noteR)).thenReturn(map) ;
	        
	        //Mockito.doThrow(new AttributeNotFound("title")).when(mutils).validatePostRequest(notes);
		        //when(mock.isOK()).thenReturn(true);
		        //when(mock.isOK()).thenThrow(exception);
		        //doThrow(exception).when(mock).someVoidMethod();
	        //Mockito.doCallRealMethod().when(mutils).validatePostRequest(notes);
	        //Mockito.doThrow(ResourceNotValid.class).when(mutils).validatePostRequest(notes);
	        
	        //Mockito.doCallRealMethod().when(mutils).validatePostRequest(notes);

	        //GetAttachments map = utils.setPaginationMetadata(attachments, nr);
	        //assertNull(map);
	        //assertFalse(map.getPagination().getTotalRecords() > 0);
	        //assertFalse(map.getPagination().getTotalPages() > 0);
	        //assertTrue(map.getAttachments().equals(attachments));
	        //assertTrue(map.getAttachments().isEmpty());

	        //Mockito.doNothing().when(utils).validateJsonString("{}");
	        //org.mockito.verification.VerificationMode
	        //Mockito.verify(mutils, VerificationModeFactory.noInteractions()).validateJsonString("{}");
	        
/*	        Mockito.doNothing().when(mutils).validateDateBy("11/11/11 11:11:11", "updateDate");
	        Mockito.doNothing().when(mutils).validatePostRequest(notes);
	        Mockito.doNothing().when(mutils).validateJsonString("{}");
	        Mockito.doNothing().when(mutils).validatePriority(notes);
	        notes.setPriority("HIGH");
	        Mockito.doNothing().when(mutils).validatePriority(notes);
	        Mockito.doNothing().when(mutils).validateScope(notes);
	        notes.setScope("external");
	        Mockito.doNothing().when(mutils).validateScope(notes);
	        Mockito.doNothing().when(mutils).validateStatus(notes);
	        notes.setStatus("active");
	        Mockito.doNothing().when(mutils).validateStatus(notes);
	        NotesRequest request = new NotesRequest();
*/	        
	        Optional<String> filter = Optional.of("id,domainId,note,title");
	        Optional<String> fields = Optional.of("id,tenantId,name,timeZone,countryCode,subdivisionCode,grParkId,siteId");
	        Optional<Integer> pageIdx = Optional.of(0);
	        Optional<Integer> pageSize = Optional.of(1);
	        Optional<String> sortKey = Optional.of("id");
	        Optional<String> orderDirection = Optional.of("DESC");

	        
	        
	        Note note = new Note();
	        note.setPriority("p");
	        Assertions.assertThrows(ResourceNotValid.class, () -> {
	        	AttachmentUtilHelper.validatePriority(note);
			});
	        note.setPriority("HIGH");
	        AttachmentUtilHelper.validatePriority(note);
	        note.setPriority("MEDIUM");
	        AttachmentUtilHelper.validatePriority(note);
	        note.setPriority("LOW");
	        AttachmentUtilHelper.validatePriority(note);
	        
	        log.info(" getNotesValidated Test done -> " + new Date(System.currentTimeMillis()));
	}
    
    @Test
    public void validatePatchRequestTest() throws AttributeNotFound, IOException{
		StringBuilder nt = new StringBuilder("aaa");
		Note notes = new Note();

    	for(int i=0; i<2505; i++ ) {nt.append("1");}
		notes.setCategory("category");
		notes.setCreatedBy("createdBy");
		notes.setCreationDate("12/12/39 11:11:11");
		notes.setDeleted(false);

		notes.setId("id");
		notes.setPriority("HIGH");
		notes.setScope("external");
		notes.setStatus("active");
		notes.setTenantId("tenantId");
		notes.setTitle("title");
		notes.setUpdateDate("12/12/39 11:11:11");
		notes.setUpdatedBy("DK");
		notes.setValidDateBy("12/12/39 11:11:11");
		
		try {
			notes.setDomainId("");
			notes.setNote(null);
			AttachmentUtilHelper.validatePostRequest(notes, "patch"); 
		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);
		}

		try {// domain missing
			notes.setDomainId("domainId");
			AttachmentUtilHelper.validatePostRequest(notes, "patch");
			notes.setDomainId("");
			AttachmentUtilHelper.validatePostRequest(notes, "patch"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		} catch(AttributeNotFound e) {
	        thrown.expect(AttributeNotFound.class);
		} catch(Exception e) {
			thrown.expect(Exception.class);
		}
		try {
			// title missing
			notes.setTitle("");
			AttachmentUtilHelper.validatePostRequest(notes, "patch");
		} catch(com.ge.ren.notes.exception.AttributeNotFound e) {
			thrown.expect(AttributeNotFound.class);

		}
		try {
			notes.setTitle("title");
			notes.setNote("note");
		}catch(ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
			//throw new  ResourceNotValid("spec Chars included");
		}
			
		AttachmentUtilHelper.validatePostRequest(notes, "patch");
		try {
			notes.setNote("note#");
			AttachmentUtilHelper.validateForSpecChars(notes.getNote(), "note");
			AttachmentUtilHelper.validatePostRequest(notes, "patch");
		}catch(ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
			//throw new  ResourceNotValid("spec Chars included");
		}
		
		try {
			notes.setNote(" ");
			AttachmentUtilHelper.validatePostRequest(notes, "patch"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}


		try {
			notes.setNote(nt.toString());
			AttachmentUtilHelper.validatePostRequest(notes, "patch"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		notes.setNote("note");
        notes.setTitle(nt.toString());
		try {
			AttachmentUtilHelper.validatePostRequest(notes, "patch"); 
		} catch(com.ge.ren.notes.exception.ResourceNotValid e) {
			thrown.expect(ResourceNotValid.class);
		}
		notes.setTitle("#");
        try {
			AttachmentUtilHelper.validateForSpecChars(notes.getNote(), "title");
			AttachmentUtilHelper.validatePostRequest(notes, "patch");
        } catch(ResourceNotValid e) {
	        thrown.expect(ResourceNotValid.class);
        }
        try {
        	AttachmentUtilHelper.validatePostRequest(notes, "patch");
            notes.setTitle(nt.toString());
        	AttachmentUtilHelper.validatePostRequest(notes, "patch");
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setTitle("title");
		notes.setScope("internal");
		try {
			AttachmentUtilHelper.validatePostRequest(notes, "patch");
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }

        notes.setStatus("");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		AttachmentUtilHelper.validateStatus(notes);
    	});        
        notes.setStatus("inactive2");
        try {
            AttachmentUtilHelper.validatePostRequest(notes, "patch");        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        

        try {
            notes.setStatus("inactive");
            AttachmentUtilHelper.validateStatus(notes);
            notes.setStatus("");
            AttachmentUtilHelper.validateStatus(notes);
            notes.setScope("#nactive2");
            AttachmentUtilHelper.validatePostRequest(notes, "patch");        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setScope("internal");
        notes.setValidDateBy("12/12/15 11:11:11");
        try {
            AttachmentUtilHelper.validatePostRequest(notes, "patch");        	
        }catch(ResourceNotValid e) {
        	thrown.expect(ResourceNotValid.class);
        }
        notes.setValidDateBy("12/12/39 11:11:11");
        notes.setStatus("active");
        AttachmentUtilHelper.validatePostRequest(notes, "patch");
        
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		AttachmentUtilHelper.validateForSpecChars("$", "note");
    	});
        Note note = new Note();
        note.setPriority("p");
        try {
        	AttachmentUtilHelper.validatePriority(note);
        }catch(ResourceNotValid e) {
            Assertions.assertThrows(ResourceNotValid.class, () -> {
            	AttachmentUtilHelper.validatePriority(note);
    		});
        }
        note.setPriority("HIGH");
        AttachmentUtilHelper.validatePriority(note);
        note.setPriority("MEDIUM");
        AttachmentUtilHelper.validatePriority(note);
        note.setPriority("LOW");
        AttachmentUtilHelper.validatePriority(note);
	}
	

	
    @org.junit.jupiter.api.Test //@Test //   (expected = AttributeNotFound.class)
	public void AttributeNotFoundExceptionTest() {
		log.info("Test validateDateBy(String date, String name)");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
    		AttachmentUtilHelper.validateDateBy("date", "name");
    	});
        	Assertions.assertThrows(ResourceNotValid.class, () -> {
        		AttachmentUtilHelper.validateDateBy("01/01/21", "date short");
        	});
    		
    	AttachmentUtilHelper.validateDateBy("01/01/39 22:22:22", "date full");

		//Mockito.doThrow(new AttributeNotFound("title")).when(mutils).validateForSpecChars("$", "title");
	}


    @org.junit.jupiter.api.Test  //  (expected = JsonMappingException.class)
	public void JsonMappingExceptionTest(){
		log.info("Test JsonParseException");
    	Assertions.assertThrows(ResourceNotValid.class, () -> {
			AttachmentUtilHelper.validateForSpecChars("{[#]}", "post");
		});
		// Validate for script
		Assertions.assertThrows(ResourceNotValid.class, () -> {
			AttachmentUtilHelper.validateForSpecChars("#javasscript", "patch");
		});

		//Mockito.doThrow(new JsonMappingException("json")).when(mutils).validateJsonString("{{{");
	}
	
    @org.junit.jupiter.api.Test //@Test //  (expected = AttributeNotFound.class)
	public void JsonProcessingExceptionTest() {
		log.info("Test JsonParsingException");
		Assertions.assertThrows(JsonParseException.class, () -> {
			AttachmentUtilHelper.validateJsonString("dfghdafrgd");
		});
		Assertions.assertThrows(JsonParseException.class, () -> {
			AttachmentUtilHelper.validateJsonString("zcxfbzf");
		});
		//Mockito.doThrow(new AttributeNotFound("msg")).when(mutils).validateJsonString("{{{");
	}
    
    

}
