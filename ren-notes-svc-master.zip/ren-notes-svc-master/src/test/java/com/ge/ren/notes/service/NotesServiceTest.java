package com.ge.ren.notes.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Optional;

import org.junit.Rule;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.mongodb.InvalidMongoDbApiUsageException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.amazonaws.util.IOUtils;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.Attachments;
import com.ge.ren.attachments.model.patch.Attachment;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.model.patch.Patch;
import com.ge.ren.attachments.utils.AwsUploader;
import com.ge.ren.attachments.utils.FileUploader;
import com.ge.ren.attachments.utils.PatchHelper;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.model.FailedNote;
import com.ge.ren.notes.model.GetNotes;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.Pagination;
import com.ge.ren.notes.model.PatchNote;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.model.SiteNotes;
import com.ge.ren.notes.model.UpsertNote;
import com.ge.ren.notes.constants.Constants;
import com.ge.ren.notes.constants.Priority;
import com.ge.ren.notes.constants.Scope;
import com.ge.ren.notes.constants.Status;
import com.ge.ren.notes.repository.SiteNotesRepository;
import com.ge.ren.notes.service.impl.NotesServiceImpl;
import com.ge.ren.notes.utils.ApiUtil;
import com.ge.ren.notes.utils.DateFormatMS;
import com.ge.ren.notes.utils.JacksonConfiguration;
import com.ge.ren.notes.utils.ValidateUtil;
import com.github.fge.jsonpatch.JsonPatchException;
import org.springframework.data.mongodb.core.BulkOperations;

import lombok.extern.slf4j.Slf4j;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
@Slf4j
@SpringBootTest (classes = {NotesServiceImpl.class}) 
@TestInstance(Lifecycle.PER_CLASS)
@RunWith(SpringRunner.class)

public class NotesServiceTest {

	@Rule
	public ExpectedException thrown = ExpectedException.none();

    @MockBean
    SiteNotesRepository repository;

 	@MockBean
 	MongoTemplate mongoTemplate;
 	
 	@MockBean
    JacksonConfiguration jc;   
    
 	@MockBean
    ApiUtil  apiUtil;
    
 	@MockBean
    DateFormatMS dateFormat;
    
 	@MockBean
    FileUploader fileUploader;
    
 	@MockBean
    AwsUploader awsUploader;
    
    @MockBean
    ObjectMapper objectMapper;
    
    @MockBean
    PatchHelper patchHelper;

    @MockBean
    ValidateUtil validateUtil;
    
    @MockBean
   	RequestInterceptor requestInterceptor;
    
    @Mock
    private BulkOperations bulkOperations;
    
    @Autowired
    NotesServiceImpl service;
	
    static final String ROOT_URL = "/utils/";
    
    // MockWebServer mockBackEnd;
	//private MongoOperations mongoOperations=mock(MongoOperations.class);

    
    String baseUrl;
    
    @Autowired
    private WebApplicationContext webApplicationContext;

    
	PostNote pn = getPostNote();
	Note notes = new Note();
	NotesRequest noteR = new NotesRequest();
	@BeforeEach
    void setUp() throws IOException, JsonPatchException {
		System.setProperty("spring.profiles.active", "dev");
		MockitoAnnotations.initMocks(this);
		when(mongoTemplate.count(any(), anyString())).thenReturn(new Long(1));
		when(mongoTemplate.save(any(), anyString())).thenReturn(getNote());
		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(getNote());
		when(mongoTemplate.findAndModify(any(), any(), any())).thenReturn(getNote());
		List<Object> list = new ArrayList<Object>();
		list.add(getNote());
		when(mongoTemplate.find(any(), any())).thenReturn(list);
		
		when(jc.getOMconfiguration(any())).thenReturn(objectMapper);
		Note note = getNote();
		List<Note> notes = new ArrayList <>();
		notes.add(note);
		when(apiUtil.getNotesByDomain(any(), any())).thenReturn(notes);
		List<AttachmentData> alist = new ArrayList<>();
		when(fileUploader.uploadFiles( anyString(), any())).thenReturn(alist);
		
		when(objectMapper.writeValueAsString(any())).thenReturn("{}");
		when(patchHelper.applyPatch(any(), anyString())).thenReturn(getNote());
		
       	when(dateFormat.getCurrentDateFormated()).thenReturn("10/10/25 10:10:10");
		when(objectMapper.writeValueAsString(any())).thenReturn(new  ObjectMapper().writeValueAsString(getJsonPatch()));
		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(getNote());
		when(awsUploader.removeS3Object(anyString())).thenReturn(true);

		when(apiUtil.getCriteriaFromQueryParser(any(), any())).thenReturn(new Query());
		
		when(requestInterceptor.getTenantId()).thenReturn("tenantid");
        when(requestInterceptor.getUsername()).thenReturn("name");
        when(apiUtil.retrieveTenantId(requestInterceptor)).thenReturn("tenantId");
        when(apiUtil.retrieveUserName(requestInterceptor)).thenReturn("tenantName");
        List<String> capabilitiesList = new ArrayList<>();
        capabilitiesList.add(Constants.NOTES_AND_ATTACHMENTS);
        capabilitiesList.add(Constants.INTERNAL_ACCESS);
        List<String> roleList = new ArrayList<>();
        roleList.add(Constants.ROLE_SUPER_ADMIN);
        when(requestInterceptor.getUserCapabilities()).thenReturn(capabilitiesList);
        when(requestInterceptor.getUserRoles()).thenReturn(roleList);        
        when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("internal");

    }

    @AfterAll
    void tearDown() throws IOException {
        
    }

    
    @BeforeEach
    public void setup() {
    }
    public static void enqueueMockResponse(MockWebServer mockBackEnd, int status, String body) {
        if (body != null) {
            mockBackEnd.enqueue(new MockResponse()
                    .setHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                    .setResponseCode(status)
                    .setBody(body));
        } else {
            mockBackEnd.enqueue(new MockResponse()
                    .setHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                    .setResponseCode(status));
        }
    }

	@Test
	void NotesServiceBaseTest() throws Exception {
		System.out.println(">>>> get Notes Service Test start...  " + new Date() );
		Note notes = new Note();
		assertTrue(null != notes);
		assertFalse(notes.toString().isEmpty());
		notes = new Note(); //"id", "domainId", "tenantId", "title", "note", 
				//"06/09/2021 12:45:55", "06/10/2021 1:40:55", "06/11/2021 2:00:00", 
				//"HIGH", "503206931", "503206931", "category", "status", "internal", false);
		assertTrue(null != notes);
		notes.setCategory("category");
		notes.setCreatedBy("createdBy");
		notes.setCreationDate("08/22/21 22:22:22");
		notes.setDeleted(false);
		notes.setDomainId("domainId");
		notes.setId("id");
		notes.setNote("note");
		notes.setPriority("priority");
		notes.setScope(Scope.internal.toString());
		notes.setStatus("active");
		notes.setTenantId("tenantId");
		notes.setTitle("title");
		notes.setUpdateDate("08/22/22 22:22:22");
		notes.setUpdatedBy("updatedBy");
		notes.setValidDateBy("08/22/25 22:22:22");
		
		assertTrue(!notes.getCategory().isEmpty());
		assertTrue(!notes.getDeleted());
		assertTrue(!notes.getCreatedBy().isEmpty());
		assertTrue(!notes.getCreationDate().isEmpty());
		assertTrue(!notes.getDomainId().isEmpty());
		assertTrue(!notes.getId().isEmpty());
		assertTrue(!notes.getNote().isEmpty());
		assertTrue(!notes.getPriority().isEmpty());
		//assertTrue(!notes.getScope().internal.name().isEmpty());
		assertTrue(!notes.getScope().isEmpty());
		assertTrue(!notes.getStatus().isEmpty());
		assertTrue(!notes.getTenantId().isEmpty());
		assertTrue(!notes.getTitle().isEmpty());
		assertTrue(!notes.getUpdateDate().isEmpty());
		assertTrue(!notes.getUpdatedBy().isEmpty());
		assertTrue(!notes.getValidDateBy().isEmpty());
		
        Optional<String> optionalStr = Optional.empty();
        Optional<Integer> optionalInt = Optional.empty();
        NotesRequest noteR = getNoteRequest(); 
        
        List<Note> noteL = new ArrayList<>();
        //get all
        //enqueueMockResponse(mockBackEnd, 200, "OK");
        //service = new NotesServiceImpl(); 

        log.info(">>>> Notes Request >>"+ noteR);
        assertTrue(null != service);

        try {
        	noteR.setBody(pn);
        	noteR.setPageSize(10);
        	SiteNotes sn = new SiteNotes();
        	sn.setId("id");
        	when(repository.findById("id")).thenReturn(Optional.of(sn));
        	ResponseEntity<Object> value = new ResponseEntity<Object> ("1", HttpStatus.CREATED);

        	assertTrue(null != value);
        	String id = "id";
            when(repository.count()).thenReturn((long) 1);

            ResponseEntity<Object> idr = service.processDeleteRequest(noteR, SiteNotes.class);
            assertThat(!idr.getStatusCode().is2xxSuccessful() );

            String snote = service.processGetRequest(noteR);
            assertTrue(null != snote);
            
            
            
        } catch (NullPointerException e){
            assertThat(null == e);

        }catch(IOException ex) {
            assertThat(ex.getMessage().contains("IO")).isTrue();
        }
        
        //get 1
        noteR.setDomainIds("domainIds");
        // get by domainid
        noteR.setId("id");
        doNothing().when(repository).delete(any());
        try {
	        ResponseEntity<Object> ret = service.processDeleteRequest(noteR, SiteNotes.class);
	        assertThat(null == ret).isFalse();
        }catch(ResourceNotValid e) {
        	 assertThat(e.getMessage().contains("Resource")).isTrue();
        }
        Optional<SiteNotes> sn = Optional.empty();
        when(repository.findById(anyString())).thenReturn(Optional.empty());

        System.out.println(" >>>> get Notes Service Test done...  " + new Date() );
	}
	
	@Test
	public void processUpdateLinksTest(){
		List<Note> list = new ArrayList<>();
		list.add(getNote());
		list = service.processUpdateLinks( "id", list, "siteNotes");
		assertTrue(!list.isEmpty());
		//List<Note> list2 = new ArrayList<>();
		//assertDoesNotThrow(() -> service.processUpdateLinks( null , list2, null));
		Assertions.assertThrows(Exception.class, () -> {
			service.processUpdateLinks( null , null, null);
		});
	}
	
	
	
	@Test
	void requestNoteTest() {
	    Optional<String> optionalStr = Optional.empty();
	    Optional<Integer> optionalInt = Optional.empty();
        NotesRequest noteR = new NotesRequest();
        NotesRequest r1 =  noteR;
        assertTrue(noteR.equals(r1));
		assertTrue(noteR.toString().length() > 0);
        noteR.setDomain("siteNotes");
        noteR.setDomainIds("domainIds");
        noteR.setFilter("id,title,note,domainId,category,updatedBy");
        noteR.setPageIdx(0);
        noteR.setPageSize(5);
        noteR.setTenantId("tenantId");
        noteR.setBody(notes);
        noteR.setQuery("priority==MEDIUM;category==category");
		assertFalse(noteR.equals(new NotesRequest()));
        noteR = new NotesRequest("sites", null, "tenantId", null, null, "Dmitry");
		assertFalse(noteR.equals(new NotesRequest()));
		noteR = new NotesRequest("1","1","1","1", 1,1,new Object(), "1","1","1","1","1",1,null, null);
		assertFalse(noteR.equals(new NotesRequest()));
		
		
	}
	

        @Test
        public void testSend() throws Exception{
            String jsonStr = "{\n" + 
            		"\"domainId\": \"500023\",\n" + 
            		"\"domainName\": \"case\",\n" + 
            		"\"description\": \"This placeholder is for Description\",\n" + 
            		"\"title\": \"text for title\"\n" + 
            		"}";

            Resource fileResource = new ClassPathResource( "attachments/test1.txt");

            assertNotNull(fileResource);

            MockMultipartFile firstFile = new MockMultipartFile( 
                       "file", fileResource.getFilename(),
                        MediaType.MULTIPART_FORM_DATA_VALUE,
                        fileResource.getInputStream());  
                        assertNotNull(firstFile);


            MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

            mockMvc.perform(MockMvcRequestBuilders
                   .multipart("/common/v1/attachments")
                    .file(firstFile)
                    .param("json", jsonStr))
                    .andExpect(org.springframework.test.web.servlet.ResultMatcher.matchAll());
            }
	
	//@Test
	public void processPostNoteTest() throws IOException {
		noteR.setId("id");
		noteR.setDomain("siteNotes");
        try {
        	
		    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
		    MockMultipartFile[] fileso = {file};
		    Optional<MultipartFile[]> files = Optional.of(fileso);
            ResponseEntity<?> ret = service.processPostRequest(noteR, files);
            assertFalse(ret.getBody().toString().isEmpty());
            
        }
        catch (ApiException e){
            assertThat(e.getMessage().contains("Note")).isTrue();
        }catch(Exception e) {
        	assertThat(null == e);
        }
        noteR.setBody(pn);	
		Note notes = new Note (((PostNote)noteR.getBody()));
		
		
		try {
			ValidateUtil.validatePostRequest(notes, getMultipartFiles(), "post");	
		}catch(ResourceNotValid e) {
			assertThat(e.getMessage().contains("Scope"));
			
		}
		
		PostNote pn = getPostNote(); //noteR.getBody());
		noteR.setBody(pn);
		pn.setTitle(ValidateUtil.validateForSpecChars(pn.getTitle(), "title"));
		pn.setNote(ValidateUtil.validateForSpecChars(pn.getNote(), "note"));
		noteR = null;
		try {
			ResponseEntity<?> ret = service.processPostRequest(noteR, null);	
		}catch(Exception e) {
			assertThat(null == e);
		}
		
		
		

		
		// validate for Error
        try {
        	
        	when(dateFormat.getCurrentDateFormated()).thenReturn("10/10/25 10:10:10");
    		when(objectMapper.writeValueAsString(any())).thenReturn(new  ObjectMapper().writeValueAsString(getJsonPatch()));
    		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(getNote());
    		when(awsUploader.removeS3Object(anyString())).thenReturn(true);

    		when(apiUtil.getCriteriaFromQueryParser(any(), any())).thenReturn(new Query());
    		List<Note> list = new ArrayList<>();
    		list.add(getNote());
    		when(apiUtil.getNotesByDomain(any(), any())).thenReturn(list);
    		when(apiUtil.getNotesByDomain(any(), any())).thenReturn(new ArrayList<Note>());
    		when(jc.getOMconfiguration(any())).thenReturn(new ObjectMapper());
    		when(objectMapper.writeValueAsString(any())).thenReturn("{}");
    		GetNotes  gn = ValidateUtil.setPaginationMetadata(new ArrayList<Note>(), noteR);
    		noteR.setBody(getPostNote());
    		ResponseEntity<?> resp = service.processPostRequest(noteR, Optional.empty());
    		assertTrue(resp != null);

    		resp = service.processPostRequest(noteR, createMultipartFileOptional());
    		
    		assertNotNull(resp.getStatusCode());
        }
        catch(Exception ex) {
            assertThat(ex.getMessage().contains("NULL")).isTrue();
        }
     
	}
	
	@Test
	public void processPostNoteWithInternalAndExternalScopeAccessTest() throws JsonParseException, ApiException, IOException {
		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(getNote());
		when(objectMapper.writeValueAsString(any())).thenReturn(new ObjectMapper().writeValueAsString(getJsonPatch()));
		when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("external");
        try {
        	pn.setScope("internal");
        	pn.setPriority("HIGH");
        	pn.setStatus("active");
        	noteR.setBody(pn);
			service.processPostRequest(noteR, Optional.empty());	
		}catch(Exception e) {
			assertNotNull(e);
		}
        when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("internal");
        when(mongoTemplate.save(any(), anyString())).thenReturn(getNote());
        try {
        	pn.setScope("internal");
        	pn.setPriority("HIGH");
        	pn.setStatus("active");
        	noteR.setBody(pn);
			service.processPostRequest(noteR, Optional.empty());	
		}catch(Exception e) {
			assertNotNull(e);
		}
	}
	
	@Test
	public void deleteNoteTest() throws IOException {
		noteR.setId("id");
		noteR.setDomain("siteNotes");
		ResponseEntity<Object> id = service.processDeleteRequest(noteR, SiteNotes.class);
		assertTrue(id.getStatusCode().is2xxSuccessful());

		try {
			id = service.processDeleteRequest(null, SiteNotes.class);
			assertFalse(id.getStatusCode().is2xxSuccessful());
		}catch(Exception e) {
			assertFalse(null == e);
		}
		// verify error
		id = service.processDeleteRequest(noteR, SiteNotes.class);
		assertFalse(id.getStatusCode().is5xxServerError());
		
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(noteR.getId()));
		query.fields().include("deleted");
		
		Note note  = getNote();
		AttachmentData ad = new AttachmentData("text/txt","attachments/test1.txt", "test1.txt");
		List<AttachmentData> list = new ArrayList<>();
		note.setAttachments(list);

		when(awsUploader.removeS3Object(anyString())).thenReturn(true);
		noteR.setBody(note);
		id = service.processDeleteRequest(noteR, SiteNotes.class);
		assertNotNull(id.getBody());

		when(awsUploader.removeS3Object(anyString())).thenReturn(false);
		noteR.setBody(note);
		id = service.processDeleteRequest(noteR, SiteNotes.class);
		assertNotNull(id.getBody());

		/*
		 * when(awsUploader.removeS3Object(anyString())).thenThrow(ApiException.class);
		 * Assertions.assertThrows(ApiException.class, () -> { noteR.setBody(note);
		 * ResponseEntity<Object> i = service.processDeleteRequest(noteR,
		 * SiteNotes.class); assertNotNull(i.getBody()); });
		 */
		
		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(null);
		ResponseEntity<Object> i = service.processDeleteRequest(noteR, SiteNotes.class);
		assertNotNull(i.getBody());
		
		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(getNote());
		when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("external");
        try {
			service.processDeleteRequest(noteR, SiteNotes.class);	
		}catch(Exception e) {
			assertNotNull(e);
		}
        
        when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("both");
        try {
			service.processDeleteRequest(noteR, SiteNotes.class);	
		}catch(Exception e) {
			assertNotNull(e);
		}
	}
	
	@Test
	public void processPatchRequestTest() throws JsonParseException, ApiException, IOException {
		when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("internal");

		try {
			ResponseEntity<Object> id = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
			//assertTrue(id.getStatusCode().is2xxSuccessful());
		}catch(Exception e) {
			assertFalse(null == e);
		}

		when(objectMapper.writeValueAsString(any())).thenReturn(new ObjectMapper().writeValueAsString(getJsonPatch()));
		//doNothing().when(validateUtil).validateJsonString("{}");
		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(getNote());
		//doNothing().when(validateUtil).validatePostRequest(any(), any(), anyString());
		when(awsUploader.removeS3Object(anyString())).thenReturn(true);
		noteR.setBody(getJsonPatch());
		ResponseEntity<Object> id = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertTrue(id.getBody()!= null);
		
		//
		Note note  = getNote();
		AttachmentData ad = new AttachmentData("text/txt","attachments/test1.txt", "test1.txt");
		List<AttachmentData> list = new ArrayList<>();
		note.setAttachments(list);
		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(note);
		id = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(id.getBody());

		noteR = getNoteRequest(); noteR.setBody(null);
		id = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(id.getBody());

		when(awsUploader.removeS3Object("attachments/test1.txt")).thenReturn(true);
		noteR.setBody(getJsonPatch());
		ResponseEntity<Object> i = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(i.getBody());

		when(awsUploader.removeS3Object("attachments/test1.txt")).thenReturn(false);
		noteR.setBody(getJsonPatch());
		i = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(i.getBody());

		when(awsUploader.removeS3Object("attachments/test1.txt")).thenThrow(ApiException.class);
		noteR.setBody(getJsonPatch());
		i = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(i.getBody());

		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(null);
		id = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(id.getBody());

		noteR.setBody(getJsonPatch());
		when(apiUtil.removeLinks(any(), any())).thenReturn(new ArrayList<AttachmentData>());
		id = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(id.getBody());
		
		when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("external");
        try {
			service.processPatchRequest(noteR, SiteNotes.class, Optional.empty());	
		}catch(Exception e) {
			assertNotNull(e);
		}
        
		when(mongoTemplate.findOne(any(), any(), anyString())).thenThrow(RuntimeException.class);
		Assertions.assertThrows(ApiException.class, () -> {
			service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		});
	
	
	}
	
	@Test
	public void processPatchRequestTestForNotesAdminTest() throws JsonParseException, ApiException, IOException {
		when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("internal");

		try {
			ResponseEntity<Object> id = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
			//assertTrue(id.getStatusCode().is2xxSuccessful());
		}catch(Exception e) {
			assertFalse(null == e);
		}

		when(objectMapper.writeValueAsString(any())).thenReturn(new ObjectMapper().writeValueAsString(getJsonPatch()));
		//doNothing().when(validateUtil).validateJsonString("{}");
		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(getNote());
		//doNothing().when(validateUtil).validatePostRequest(any(), any(), anyString());
		when(awsUploader.removeS3Object(anyString())).thenReturn(true);
		noteR.setBody(getJsonPatch());
		ResponseEntity<Object> id = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertTrue(id.getBody()!= null);
		
		//
		Note note  = getNote();
		AttachmentData ad = new AttachmentData("text/txt","attachments/test1.txt", "test1.txt");
		List<AttachmentData> list = new ArrayList<>();
		note.setAttachments(list);
		when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(note);
		id = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(id.getBody());

		noteR = getNoteRequest(); noteR.setBody(null);
		id = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(id.getBody());

		when(awsUploader.removeS3Object("attachments/test1.txt")).thenReturn(true);
		noteR.setBody(getJsonPatch());
		ResponseEntity<Object> i = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(i.getBody());

		when(awsUploader.removeS3Object("attachments/test1.txt")).thenReturn(false);
		noteR.setBody(getJsonPatch());
		i = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		assertNotNull(i.getBody());
        
        List<String> capabilitiesList = new ArrayList<>();
        capabilitiesList.add(Constants.NOTES_AND_ATTACHMENTS);
        capabilitiesList.add(Constants.INTERNAL_ACCESS);
        capabilitiesList.add(Constants.NOTES_ADMIN);
        List<String> roleList = new ArrayList<>();
        roleList.add(Constants.ROLE_SUPER_ADMIN);
        when(requestInterceptor.getUserCapabilities()).thenReturn(capabilitiesList);
        when(requestInterceptor.getUserRoles()).thenReturn(roleList);
        noteR.setCreatedBy("212746564");
        noteR.setBody(getJsonPatch());
        when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("external");
        try {
			service.processPatchRequest(noteR, SiteNotes.class, Optional.empty());	
		}catch(Exception e) {
			assertNotNull(e);
		}        

        List<String> capabilitiesList1 = new ArrayList<>();
        capabilitiesList1.add(Constants.NOTES_AND_ATTACHMENTS);
        capabilitiesList1.add(Constants.INTERNAL_ACCESS);
        when(requestInterceptor.getUserCapabilities()).thenReturn(capabilitiesList1);
        noteR.setCreatedBy("212746564");
        noteR.setBody(getJsonPatch());
        when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("both");
        try {
			service.processPatchRequest(noteR, SiteNotes.class, Optional.empty());	
		}catch(Exception e) {
			assertNotNull(e);
		}
        
		when(mongoTemplate.findOne(any(), any(), anyString())).thenThrow(RuntimeException.class);
		Assertions.assertThrows(ApiException.class, () -> {
			service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
		});
	
	}

	@Test
	public void processGetRequestTest() throws JsonParseException, ApiException, IOException {
		
		when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("external");
		
		Assertions.assertThrows(NullPointerException.class, () -> {
			GetNotes gn = new GetNotes();
			Note note = getNote();
			List<Note> notes = new ArrayList <>();
			notes.add(note);
			gn.setNotes(notes);
			Pagination pagination = new Pagination(1,1,1,1);
			gn.setPagination(pagination);
			when(com.ge.ren.notes.utils.ValidateUtil.setPaginationMetadata(notes, noteR)).thenReturn(gn);
		});
		noteR.setDomainIds("500023,100001");
		noteR.setCreatedBy("createdBy");
		noteR.setBody("500023");
		noteR.setUpdateDate("2025-08-02T11:11:11.555Z");
		noteR.setCategory("category");
		noteR.setDomain("siteNotes");
		noteR.setId("id");
		noteR.setCount(10);
		noteR.setFilter("id,note,domainId,title");
		
		String resp = null;
		try {
			resp = service.processGetRequest(noteR);
			assertFalse(resp.isEmpty());
			resp = service.processGetRequest(noteR);
		}catch(Exception e) {
			assertFalse(null == e);
		}
		
		noteR.setQuery("category==category;priority==HIGH");
		try {
			resp = service.processGetRequest(noteR);
		}catch(Exception e) {
			assertFalse(null == e);
		}

		try {
			resp = service.processGetRequest(noteR);
		}catch(Exception e) {
			assertFalse(null == e);
		}
		try {

			noteR.setDomainIds("500023");
			Assertions.assertThrows(InvalidMongoDbApiUsageException.class, () -> {
				service.processGetRequest(noteR);
			});
		}catch(NullPointerException e) {
			thrown.expect(NullPointerException.class);
		}

		try {
			noteR.setDomainIds(null);
			resp = service.processGetRequest(noteR);
		}catch(Exception e) {
			assertFalse(null == e);
		}
		try {
			noteR.setCreatedBy(null);
			resp = service.processGetRequest(noteR);
		}catch(Exception e) {
			assertFalse(null == e);
		}

		noteR.setBody(null);
		try {
			resp = service.processGetRequest(noteR);
		}catch(Exception e) {
			assertFalse(null == e);
		}
		noteR.setUpdateDate(null);
		try {
			resp = service.processGetRequest(noteR);
		}catch(Exception e) {
			assertFalse(null == e);
		}
		noteR.setCategory(null);
		try {
			resp = service.processGetRequest(noteR);
			assertFalse(resp.isEmpty());
			noteR.setQuery(null);

			resp = service.processGetRequest(noteR);
		}catch(Exception e) {
			assertFalse(null == e);
		}
		Query query = new Query();
		query.fields().exclude("timestampc").exclude("timestampu");
		try {
			noteR = new NotesRequest();
			noteR.setTenantId("tenantId");
			resp = service.processGetRequest(noteR);
		}catch(Exception e) {
			assertFalse(null == e);
		}
		
		// new 
		List<Note> list = new ArrayList<>();
		list.add(getNote());
		
		when(apiUtil.getCriteriaFromQueryParser(any(), any())).thenReturn(new Query());
		when(apiUtil.getNotesByDomain(any(), any())).thenReturn(list);
		when(jc.getOMconfiguration(any())).thenReturn(new ObjectMapper());
		when(objectMapper.writeValueAsString(any())).thenReturn("{}");


		when(apiUtil.getNotesByDomain(any(), any())).thenReturn(list);
		try (MockedStatic<ValidateUtil> theMock = Mockito.mockStatic(ValidateUtil.class)) {
            theMock.when(() -> ValidateUtil.setPaginationMetadata(list, noteR))
                   .thenReturn(new GetNotes());

            assertNotNull(ValidateUtil.setPaginationMetadata(list, noteR));
    		noteR.setDomainIds("500023,500021");
    		noteR.setFilter("id,domainId,title,note");
        	Assertions.assertThrows(NullPointerException.class, () -> {
        		service.processGetRequest(noteR);
        	});

        }catch(IllegalArgumentException e) {
			assertFalse(null == e);
		}
		noteR.setDomainIds("500023,100001");
		noteR.setFilter("id,note,domainId,title");
		noteR.setDomain("siteNotes");
		noteR.setId("id");
		
		//when(service.processUpdateLinks(anyString(), any(), anyString())).thenReturn(new ArrayList<Note>());
		service.processGetRequest(noteR);
		
    	Assertions.assertThrows(NullPointerException.class, () -> {
    		service.processGetRequest(null);
    	});

		//when(validateUtil.setPaginationMetadata(any(),any())).thenReturn(new GetNotes());
		//GetNotes  gn = ValidateUtil.setPaginationMetadata(new ArrayList<Note>(), noteR);
		//assertTrue(gn != null);
		
    	when(apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor)).thenReturn("internal");
	}

	@Test
	public void testProcessUpdateLinks(){
		List<Note> notes = new ArrayList<>();
		notes.add(getNote());
		List<Note> list = service.processUpdateLinks("id", notes, "siteNotes");
		assertFalse(list.isEmpty());
	}
	
	@Test
	public void postNoteTest() {
		noteR = new NotesRequest();
		noteR.setBody(new PostNote());
		pn = ((PostNote) noteR.getBody());

		PostNote pn = new PostNote();
		pn.setCategory("category");
		pn.setDomainId("domainId");
		pn.setNote("note");
		pn.setPriority("priority");
		pn.setScope("scope");
		pn.setStatus("status");
		pn.setTitle("title");
		pn.setValidDateBy("validDateBy");
		pn.getCategory();
		pn.getDomainId();
		pn.getNote();
		pn.getPriority();
		pn.getScope();
		pn.getStatus();
		pn.getTitle();
		pn.getValidDateBy();
		PostNote pn1 = pn;
		assertTrue(pn.equals(pn1));
		pn = new PostNote("1","1","1","1","1","1","1","1", new ArrayList<AttachmentData>());
		assertFalse(pn.equals(pn1));
		
		pn = getPostNote();
		
		assertTrue(pn.toString().length() != 0);
		pn.setTitle(ValidateUtil.validateForSpecChars(pn.getTitle(), "title"));
		pn.setNote(ValidateUtil.validateForSpecChars(pn.getNote(), "note"));
		when(dateFormat.getCurrentDateFormated()).thenReturn("10/10/25 10:10:10");
		DateFormatMS df = new DateFormatMS();
		Note note = new Note();
			  note.setDomainId(pn.getDomainId()); note.setTenantId("tenantId"); note.setTitle(pn.getTitle()); note.setNote(pn.getNote()); note.setCreationDate("10/10/25 10:10:10"); note.setUpdateDate("10/10/25 10:10:10");
			  note.setValidDateBy(pn.getValidDateBy()); note.setPriority(Priority.LOW.toString()); note.setCreatedBy("503206931"); note.setUpdatedBy("503206931"); note.setCategory(pn.getCategory());  note.setStatus(((null != pn.getStatus()) ? pn.getStatus(): Status.active.toString())); note.setScope(Scope.internal.toString());  note.setDeleted(Boolean.FALSE);  
			  note.setTimestampc(new Timestamp(System.currentTimeMillis()));  note.setTimestampu(new Timestamp(System.currentTimeMillis()));
	}
		
		
    @org.junit.jupiter.api.Test 
	public void validateFieldsTest() throws Exception {
    	SiteNotes note =  new SiteNotes();
    	NotesRequest noteR = new NotesRequest();
		noteR.setDomainIds("500023,100001");
		noteR.setCreatedBy("createdBy");
		noteR.setUpdateDate("08/22/25 22:22:22");
		noteR.setCategory("category");
		noteR.setDomain("siteNotes");
		noteR.setId("1");
    	PatchNote pn = new PatchNote(
    			"title",
    			"note",
    		    "HIGH",
    		    "category",
    		    "internal",
    		    "active",
    		    null,
    		    "updatedBy",
    		    new ArrayList<AttachmentData>());
    	Update update = new Update();
    	
    	noteR.setDomainIds("500203");
    	//getJsonPatch()
    	noteR.setBody(getJsonPatch());
    	ResponseEntity<Object> resp = service.processPatchRequest(noteR, SiteNotes.class,  getOptionalFiles());
    	assertTrue( resp.getStatusCode().is2xxSuccessful());
    	//when(MongoTemplate.findAndModify(any(), any(), any())).thenReturn(note);
    	resp = service.processPatchRequest(noteR, SiteNotes.class,  getOptionalFiles());
    	
    	noteR.setBody(getJsonPatch());
    	resp = service.processPatchRequest(noteR, SiteNotes.class, Optional.empty());
    	assertTrue(resp.getStatusCode().is2xxSuccessful());
    	update = service.validateFields(getNote());
    	//when(validateUtil.validateFields(noteR)).thenReturn(update);
    	assertTrue(update.getUpdateObject().size() > 0);
    	
    	noteR.setBody(getJsonPatch());
    	update = service.validateFields(getNote());
    	assertTrue(!update.getUpdateObject().isEmpty());

    	//update.set("note", "note"); 
		//when(validateUtil.validateFields(noteR)).thenReturn(update);
    	noteR.setBody(getJsonPatch());
    	resp = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
    	assertTrue(resp.getStatusCode().is2xxSuccessful());
    	update = service.validateFields(getNote());
    	assertTrue(!update.getUpdateObject().isEmpty()); 

    	noteR.setBody(getJsonPatch());
		System.out.println("update.getUpdateObject() -> "+ update.getUpdateObject().toString());
    	resp = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
    	assertTrue(resp.getStatusCode().is2xxSuccessful());
    	update = service.validateFields(getNote());
    	assertTrue(!update.getUpdateObject().isEmpty()); //.toJson().contains("priority"));

    	
    	noteR.setBody(getJsonPatch());
    	update.set("category", "category");
    	resp = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
    	assertTrue(resp.getStatusCode().is2xxSuccessful());
    	update = service.validateFields(getNote());
    	assertTrue(!update.getUpdateObject().isEmpty());
    	
    	JsonPatch jp = getJsonPatch();
    	List<Patch> lp = new ArrayList<>();
    	lp.add(new Patch("add", "/scope", "internal"));
    	jp.setPatch(lp);
    	noteR.setBody(jp);
    	resp = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
    	assertTrue(resp.getStatusCode().is2xxSuccessful());
    	update = service.validateFields(getNote());
    	assertTrue(!update.getUpdateObject().isEmpty());

    	JsonPatch jps = getJsonPatch();
    	List<Patch> lps = new ArrayList<>();
    	lp.add(new Patch("replace", "/scope", "Wrong"));
    	jp.setPatch(lp);
    	NotesRequest noter = new NotesRequest();
		noter.setDomainIds("500023");
		noter.setCreatedBy("createdBy");
		noter.setUpdateDate("08/22/25 22:22:22");
		noter.setDomain("siteNotes");
		noter.setId("1");
    	noter.setBody(jps);
		service.processPatchRequest(noter, SiteNotes.class,  Optional.empty());
    	
    	assertTrue(resp.getStatusCode().is2xxSuccessful());
    	update = service.validateFields(getNote());
    	assertTrue(!update.getUpdateObject().isEmpty());

    	noteR.setBody(getJsonPatch());
    	resp = service.processPatchRequest(noteR, SiteNotes.class,  Optional.empty());
    	assertTrue(resp.getStatusCode().is2xxSuccessful());
    	update = service.validateFields(getNote());
    	assertTrue(!update.getUpdateObject().isEmpty());

    	assertTrue(!update.getUpdateObject().isEmpty());
    	
    	//PostNote
    	PostNote pon = new PostNote();
    	pon.setAttachments(null);
    	assertTrue(null == pon.attachments);
    	List ats = Arrays.asList(new Attachments());
    	pon.setAttachments(ats);
    	assertTrue(null != pon.attachments);
    	//Note Request
    	MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
    	noteR = new NotesRequest("domain", "domainIds", "tenantId", "body", "id", "createdBy",  file);
    	
    	assertTrue(noteR.getFile().getBytes().length > 0 );
    	assertNotNull(noteR);
    	
    	Note not = new Note();
    	
    	update = service.validateFields(not);
    	
    	assertTrue(update.getUpdateObject() != null);
    	
    }
    
    @Test
    public void noteServiceRepositoryTest() {
    	SiteNotes sn = getSiteNote();
    	List<SiteNotes> notes = new ArrayList<>();
    	notes.add(sn);
        Page<SiteNotes> pagedResponse = new PageImpl(notes );
        notes.clear();
        Page<SiteNotes> response = new PageImpl(notes);
        when(repository.count()).thenReturn((long) 1);
        
        when(repository.findAllById(any())).thenReturn(pagedResponse);
        when(repository.findByIdIn( any(), any())).thenReturn(pagedResponse);
        when(repository.findByIdNot(any(), any())).thenReturn(pagedResponse);
        when(repository.findByIdNotIn(any(), any())).thenReturn(pagedResponse);
        when(repository.findByTenantIdAndId(anyString(),anyString(), any())).thenReturn(pagedResponse);
        when(repository.findByTenantIdAndIdNot(anyString(),anyString(), any())).thenReturn(pagedResponse);
        when(repository.findByTenantIdAndIdIn(anyString(),any(), any())).thenReturn(pagedResponse);
        when(repository.findByTenantIdAndIdNotIn(anyString(),any(), any())).thenReturn(pagedResponse);        
        when(repository.findByTenantId(anyString(), any())).thenReturn(pagedResponse);
        when(repository.findByTenantIdIn(any(), any())).thenReturn(pagedResponse);
        when(repository.findByTenantIdNot(anyString(), any())).thenReturn(pagedResponse);
        when(repository.findByTenantIdNotIn(any(), any())).thenReturn(pagedResponse);
        when(repository.findByTenantIdAndDomainIdIn(anyString(), any(), any())).thenReturn(pagedResponse);        
    	when(repository.findAll()).thenReturn(notes);
    	when(repository.save(any(SiteNotes.class))).thenReturn(sn);
    	when(repository.findAll()).thenReturn(notes);
        
        Page<SiteNotes> page = service.searchByParams("id", "tenantId",  "domainId");
        assertFalse(page.isEmpty());
    	page = service.searchByParams("id", "tenantId",  "domainId");
    	assertNotNull(sn);
        
        when(repository.findAllById(any())).thenReturn(response);
        when(repository.findByIdIn( any(), any())).thenReturn(response);
        when(repository.findByIdNot(any(), any())).thenReturn(response);
        when(repository.findByIdNotIn(any(), any())).thenReturn(response);      
        when(repository.findByTenantIdAndId(anyString(),anyString(), any())).thenReturn(response);        
        when(repository.findByTenantIdAndIdNot(anyString(),anyString(), any())).thenReturn(response);       
        when(repository.findByTenantIdAndIdIn(anyString(),any(), any())).thenReturn(response);      
        when(repository.findByTenantIdAndIdNotIn(anyString(),any(), any())).thenReturn(response);      
        when(repository.findByTenantId(anyString(), any())).thenReturn(response);
        when(repository.findByTenantIdNot(anyString(), any())).thenReturn(response);
        when(repository.findByTenantIdIn(any(), any())).thenReturn(response);
        when(repository.findByTenantIdNotIn(any(), any())).thenReturn(response);
        when(repository.findByTenantIdAndDomainIdIn(anyString(), any(), any())).thenReturn(response);
        
        
        page = service.searchByParams("id", "tenantId",  "domainId");
        assertTrue(page.isEmpty());
    	
    	
    }
    
    @Test
    void ProcessAssetBulkUpsertSuccess() throws Exception {
        
        NotesRequest request = new NotesRequest();
        request.setDomain("assetNotes");
        request.setTenantId("tenant123");

        UpsertNote upsertNote = new UpsertNote();
        upsertNote.setOnPremId("note-id-123");
        upsertNote.setNote("Test note.");
        upsertNote.setTitle("Test Title");
        upsertNote.setPriority("High");
        upsertNote.setCategory("Test Category");
        upsertNote.setStatus("New");
        upsertNote.setScope("General");
        upsertNote.setCreationDate(Instant.now().toString());
        upsertNote.setCreationDate(Instant.now().toString());
        upsertNote.setTimestampc(Timestamp.from(Instant.now()));

        request.setBody(upsertNote);

        List<NotesRequest> requestList = List.of(request);
        when(mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, Note.class, "assetNotes"))
        .thenReturn(bulkOperations);

	    when(jc.getOMconfiguration(any())).thenReturn(new ObjectMapper());
	
	    try (MockedStatic<ValidateUtil> mockedStatic = mockStatic(ValidateUtil.class)) {
	        
	        ResponseEntity<?> response = service.processBulkUpsertRequest(requestList);
	
            assertNotNull(response);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            List<?> body = (List<?>) response.getBody();
            assertNotNull(body);
	       
	    }
        
    }

    @Test
    void ProcessAssetBulkUpsertFailed() throws Exception {
        
        NotesRequest request = new NotesRequest();
        request.setDomain("assetNotes");
        request.setTenantId("tenant123");

        UpsertNote upsertNote = new UpsertNote();  
        request.setBody(upsertNote);

        List<NotesRequest> requestList = List.of(request);

        Mockito.when(mongoTemplate.bulkOps(
                BulkOperations.BulkMode.UNORDERED, 
                Note.class, 
                "assetNotes"))
            .thenReturn(bulkOperations);
        
        ResponseEntity<?> response = service.processBulkUpsertRequest(requestList);
        
        Mockito.verify(bulkOperations, Mockito.never()).execute(); 

        List<FailedNote> failedNotes = (List<FailedNote>)response.getBody();
        assertNotNull(failedNotes);
        assertEquals(1, failedNotes.size());
        assertEquals("400", failedNotes.get(0).getStatus());
    }
    
    @Test
    void ProcessSiteBulkUpsertSuccess() throws Exception {
        
        NotesRequest request = new NotesRequest();
        request.setDomain("siteNotes");
        request.setTenantId("tenant123");

        UpsertNote upsertNote = new UpsertNote();
        upsertNote.setOnPremId("note-id-123");
        upsertNote.setNote("Test note.");
        upsertNote.setTitle("Test Title");
        upsertNote.setPriority("High");
        upsertNote.setCategory("Test Category");
        upsertNote.setStatus("New");
        upsertNote.setScope("General");
        upsertNote.setCreationDate(Instant.now().toString());
        upsertNote.setCreationDate(Instant.now().toString());
        upsertNote.setTimestampc(Timestamp.from(Instant.now()));

        request.setBody(upsertNote);

        List<NotesRequest> requestList = List.of(request);
        when(mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, Note.class, "siteNotes"))
        .thenReturn(bulkOperations);

	    when(jc.getOMconfiguration(any())).thenReturn(new ObjectMapper());
	
	    try (MockedStatic<ValidateUtil> mockedStatic = mockStatic(ValidateUtil.class)) {
	        
	        ResponseEntity<?> response = service.processBulkUpsertRequest(requestList);
	
            assertNotNull(response);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            List<?> body = (List<?>) response.getBody();
            assertNotNull(body);
	       
	    }
        
    }

    @Test
    void ProcessSiteBulkUpsertFailed() throws Exception {
        
        NotesRequest request = new NotesRequest();
        request.setDomain("siteNotes");
        request.setTenantId("tenant123");

        UpsertNote upsertNote = new UpsertNote();  
        request.setBody(upsertNote);

        List<NotesRequest> requestList = List.of(request);

        Mockito.when(mongoTemplate.bulkOps(
                BulkOperations.BulkMode.UNORDERED, 
                Note.class, 
                "siteNotes"))
            .thenReturn(bulkOperations);
        
        ResponseEntity<?> response = service.processBulkUpsertRequest(requestList);
        
        Mockito.verify(bulkOperations, Mockito.never()).execute(); 

        List<FailedNote> failedNotes = (List<FailedNote>)response.getBody();
        assertNotNull(failedNotes);
        assertEquals(1, failedNotes.size());
        assertEquals("400", failedNotes.get(0).getStatus());
    }
    
    public void processUpdateLinks() {
    	List<Note> list = new ArrayList<>();
    	list.add(getNote());
    	service.processUpdateLinks("id", list, "siteNotes");
    }
    
    // HELPERS
    
    private Note getNote() {
    	Note attachment = new Note();
		attachment.setCategory("category");
		attachment.setCreatedBy("DMITRY");
		attachment.setCreationDate("08/22/21 21:21:21");
		attachment.setDeleted(false);
		attachment.setDomainId("500011");
		attachment.setId("id");
		attachment.setNote("note");
		attachment.setPriority("HIGH");
		attachment.setScope(Scope.internal.toString());
		attachment.setStatus("active");
		attachment.setTenantId("tenantId");
		attachment.setTitle("title");
		attachment.setUpdateDate("08/22/22 23:23:23");
		attachment.setUpdatedBy("updatedBy");
		attachment.setValidDateBy("08/30/50 01:01:01");
		List<AttachmentData> attachments = new ArrayList<>();
		AttachmentData ad = new AttachmentData("https://renewables-uai3031357-attachments-dev.s3.amazonaws.com/attachments/test1.txt", "text/txt", "test1.txt");
		attachments.add(ad);
		attachment.setAttachments(attachments);
    	return attachment;
    }	
    
    private SiteNotes getSiteNote() {
    	SiteNotes attachment = new SiteNotes();
		attachment.setCategory("category");
		attachment.setCreatedBy("DMITRY");
		attachment.setCreationDate("08/22/21 21:21:21");
		attachment.setDeleted(false);
		attachment.setDomainId("500011");
		attachment.setId("id");
		attachment.setNote("note");
		attachment.setPriority("HIGH");
		attachment.setScope(Scope.internal.toString());
		attachment.setStatus("active");
		attachment.setTenantId("tenantId");
		attachment.setTitle("title");
		attachment.setUpdateDate("08/22/22 23:23:23");
		attachment.setUpdatedBy("updatedBy");
		attachment.setValidDateBy("08/30/50 01:01:01");
		List<AttachmentData> attachments = new ArrayList<>();
		AttachmentData ad = new AttachmentData("https://renewables-uai3031357-attachments-dev.s3.amazonaws.com/attachments/test1.txt", "text/txt", "test1.txt");
		attachments.add(ad);
		attachment.setAttachments(attachments);
    	return attachment;
    }	
    public static String asJsonString(final
            Note notes) {
    	try {
    		return new ObjectMapper().writeValueAsString(notes);
    	} catch (Exception e) {
    		throw new RuntimeException(e);
    	}
    }
    
	private MultipartFile[] getMultipartFiles() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] files = {file};
	    return files;
	}
	private Optional<MultipartFile[]> getOptionalFiles() {
	    MockMultipartFile file = new MockMultipartFile("file",  "hello.txt", MediaType.TEXT_PLAIN_VALUE, "Hello, World!".getBytes());
	    MockMultipartFile[] fileso = {file};
	    Optional<MultipartFile[]> files = Optional.of(fileso);
	    return files;
	}
	private JsonPatch getJsonPatch() {
    	JsonPatch jp = new JsonPatch();
    	//Attachment atts = new Attachment("add", (AWS_PATH1+System.getenv("spring.profiles.active")+AWS_PATH2)+"attachments", "test1.txt");
    	Patch patch = new Patch("add", "note", "new note value");
    	List<Patch> plist = new ArrayList<>();
    	plist.add(patch);
    	patch = new Patch("add", "validDateBy", "08/22/50 22:22:22");
    	plist.add(patch);
    	List<Attachment> alist = new ArrayList<>();
    	//alist.add(atts);
    	jp.setAttachments(alist);
    	jp.setPatch(plist);
    	return jp;
	}
	
	private PostNote getPostNote() {
		List<AttachmentData> attachments = new ArrayList<>();
		AttachmentData ad = new AttachmentData("https://renewables-uai3031357-attachments-dev.s3.amazonaws.com/attachments/test1.txt", "text/txt", "test1.txt");
		attachments.add(ad);
		pn = new PostNote(   
				"domainId",
			    "note",
			    "title",
			    "priority",
			    "category",
			    "scope",
			    "status",
			    "08/22/25 22:22:22",
			    attachments);
		return pn;
	}
	
	private NotesRequest getNoteRequest() {
        NotesRequest noteR = new NotesRequest();
        noteR.setDomain("siteNotes");
        noteR.setDomainIds("domainIds");
        noteR.setFilter("id,title,note,domainId,category,updatedBy");
        noteR.setPageIdx(0);
        noteR.setPageSize(5);
        noteR.setTenantId("tenantId");
        noteR.setBody(notes);
        noteR.setQuery("priority==MEDIUM;category==category");
        return noteR;
	}
	
	private Optional<MultipartFile[]> createMultipartFileOptional() throws IOException {
		File file = new File("src/main/resources/attachments/test-image.png");
		FileInputStream input = new FileInputStream(file);
		MultipartFile multipartFile = new MockMultipartFile("file",
		            file.getName(), "text/plain", IOUtils.toByteArray(input));
		MultipartFile[] mf = {multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, 
				multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile,
				multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile, multipartFile};
		Optional<MultipartFile[]> mfo = Optional.of(mf);
		return mfo;
	}
}
