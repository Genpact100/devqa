package com.ge.ren.attachments.controller;

import java.io.IOException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@SpringBootTest (classes = AttachementApiController.class, properties = {"bucket=attachments","descriptionSize=20", "titleSize=10", "storageType=fyleSystem", "searchLimit=1", "pageSizeDef=1", "EMPTY_JSON_RESPONSE={}"}) 
@TestPropertySource(locations = "/application.properties") 
@RunWith(SpringRunner.class)
@WebAppConfiguration
@AutoConfigureMockMvc

@EnableWebMvc
public class AbstractTest {
	@Autowired
	protected MockMvc mockMvc;

   @Autowired
   AttachementApiController controller;

   @Value("${searchLimit}")
   int searchLimit = 1;
   @Value("${pageSizeDef}")
   int pageSizeDef = 1;
   
   @Value("${pageNum}")
   int pageNum = 1;
   
   @Value("${EMPTY_JSON_RESPONSE}")
   String EMPTY_JSON_RESPONSE = "{}";

   protected void setUp() {
      mockMvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(new com.ge.ren.notes.exception.ResponseExceptionHandler()).build();
      System.out.println(">> MockMvc setup is done for Controller test!");
   }
   protected String mapToJson(Object obj) throws JsonProcessingException {
      ObjectMapper objectMapper = new ObjectMapper();
      return objectMapper.writeValueAsString(obj);
   }
   protected <T> T mapFromJson(String json, Class<T> clazz)
      throws JsonParseException, JsonMappingException, IOException {
      
      ObjectMapper objectMapper = new ObjectMapper();
      return objectMapper.readValue(json, clazz);
   }
}