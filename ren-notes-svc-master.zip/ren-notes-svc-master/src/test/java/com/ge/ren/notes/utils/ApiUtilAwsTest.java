package com.ge.ren.notes.utils;

import static com.ge.ren.notes.constants.Constants.DELETED;
import static com.ge.ren.notes.constants.Constants.PAGE_SEARCH_SORT_KEY;
import static com.ge.ren.notes.constants.Constants.TENANTID;
import static com.ge.ren.notes.constants.Constants.AWS_PATH1;
import static com.ge.ren.notes.constants.Constants.AWS_PATH2;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.NativeWebRequest;

import com.fasterxml.jackson.core.JsonParseException;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.model.patch.Patch;
import com.ge.ren.attachments.service.impl.AttachmentServiceImpl;
import com.ge.ren.attachments.utils.AwsUploader;
import com.ge.ren.common.keycloak.exception.TokenVerifyException;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.controller.NotesApiController;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.NotFoundException;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.service.NotesService;
import com.ge.ren.notes.utils.ApiUtil;
import com.ge.ren.notes.utils.JacksonConfiguration;
import com.ge.ren.notes.utils.ValidateUtil;
@RunWith(SpringRunner.class)
@SpringBootTest(classes= {ApiUtil.class}, properties = {"bucket=attachments","descriptionSize=20", "titleSize=10", "storageType=s3aws", "searchLimit=1"}) 
//, properties = {"bucket=attachments","descriptionSize=20", "titleSize=10", "storageType=fyleSystem", "searchLimit=1"}) //,MongoConfig.class 
//@TestPropertySource(locations = "/application.properties") 

@AutoConfigureMockMvc
public class ApiUtilAwsTest {

 	@MockBean
 	MongoTemplate mongoTemplate;
 
    @MockBean
    RequestInterceptor requestInterceptor;
 	
	@MockBean
	AwsUploader awsUploader;
	
	@Autowired
	ApiUtil apiUtil;
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
    Note note;
    
    @BeforeEach
    public void setup() throws TokenVerifyException {
    	MockitoAnnotations.initMocks(this);
        when(requestInterceptor.getTenantId()).thenReturn("tenantid");
        when(requestInterceptor.getUsername()).thenReturn("name");
        List<Object> notes = new ArrayList<>();
        when(mongoTemplate.find(any(), any())).thenReturn(notes);
    }
    
    
    @Test
	public void removeLinksTest() {
		when(awsUploader.removeS3Object(any())).thenReturn(true);
		List<com.ge.ren.attachments.model.patch.Attachment> attachmentList = getJsonPatch().getAttachments();
		List<AttachmentData> attachments = new ArrayList<>();
		AttachmentData ad = new AttachmentData("attachments/test1.txt", "text/txt", "test1.txt");
		attachments.add(ad);
		attachments = apiUtil.removeLinks(attachmentList, attachments);
		assertTrue(attachments != null);
		
		when(awsUploader.removeS3Object(any())).thenThrow(ApiException.class);
		Assertions.assertThrows(ApiException.class, () -> {
			List<AttachmentData> atachments = new ArrayList<>();
			AttachmentData a = new AttachmentData("attachments/test1.txt", "text/txt", "test1.txt");
			atachments.add(a);
			apiUtil.removeLinks(attachmentList, atachments);
			assertTrue(atachments != null);
		});
	}
	
	//helpers
	private JsonPatch getJsonPatch() {
    	JsonPatch jp = new JsonPatch();
    	com.ge.ren.attachments.model.patch.Attachment atts = new com.ge.ren.attachments.model.patch.Attachment("add", (AWS_PATH1+"dev"+AWS_PATH2)+"attachments", "test1.txt");
    	Patch patch = new Patch("add", "note", "new note value");
    	List<Patch> plist = new ArrayList<>();
    	plist.add(patch);
    	patch = new Patch("add", "validDateBy", "08/22/25 22:22:22");
    	plist.add(patch);
    	List<com.ge.ren.attachments.model.patch.Attachment> alist = new ArrayList<>();
    	alist.add(atts);
    	jp.setAttachments(alist);
    	jp.setPatch(plist);
    	return jp;
	}
}
