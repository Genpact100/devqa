package com.ge.ren.notes.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.patch.Patch;
import com.ge.ren.attachments.utils.AwsUploader;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.constants.Constants;
import com.ge.ren.notes.constants.ErrorConstants.ErrorCodes;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.exception.NotFoundException;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.AssetNotes;
import com.ge.ren.notes.model.CaseNotes;
import com.ge.ren.notes.model.EventNotes;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.SiteNotes;
import com.ge.ren.notes.model.TaskNotes;
import com.github.rutledgepaulv.qbuilders.builders.GeneralQueryBuilder;
import com.github.rutledgepaulv.qbuilders.conditions.Condition;
import com.github.rutledgepaulv.qbuilders.visitors.MongoVisitor;
import com.github.rutledgepaulv.rqe.pipes.DefaultArgumentConversionPipe;
import com.github.rutledgepaulv.rqe.pipes.QueryConversionPipeline;
import com.mongodb.BasicDBList;
import static com.ge.ren.notes.constants.Constants.*;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Component
public class ApiUtil {
 	
	@Value("${mongodb.search.limit:10}")
	private int searchLimit;
	
    @Value("${storage.type:s3aws}")
	private String storageType;
    
    @Value("${aws.bucket.prefix:TODO_add_to_properties}")
	private String bucket;
    
    @Value("${spring.profiles.active}")
    String activeProfile;
    
    @Autowired
    AwsUploader awsUploader;
    
	@Autowired
 	MongoTemplate mongoTemplate;
 	
	public List<Note> getNotesByDomain(NotesRequest request, Query query) throws IOException {
		List<Note> notes = new ArrayList<>();
        switch(request.getDomain()) {
		case "siteNotes":
	        //Optional<List<SiteNotes>> noteList = Optional.of(mongoTemplate.find(note, SiteNotes.class));
			notes.addAll(Optional.of(mongoTemplate.find(query, SiteNotes.class)).get());
			break;
		case "assetNotes":
			notes.addAll(Optional.of(mongoTemplate.find(query, AssetNotes.class)).get());
			break;
		case "eventNotes":
			notes.addAll(Optional.of(mongoTemplate.find(query, EventNotes.class)).get());
			break;
		case "caseNotes":
			notes.addAll(Optional.of(mongoTemplate.find(query, CaseNotes.class)).get());
			break;
		case "taskNotes":
	        notes.addAll(Optional.of(mongoTemplate.find(query, TaskNotes.class)).get());
			break;
		default: 
			throw new ResourceNotValid("Domain Name is not valid: " + request.getDomain());
        }	
		return notes;
	}
	
	public String retrieveUserName(RequestInterceptor requestInterceptor) {
		if (!StringUtils.hasLength(requestInterceptor.getUsername())) {
			throw new ResourceNotValid("User Name can't be null or empty");
		}return requestInterceptor.getUsername();
		
	}


	public String retrieveTenantId(RequestInterceptor requestInterceptor) {
        if (!StringUtils.hasLength(requestInterceptor.getTenantId())) {
            throw new NotFoundException("Tenant Id: " + requestInterceptor.getTenantId());
        }return requestInterceptor.getTenantId(); //tenantId = "geservdrZp";
		
    }
 
	/*
	 *  Method getCriteriaFromQueryParser
	 *  @param query String
	 *  @param query Query
	 *  @return Query
	 */
	public Query getCriteriaFromQueryParser(String squery, Query query) {
          
           
       squery =convertToISODateString(squery);
           
		QueryConversionPipeline pipeline = QueryConversionPipeline.builder()
				.useNonDefaultArgumentConversionPipe(DefaultArgumentConversionPipe.builder()
						.useNonDefaultFieldResolver(new NotesFieldResolver())
						.useNonDefaultStringToTypeConverter(new QueryConvertionUtil()).build())
				.build();
		try {
			log.info("Query parameter received - {}",squery);
			Condition<GeneralQueryBuilder> condition = pipeline.apply(squery, SiteNotes.class);
			Criteria criteria = condition.query(new MongoVisitor());
			log.info("criteria ->  {} , value ->  {} ",criteria.getKey(), criteria.getCriteriaObject().toJson());
			query.addCriteria(criteria);
		}catch (Exception x) {
			throw new ApiException(ErrorCodes.EXCEPTION_400_BAD_REQUEST.toString(), x.getMessage());
		}
		//log.debug("criteria->  {} , value->  {} ", criteria.getKey(), criteria.getCriteriaObject().toJson());
		Collection<Object> collectionList = query.getQueryObject().values();
		for (Object object : collectionList) {
			if (object instanceof BasicDBList) {
				BasicDBList dbList = (BasicDBList) object;
				if (dbList.size() > searchLimit) {
					throw new ApiException("500", "Search query exceeded the limit");
				}
			}
		}
		return query;
	}
	
	
	public String convertToISODateString(String squery) {

		if ((squery.contains("timestampc") || squery.contains("timestampu"))) {
			
			Pattern pattern = Pattern.compile("'(\\d{4}-\\d{2}-\\d{2}) (\\d{2}:\\d{2}:\\d{2})(\\.\\d{1,9})?'");
	        Matcher matcher = pattern.matcher(squery);

	        StringBuffer sb = new StringBuffer();

	        while (matcher.find()) {
	            String date = matcher.group(1);
	            String time = matcher.group(2);
	            String millis = matcher.group(3);

	            String normalizedMillis = normalizeMillis(millis);

	            // Replacement string with T and Z, preserving single quotes
	            String replacement = "'" + date + "T" + time + normalizedMillis + "Z'";

	            matcher.appendReplacement(sb, replacement);
	        }
	        matcher.appendTail(sb);

	        return sb.toString();
		} else {
			return squery;
		}
	}
	
	public static String normalizeMillis(String millis) {
        if (millis == null || millis.isEmpty()) {
            return ".000";
        }
        String digits = millis.substring(1); // remove the dot
        if (digits.length() == 1) {
            return ".00" + digits;
        }
        if (digits.length() == 2) {
            return ".0" + digits;
        }
        if (digits.length() >= 3) {
            return "." + digits.substring(0, 3);
        }
        return ".000";
    }

	public List<AttachmentData> removeLinks(List<com.ge.ren.attachments.model.patch.Attachment> attachmentList, List<AttachmentData> attachments){
		Iterator <com.ge.ren.attachments.model.patch.Attachment> it = attachmentList.iterator(); 
		Path path = null;
		while(it.hasNext()) {
			try {
				com.ge.ren.attachments.model.patch.Attachment atmt = it.next();
				log.debug(" PATCH file to delete -> {}", atmt.getPath());
				if(!storageType.equalsIgnoreCase(S3BUCKET)) { // save to fileSystem
					path = Paths.get(atmt.getPath().substring((AWS_PATH1+activeProfile+AWS_PATH2).length()));
					Files.delete(path);
				}else {
					awsUploader.removeS3Object(atmt.getPath().substring((AWS_PATH1+activeProfile+AWS_PATH2).length()));
				}
				List<AttachmentData> list = attachments.parallelStream().filter(p -> p.getFile().contains(atmt.getPath())).collect(Collectors.toList());
				if(list.size() > 0) { 
					attachments.removeAll(list);
				}
			} catch (NoSuchFileException x) {
			    log.error("No such file or directory exists: {}", path);
			    throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), "No such file or directory exists:" + path);
			}catch (IOException x) {
			    // File permission problems are caught here.
				log.error("File/Folder Permission Exception {}", x);
				throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), x.getMessage());
			}
		}
		return attachments;
	}
	
	
    /**
     * Entry point to a query processing
     * @param tenantId
     * @param query
     * @param fields
     * @param pageIdx
     * @param pageSize
     * @param sortKey
     * @param orderDirection
     * @param responseType
     * @return
     * @throws JsonProcessingException
     */
    public Map<String,Object> processQuery(String tenantId, String domain, Optional<String> query, Optional<String> fields, Optional<Integer> pageIdx, 
    									Optional<Integer> pageSize, Optional<String> sortKey, Optional<String> orderDirection, String responseType) {        
    	String pageSortKey = null;
    	if(sortKey.isPresent()) {
    		switch(domain) {
    		case "siteNotes": 
    			pageSortKey =  sortKey.get();
    			break;
    		case "assetNotes": 
    			pageSortKey =  sortKey.get();
    			break;
    		case "caseNotes": 
    			pageSortKey =  sortKey.get();
    			break;
    		case "eventNotes": 
    			pageSortKey =  sortKey.get();
    			break;
    		case "taskNotes": 
    			pageSortKey =  sortKey.get();
    			break;
    		default:
    			pageSortKey =  "id";
    			break;
    		}
    		
    	}else {
			pageSortKey =  "id";
    	}

    	Integer pageSearchInx = (!pageIdx.isPresent()) ? 1 : pageIdx.get();
        Integer pageSearchSize = (!pageSize.isPresent()) ? 1 : pageSize.get();

 
     	Sort.Direction   direction =  (orderDirection.isPresent()) ? Sort.Direction.DESC : Sort.Direction.ASC;

        PageRequest pageRequest = PageRequest.of(pageSearchInx, pageSearchSize, direction, pageSortKey);        
        if ("".equals(responseType)){
            responseType = MediaType.MULTIPART_MIXED_VALUE;
        }else {
        	responseType = MediaType.APPLICATION_JSON_VALUE;
        }
        Map<String,Object> keys = new HashMap<>();
        keys.put("pageSortKey", pageSortKey);
        keys.put("pageSearchInx", pageSearchInx);
        keys.put("pageSearchSize", pageSearchSize);
        keys.put("pageRequest", pageRequest);
        keys.put("responseType", responseType);
        keys.put("direction", direction);
        
        return keys;

    }
    
    /**
     * Logic - 
     * a.	If only current capability i.e. “Notes and Attachments”, exist then only provide access to external notes.
     * b.	If current capability and new capability i.e. “Internal Access” exists then provide access to both internal & external notes.
     * c.   If only “Internal Access” capability exists, then provide access to both internal & external notes.
     * d.   For the super-admin role, allow change(POST, PATCH & DEL) to any notes including retrieval (GET).
     * e.   Ensuring, that only exterior notes access with 'Notes and Attachments' capability can post/delete/patch exterior notes.
     * f.   If user is not Super Admin, ensuring that createdBy field (i.e. username) matches with username from token, if success then permit PATCH & DELETE.
     *      - Changes done on Aug-12-2022 for point f. Introduced a new capability named 'Notes Admin' to handle cross user notes update (i.e. patch & delete).
     *      - If 'Notes Admin' capability exist then allow patch & delete operation for notes which is created by a different user. 
     * @param requestInterceptor
     * @return String
     */
    public String determineNotesScopeFromCapabilitiesAndRoles(RequestInterceptor requestInterceptor) {
    	String scopeAccess = "";
    	StringBuilder strBuilder = new StringBuilder(requestInterceptor.getTenantId()).append("-").append(Constants.ROLE_SUPER_ADMIN);
    	log.info("** Roles -> "+requestInterceptor.getUserRoles());
    	log.info("** Capabilities -> "+requestInterceptor.getUserCapabilities());
    	if(requestInterceptor.getUserRoles() != null && 
    	   requestInterceptor.getUserRoles().size() > 0 && 
    	   requestInterceptor.getUserRoles().contains(strBuilder.toString())) {
    		scopeAccess = Constants.ROLE_SUPER_ADMIN;
    	}else if(requestInterceptor.getUserCapabilities() != null && 
    			 requestInterceptor.getUserCapabilities().size() > 0 && 
    			 requestInterceptor.getUserCapabilities().contains(Constants.NOTES_AND_ATTACHMENTS) && 
        		 requestInterceptor.getUserCapabilities().contains(Constants.INTERNAL_ACCESS)) {
        	scopeAccess = Constants.BOTH_INTERNAL_AND_EXTERNAL;
    	}else if(requestInterceptor.getUserCapabilities() != null && 
   			     requestInterceptor.getUserCapabilities().size() > 0 && 
   			     requestInterceptor.getUserCapabilities().contains(Constants.NOTES_AND_ATTACHMENTS) && 
        		!requestInterceptor.getUserCapabilities().contains(Constants.INTERNAL_ACCESS)) {
    		scopeAccess = Constants.SCOPE_EXTERNAL;
    	}else if(requestInterceptor.getUserCapabilities() != null &&
  			     requestInterceptor.getUserCapabilities().size() > 0 &&
    			!requestInterceptor.getUserCapabilities().contains(Constants.NOTES_AND_ATTACHMENTS) && 
        		requestInterceptor.getUserCapabilities().contains(Constants.INTERNAL_ACCESS)) {
    		scopeAccess = Constants.BOTH_INTERNAL_AND_EXTERNAL;
    	}
    	return scopeAccess;
    }
    
    public void setNotesScopeInQuery(Query query, String scopeAccess) {
    	log.info("** scopeAccess -> "+scopeAccess);
    	query.addCriteria(Criteria.where(Constants.SCOPE).is(scopeAccess));
    }
    
    /**
     * Logic - Allowing patch on scope attribute as per access.
     *         e.g. A person having access to external notes cannot patch scope to internal.
     *         
     * @param patchList
     * @param requestInterceptor
     * @return
     */
    public Boolean checkScopeInPatch(List<Patch> patchList, RequestInterceptor requestInterceptor) {
    	boolean scopeFlag = false;
    	for(Patch patch : patchList){
    		if(patch.getPath().equals(Constants.SCOPE_ATTRIBUTE) && 
    				(patch.getValue().equals(Constants.SCOPE_VALUE) || patch.getValue().equals("")) &&
    				determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor).equals(Constants.SCOPE_EXTERNAL)) {
    			scopeFlag = true;
    			break;
    		}
    	}
    	return scopeFlag;
    }
	
}