package com.ge.ren.notes.exception;

import org.springframework.http.HttpStatus;

public class UnAuthorizedException extends ApiException {
    public UnAuthorizedException(String msg) {
        super(HttpStatus.UNAUTHORIZED.toString(), msg);
    }
}
