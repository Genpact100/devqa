package com.ge.ren.notes.service.impl;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static com.ge.ren.notes.constants.Constants.*;

import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.model.patch.Patch;
import com.ge.ren.attachments.utils.AwsUploader;
import com.ge.ren.attachments.utils.FileUploader;
import com.ge.ren.attachments.utils.PatchHelper;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.constants.ErrorConstants.ErrorCodes;
import com.ge.ren.notes.constants.ErrorConstants.VaidatedMessage;
import com.ge.ren.notes.constants.Constants;
import com.ge.ren.notes.constants.ErrorConstants;
import com.ge.ren.notes.constants.Priority;
import com.ge.ren.notes.constants.Scope;
import com.ge.ren.notes.constants.Status;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.exception.Error;
import com.ge.ren.notes.model.AssetNotes;
import com.ge.ren.notes.model.CaseNotes;
import com.ge.ren.notes.model.EventNotes;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.model.UpsertNote;
import com.ge.ren.notes.model.SiteNotes;
import com.ge.ren.notes.model.TaskNotes;
import com.ge.ren.notes.model.FailedNote;
import com.ge.ren.notes.repository.SiteNotesRepository;
import com.ge.ren.notes.service.NotesService;
import com.ge.ren.notes.utils.ApiUtil;
import com.ge.ren.notes.utils.DateFormatMS;
import com.ge.ren.notes.utils.JacksonConfiguration;
import com.ge.ren.notes.utils.ValidateUtil;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class NotesServiceImpl implements NotesService {

 	@Autowired
	SiteNotesRepository notesRepository;

 	@Autowired
 	MongoTemplate mongoTemplate;
    @Autowired
    JacksonConfiguration jc;   
    
    @Autowired
    ApiUtil apiUtil;
    
    @Autowired
    DateFormatMS dateFormat;
    
    @Autowired
    FileUploader fileUploader;
    
    @Autowired
    AwsUploader awsUploader;
    
    @Autowired
    ObjectMapper objectMapper;
    
    @Autowired
    PatchHelper patchHelper;
    
    @Value("${storage.type:s3aws}")
	private String storageType;
    
    @Value("${aws.bucket.prefix:TODO_add_to_properties}")
	private String bucket;
    private static final String HTTPS = "https://";
    
    @Value("${spring.profiles.active}")
    String activeProfile;
    
    @Autowired
    private RequestInterceptor requestInterceptor;
    
    /*
     * Method Get Site Notes for all or by parameters
     * @method GetNotesRequest
     * @param NotesRequest
     * @return String
     */
    @Override
	public String processGetRequest(NotesRequest request) throws IOException {    	
		List<Note> notes = new ArrayList <>(); 
		Query query = new Query();
		if(null != request.getQuery()) {
			query = apiUtil.getCriteriaFromQueryParser(request.getQuery(), query);
		}
		
		String scopeAccess = apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor);
		if(scopeAccess.equals(Constants.SCOPE_EXTERNAL)) {
			apiUtil.setNotesScopeInQuery(query, scopeAccess);
		}
		log.info("Query Object : "+query.getQueryObject());
		
		if(null != request.getId()) {
			query.addCriteria(Criteria.where(TENANTID).is(request.getTenantId()).and("id").is(request.getId()).and(DELETED).ne(true)).fields().exclude(TIMESTAMPC).exclude(TIMESTAMPU);
			notes = processUpdateLinks(request.getId(), apiUtil.getNotesByDomain(request, query), request.getDomain());
			log.debug(">>>>> GET NOTE by ID - > {}", notes);
			return (!notes.isEmpty())? jc.getOMconfiguration(new ObjectMapper()).writeValueAsString(notes.get(0)) : new String("{}");
		}else if(null != request.getDomainIds()){
			if(request.getDomainIds().contains(SPLIT_RULE)) {
				List<String> ids = Arrays.asList(request.getDomainIds().split(SPLIT_RULE));
				query.addCriteria(Criteria.where(TENANTID).is(request.getTenantId()).and(DOMAIN_ID).in(ids).and(DELETED).ne(true));
			}else {
				query.addCriteria(Criteria.where(TENANTID).is(request.getTenantId()).and(DOMAIN_ID).is(request.getDomainIds()).and(DELETED).ne(true));						
			}
		}else {
			query.addCriteria(Criteria.where(TENANTID).is(request.getTenantId()).and(DELETED).ne(true));
		}
		setCountBasedOnNotesType(request, query);
		query.with(PageRequest.of(request.getPageIdx(), request.getPageSize(), org.springframework.data.domain.Sort.Direction.DESC, PAGE_SEARCH_SORT_KEY));
		if(null != request.getFilter()) {
			List<String> filters = Arrays.asList(request.getFilter().split(SPLIT_RULE));
			final Query tQuery = query;
			filters.stream().forEach(filter -> { 
				tQuery.fields().include(filter);
			});
			query = tQuery;
		}else {
			query.fields().exclude(TIMESTAMPC).exclude(TIMESTAMPU);
		}
		return  objectMapper.writeValueAsString(ValidateUtil.setPaginationMetadata(processUpdateLinks(request.getId(), apiUtil.getNotesByDomain(request, query), request.getDomain()), request));
	}

	private void setCountBasedOnNotesType(NotesRequest request, Query query) {
		if(request.getDomain().equals("siteNotes")) {
			request.setCount((int) mongoTemplate.count(query, SiteNotes.class));
		}else if(request.getDomain().equals("assetNotes")) {
			request.setCount((int) mongoTemplate.count(query, AssetNotes.class));
		}else if(request.getDomain().equals("eventNotes")) {
			request.setCount((int) mongoTemplate.count(query, EventNotes.class));
		}else if(request.getDomain().equals("taskNotes")) {
			request.setCount((int) mongoTemplate.count(query, TaskNotes.class));
		}else if(request.getDomain().equals("caseNotes")) {
			request.setCount((int) mongoTemplate.count(query, CaseNotes.class));
		}
	}
    
	/*
	 * Process POST request
	 * @param NotesRequest request
	 * @return ResponseEntity<Object>
	 */
	@Override
	public <T> ResponseEntity<?> processPostRequest(NotesRequest request , Optional<MultipartFile[]> multipartFiles) throws JsonParseException, IOException{ 
		log.debug("Date- > {} " , dateFormat.getCurrentDateFormated());
		try {
			ValidateUtil.validateJsonString(jc.getOMconfiguration(new ObjectMapper()).writeValueAsString(((PostNote)request.getBody())));
			Note notes = new Note (((PostNote)request.getBody()));
			ValidateUtil.validatePostRequest(notes, (multipartFiles.isPresent() && !multipartFiles.isEmpty()? multipartFiles.get(): null), POST);
			PostNote pn = ((PostNote) request.getBody());
			if(StringUtils.hasLength(pn.getTitle())) {
				pn.setTitle(ValidateUtil.validateForSpecChars(pn.getTitle(), TITLE));				
			}
			if(StringUtils.hasLength(pn.getNote())) {
				pn.setNote(ValidateUtil.validateForSpecChars(pn.getNote(), NOTE));
			}
			String scopeAccess = apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor);			
			log.info("pn.getScope -> "+pn.getScope()+" scopeAccess -> "+scopeAccess);
            if(scopeAccess.equals(Constants.SCOPE_EXTERNAL) && 
            		(org.apache.commons.lang3.StringUtils.isEmpty(pn.getScope()) || pn.getScope().equals(Constants.SCOPE_INTERNAL))) {
            	return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.AUTHORIZATION_ERROR.errordescription(), VaidatedMessage.NOT_AUTHORIZED.description() + pn.getScope()), HttpStatus.UNAUTHORIZED);
			}
			
			//Save Attachments into bucket
			Note note = new Note();
			if(multipartFiles.isPresent() && !multipartFiles.isEmpty()) {
				note.setAttachments(fileUploader.uploadFiles( request.getDomain(), multipartFiles.get()));
			}
			note.setDomainId(pn.getDomainId());  note.setTenantId(request.getTenantId()); note.setTitle(pn.getTitle());  note.setNote(pn.getNote()); note.setCreationDate(dateFormat.getCurrentDateFormated());  note.setUpdateDate(dateFormat.getCurrentDateFormated());  note.setValidDateBy(pn.getValidDateBy());  note.setPriority(((null != pn.getPriority()) ? pn.getPriority(): Priority.LOW.toString() ));  note.setCreatedBy(request.getCreatedBy());  note.setUpdatedBy(request.getCreatedBy());  note.setCategory(pn.getCategory());  note.setStatus(((null != pn.getStatus()) ? pn.getStatus(): Status.active.toString()));  note.setScope(((null != pn.getScope()) ? pn.getScope(): Scope.internal.toString()));
			note.setTimestampc(new Timestamp(System.currentTimeMillis()));  note.setTimestampu(new Timestamp(System.currentTimeMillis()));
			note = mongoTemplate.save(note, request.getDomain());
			note.setTimestampc(null);note.setTimestampu(null);
			log.debug("Note Saved ->> {}" , note);
			return new ResponseEntity<> (jc.getOMconfiguration(new ObjectMapper()).writeValueAsString(note), HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("Exception processPostRequest: {} ",e);
			throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), e.getMessage());
		}
	}
	
	public <T> ResponseEntity<?> processBulkUpsertRequest(List<NotesRequest> requests) throws JsonParseException, IOException {

		try {	
			String collectionName = requests.get(0).getDomain();
			List<FailedNote> failedNotes = new ArrayList<>();
			BulkOperations bulkOps = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, Note.class, collectionName);
			int upsertCount = 0;
			for (NotesRequest request : requests) {				
				UpsertNote pn = (UpsertNote) request.getBody();
				try {	
					pn.initializeOnPremIdFromId();
					if (!StringUtils.hasLength(pn.getOnPremId())) {
						failedNotes.add(new FailedNote(pn.getOnPremId(), "400", "onPremId is required"));
						continue;
					}				
					ValidateUtil.validateJsonString(jc.getOMconfiguration(new ObjectMapper()).writeValueAsString(pn));
					
					ValidateUtil.validatePatchRequest(pn, PATCH);
					
					if (StringUtils.hasLength(pn.getTitle())) {
						pn.setTitle(ValidateUtil.validateForSpecChars(pn.getTitle(), TITLE));
					}
					if (StringUtils.hasLength(pn.getNote())) {
						pn.setNote(ValidateUtil.validateForSpecChars(pn.getNote(), NOTE));
					}	
					
					Query query = new Query();
					query.addCriteria(Criteria.where("onPremId").is(pn.getOnPremId()));
					Update update = new Update()
						.set("note", pn.getNote())
						.set("title", pn.getTitle())
						.set("priority", pn.getPriority())
						.set("category", pn.getCategory())
						.set("status", pn.getStatus())
						.set("scope", pn.getScope())
						.set("validDateBy", pn.getValidDateBy())
						.set("updatedBy", pn.getUpdatedBy())
						.set("updateDate", pn.getUpdateDate())					
						.set("createdBy", pn.getCreatedBy())
						.set("creationDate", pn.getCreationDate())
						.set("domainId", pn.getDomainId())
						.set("tenantId", request.getTenantId())	
						.set("deleted", pn.getDeleted())
						.set("attachments", pn.getAttachments())					
						.setOnInsert("timestampc", pn.getTimestampc())
						.setOnInsert("timestampu", pn.getTimestampu());
					bulkOps.upsert(query, update);
					upsertCount++;
					
				} catch (Exception e) {
					// Add failed object and error message
					failedNotes.add(new FailedNote(pn.getOnPremId(),"400", e.getMessage()));
				}
			}	
			if (upsertCount > 0) {
				bulkOps.execute();
			}
			return ResponseEntity.status(HttpStatus.OK).body(failedNotes);

		} catch (Exception e) {
			log.error("Exception processPostRequest: {} ", e);
			throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), e.getMessage());
		}
    }

	/*
	 * Delete note
	 * @param NotesRequest request
	 * @param Class<T> entityClass
	 * return <T> ResponseEntity<Object>
	 */
    @Override
	public <T> ResponseEntity<Object> processDeleteRequest(NotesRequest request, Class<T> entityClass) throws IOException {
		log.debug("-->> IN DELETE Date- > {}  ID-> {}" , dateFormat.getCurrentDateFormated(), request.getId());
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(request.getId())).fields().include(ATTACHMENTS);
		query.fields().include(DELETED).include(ATTACHMENTS).include(DOMAIN_ID).include(SCOPE).include(CREATED_BY).include(CATEGORY);
		Note note = (Note) mongoTemplate.findOne(query, entityClass, request.getDomain());
		String scopeAccess = apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor);
		if(null == note) {
			return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.CODE_404.errordescription(), VaidatedMessage.NOT_FOUND.description() + request.getId()), HttpStatus.NOT_FOUND);
		}else if(scopeAccess.equals(Constants.EXTERNAL) && !note.getScope().equals(scopeAccess)){
			return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.AUTHORIZATION_ERROR.errordescription(), VaidatedMessage.NOT_AUTHORIZED_SCOPE_1.description()), HttpStatus.UNAUTHORIZED);
		}else if(scopeAccess.equals(Constants.EXTERNAL) && !note.getCreatedBy().equals(requestInterceptor.getUsername()) && !requestInterceptor.getUserCapabilities().contains(Constants.NOTES_ADMIN)){
			return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.AUTHORIZATION_ERROR.errordescription(), VaidatedMessage.NOT_AUTHORIZED_USERNAME_2.description()), HttpStatus.UNAUTHORIZED);
		}else if(scopeAccess.equals(Constants.BOTH_INTERNAL_AND_EXTERNAL) && !note.getCreatedBy().equals(requestInterceptor.getUsername()) && !requestInterceptor.getUserCapabilities().contains(Constants.NOTES_ADMIN)){
			return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.AUTHORIZATION_ERROR.errordescription(), VaidatedMessage.NOT_AUTHORIZED_USERNAME_3.description()), HttpStatus.UNAUTHORIZED);
		}
		
		//log.debug("path before DELETE  -> {}", jc.getOMconfiguration(new ObjectMapper()).writeValueAsString(note));
		if(null != note.getAttachments()) {
			//Delete attached files
			Iterator<AttachmentData> it = note.getAttachments().iterator(); Path path = null;
			while(it.hasNext()) {
				try {
					AttachmentData at =  it.next();
					if(!storageType.equalsIgnoreCase(S3BUCKET)) { // save to fileSystem
						path = Paths.get( at.getFile());
						log.debug("path to DELETE -> {}", at.getFile());
					    Files.delete( path);
					}else { // save to aws
						log.debug("in service AWS Delete File ->  " + at.getFile());
						awsUploader.removeS3Object(at.getFile().substring((AWS_PATH1+activeProfile+AWS_PATH2).length()));
					}
				} catch (NoSuchFileException x) {
				    log.error("No such file or Folder exists: {}, {}", path.getRoot(), path.getFileName());
				    throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), x.getMessage());
				}catch (IOException x) {
					log.error("File/Folder Permission Exception: {}", x);
					throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), x.getMessage());
				}
			}
		}

		note.setDeleted(true); note.setDomainId(note.getDomainId()); note.setTenantId(request.getTenantId()); note.setUpdatedBy(request.getCreatedBy());	note.setUpdateDate(dateFormat.getCurrentDateFormated()); note.setTimestampu(dateFormat.getcurrentTimestamp());	note.setAttachments(null);
		log.info("Tenent Id in the request: {}",request.getTenantId());
		mongoTemplate.save(note, request.getDomain());
	//	 mongoTemplate.findAndModify(query, new Update().set(DELETED, true).set(UPDATEDBY, request.getCreatedBy()).set(UPDATEDATE, dateFormat.getCurrentDateFormated()).set(TIMESTAMPU, dateFormat.getcurrentTimestamp()).set(ATTACHMENTS, null).set(DOMAIN_ID,note.getDomainId() ), entityClass, request.getDomain());

		return new ResponseEntity<> (request.getId(), HttpStatus.OK);
	}
	
	/* 
	 * processPatchRequest
	 * @param NotesRequest request
	 * @param Class<T> entityClass
	 * @return <T> ResponseEntity<Object>
	 */
    @Override
	public <T> ResponseEntity<Object> processPatchRequest(NotesRequest request, Class<T> entityClass, Optional<MultipartFile[]> multipartFiles) throws ApiException, JsonParseException, IOException {

		log.info("## Date -> {} " , dateFormat.getCurrentDateFormated());
		Map<String, Note> patch = new HashMap<>();
		ValidateUtil.validateJsonString( objectMapper.writeValueAsString(((JsonPatch)request.getBody())));
		List<AttachmentData> attachments = new ArrayList<>();
		Update update = new Update();
		Note updated = new Note();
		try {

			Note note = (Note) mongoTemplate.findOne(compileQuery(request.getId()), entityClass, request.getDomain());
			patch.put(ORIGINAL, note);
			String scopeAccess = apiUtil.determineNotesScopeFromCapabilitiesAndRoles(requestInterceptor);
			log.info("** scopeAccess -> "+scopeAccess);
			if(null == note) {
				return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.CODE_404.errordescription(), VaidatedMessage.NOT_FOUND.description() + request.getId()), HttpStatus.NOT_FOUND);
			}else if(scopeAccess.equals(Constants.SCOPE_EXTERNAL) && !note.getScope().equals(scopeAccess)){
				log.info("1-scopeAccess -> "+scopeAccess+" get-Scope() -> "+note.getScope()+" get-CreatedBy() -> "+note.getCreatedBy());
				return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.AUTHORIZATION_ERROR.errordescription(), VaidatedMessage.NOT_AUTHORIZED_SCOPE_1.description()), HttpStatus.UNAUTHORIZED);
			}else if(scopeAccess.equals(Constants.SCOPE_EXTERNAL) && !note.getCreatedBy().equals(requestInterceptor.getUsername()) && !requestInterceptor.getUserCapabilities().contains(Constants.NOTES_ADMIN)){
				log.info("2-scopeAccess -> "+scopeAccess+" get-Scope() -> "+note.getScope()+" get-CreatedBy() -> "+note.getCreatedBy());
				return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.AUTHORIZATION_ERROR.errordescription(), VaidatedMessage.NOT_AUTHORIZED_USERNAME_2.description()), HttpStatus.UNAUTHORIZED);
			}else if(scopeAccess.equals(Constants.BOTH_INTERNAL_AND_EXTERNAL) && !note.getCreatedBy().equals(requestInterceptor.getUsername()) && !requestInterceptor.getUserCapabilities().contains(Constants.NOTES_ADMIN)){
				log.info("3-scopeAccess -> "+scopeAccess+" getScope() -> "+note.getScope()+" getCreatedBy() -> "+note.getCreatedBy());
				return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.AUTHORIZATION_ERROR.errordescription(), VaidatedMessage.NOT_AUTHORIZED_USERNAME_3.description()), HttpStatus.UNAUTHORIZED);
			}else if(null != note.attachments){
				log.debug("note.getAttachments()  {}", note);
				attachments.addAll(note.getAttachments());
			}
			if(null != request.getBody()) {
				JsonPatch jsonPatch =  (JsonPatch) request.getBody();
				List<Patch> patchList = jsonPatch.getPatch();
				if(apiUtil.checkScopeInPatch(patchList, requestInterceptor)) {
					return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.AUTHORIZATION_ERROR.errordescription(), VaidatedMessage.NOT_AUTHORIZED_SCOPE_OR_USERNAME.description()), HttpStatus.UNAUTHORIZED);
				}
				if(null != patchList) {
					updated =  patchHelper.applyPatch(note, objectMapper.writeValueAsString(patchList) );
					ValidateUtil.validatePostRequest(updated, (multipartFiles.isPresent() && !multipartFiles.isEmpty()? multipartFiles.get(): null), PATCH);
				}
				log.debug("notes - > {}", updated.toString());
				if (null != jsonPatch.getAttachments()){
					attachments = apiUtil.removeLinks(jsonPatch.getAttachments(), attachments);
				}
			}
			log.debug("FILES files.isPresent() -->> {} && !files.isEmpty() ->>> {} ", multipartFiles.isPresent() , multipartFiles.isEmpty());
			if(multipartFiles.isPresent() && !multipartFiles.isEmpty()) {
				attachments.addAll(fileUploader.uploadFiles( request.getDomain(), multipartFiles.get()));
			}
			log.debug("attachments ->> {}", new ObjectMapper().writeValueAsString(attachments));
			update = validateFields(updated);			
			updated.setUpdatedBy(request.getCreatedBy());
			updated.setUpdateDate(dateFormat.getCurrentDateFormated());
			updated.setAttachments(attachments);
			update.set(UPDATEDBY, request.getCreatedBy()).set(ATTACHMENTS, attachments);
			mongoTemplate.findAndModify(compileQuery(request.getId()), update, entityClass, request.getDomain()); //mongoTemplate.save(update, request.getDomain()); 
			patch.put("updated", updated);						
			
			log.debug("NOTE patched ->> {}" , patch);
			return new ResponseEntity<> (jc.getOMconfiguration(new ObjectMapper()).writeValueAsString(patch) , HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception processPatchRequest: {} ", e);
			throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), e.getMessage());
		}
	}
    
	
	@Override
	public List<Note> processUpdateLinks(String id, List<Note> attachments, String domainName) { 		log.debug("Process update links started - > {} " , attachments);
		Query query = new Query();	query.addCriteria(Criteria.where(ID).is(id)).fields().include(DOMAINNAME).include(DOMAIN_ID).include(TENANTID).include(TITLE).include(DESCRIPTION).include(CREATED_BY).include(UPDATEDBY).include(UPDATEDATE).include(ATTACHMENTS);
		Update update = new Update();
		try {
			Iterator<Note> it = attachments.iterator(); boolean updated = true;
			while(it.hasNext()) {
				Note at = it.next();
				if (null != at.attachments) {
					log.debug("attachments Found: {}", at.attachments);
					List<AttachmentData> atsNew = new ArrayList<>(); List<AttachmentData> ats = at.getAttachments(); List<AttachmentData> atsOld = new ArrayList<>();
					Iterator <AttachmentData> itr = ats.iterator();
					while(itr.hasNext()) {
						AttachmentData ad = itr.next(); String key = ad.getFile();
						if(key.contains("?")) {
							String dateStr = key.substring(key.indexOf("X-Amz-Date=")+11, key.indexOf("X-Amz-Date=") + 19); 
							SimpleDateFormat formatter = new SimpleDateFormat(AWS_DATE_PATTERN); Date date = formatter.parse(dateStr); Timestamp ts = new java.sql.Timestamp(date.getTime());
							log.debug("ts Before Current -> {} ", ts.before( new Date((Instant.now().toEpochMilli() - (1000*60*60)*8))) );
							if((ts.after( new Date((Instant.now().toEpochMilli() - (1000*60*60)*8)))) || ts.before( new Date((Instant.now().toEpochMilli())))) {
								key = key.substring(key.indexOf(".com/")+5, key.indexOf("?")); log.debug("bucket + key -> {} ", bucket+key ); URL url = fileUploader.updateLinks(bucket, key);
								atsNew.add(new AttachmentData(HTTPS + url.getHost() + url.getFile(), ad.getContentType(), ad.getFileName()));	atsOld.add(ad); 
							}
						}
					}
					if(!atsNew.isEmpty()) {	ats.removeAll(atsOld); ats.addAll(atsNew); update.set(ATTACHMENTS, ats); updated = true;}
				}		
				update = validateFields(at); update.set(UPDATEDBY, PRESIGNED);  			
				if(updated) { mongoTemplate.findAndModify(query, update, Class.forName("com.ge.ren.notes.model."+(domainName.substring(0,1).toUpperCase() + domainName.substring(1))), domainName);
								log.debug("Links updated ->> {}" , update);
				}
			}	
			
			return attachments;
		} catch (Exception e) {
			log.error("Exception processUpdateLinks: {} ",e);
			throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), e.getMessage());
		}
	}
	/*
	 * 
	 */
	public Update validateFields(Note note) {
		Update update = new Update();
		if(null != note.getTitle()) {
			update.set("title", note.getTitle());
		}
		if(null != note.getNote()) {
			update.set("note", note.getNote());
		}
		if(null !=  note.getPriority()) {
			update.set("priority", note.getPriority());	
		}
		if(null != note.getCategory()){
			update.set("category", note.getCategory());
		}
		if(null != note.getScope()) {
			update.set("scope", note.getScope());
		}
		if(null != note.getStatus()){
			update.set("status", note.getStatus());
		}
		if(null != note.getValidDateBy()){
			update.set(VALID_DATE_BY, note.getValidDateBy());
		}
		update.set("updateDate", dateFormat.getCurrentDateFormated())
			  .set(TIMESTAMPU, dateFormat.getcurrentTimestamp());				
		return update;
	}
	
	private Query compileQuery(String id) {
		Query query = new Query();
		query.addCriteria(Criteria.where(ID).is(id))
			.fields()
				.include(TENANTID)
				.include(CREATIONDATE)
				.include(CREATED_BY)
				.include(TITLE)
				.include(NOTE)
				.include(PRIORITY)
				.include(CATEGORY)
				.include(DOMAIN_ID)
				.include(STATUS)
				.include(VALIDDATEBY)
				.include(SCOPE)
				.include(UPDATEDBY)
				.include(UPDATEDATE)
				.include(ATTACHMENTS);
		return query;
	}
	
	/*
	 * searchByParams
	 * @param String
	 * @param String
	 * @param String
	 * @return Page<SiteNotes>
	 */
	public Page<SiteNotes> searchByParams(String id, String tenantId, String domainId){
		List<SiteNotes> notes = new ArrayList<>();

		Pageable pg = PageRequest.of(1, 10);

		 Page<SiteNotes> page = notesRepository.findByIdIn(Arrays.asList(id), pg);
		 page = notesRepository.findByIdNot( id, pg);
		 int count = 0;

		if (!page.getContent().isEmpty()) {
			page.getContent().forEach(k->  log.debug("id -> " + k.getId()));
		 	count += page.getNumberOfElements();
		}
		 page = notesRepository.findByIdNotIn(Arrays.asList(id), pg);
		 if (!page.getContent().isEmpty()) {
		 	page.getContent().forEach(k->  log.debug("id -> " + k.getId()));
		 	count += page.getNumberOfElements();
		 }
		 page = notesRepository.findByTenantIdAndId(tenantId, id, pg);
		 if (!page.getContent().isEmpty()) {
			 	page.getContent().forEach(k->  log.debug("id -> " + k.getId()));
			 	count += page.getNumberOfElements();
		 }
		 page = notesRepository.findByTenantIdAndIdNot(tenantId, id, pg);
		 if (!page.getContent().isEmpty()) {
			 	page.getContent().forEach(k->  log.debug("id -> " + k.getId()));
			 	count += page.getNumberOfElements();
		 }
		 page = notesRepository.findByTenantIdAndIdIn(tenantId, Arrays.asList(tenantId), pg);
		 if (!page.getContent().isEmpty()) {
			 	page.getContent().forEach(k->  log.debug("id -> " + k.getId()));
			 	count += page.getNumberOfElements();
		 }
		 page = notesRepository.findByTenantIdAndIdNotIn(tenantId, Arrays.asList(tenantId), pg);
		 
		 if (!page.getContent().isEmpty()) {
			 	page.getContent().forEach(k->  log.debug("note -> " + k.getId()));
		 	count += page.getNumberOfElements();
		 }

        
        page = notesRepository.findByTenantIdNot(tenantId, pg);
		 if (!page.getContent().isEmpty()) {
			 	page.getContent().forEach(k->  log.debug("tenantId -> " + k.getId()));
			 	count += page.getNumberOfElements();
		 }
        page = notesRepository.findByTenantIdIn(Arrays.asList(tenantId), pg);
		 if (!page.getContent().isEmpty()) {
			 	page.getContent().forEach(k->  log.debug("title -> " + k.getId()));
			 	count += page.getNumberOfElements();
		 }
        page = notesRepository.findByTenantIdNotIn(Arrays.asList(tenantId), pg);
		 if (!page.getContent().isEmpty()) {
			 	page.getContent().forEach(k->  log.debug("createdBy -> " + k.getId()));
			 	count += page.getNumberOfElements();
		 }
        page = notesRepository.findByTenantIdAndDomainIdIn(tenantId, Arrays.asList(domainId),  pg);
		 if (!page.getContent().isEmpty()) {
			 	page.getContent().forEach(k->  log.debug("creationDate -> " + k.getId()));
			 	count += page.getNumberOfElements();
		 }
		return page;
	}

}
