package com.ge.ren.notes.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import com.fasterxml.jackson.annotation.JsonAnySetter;

public class UrlEncodedWriter {
	
	private static final String Encoding = "UTF-8";
	
    private final StringBuilder stringBuilder = new StringBuilder();
    public UrlEncodedWriter() {}
    @JsonAnySetter
    public void write(String name, Object property) throws UnsupportedEncodingException {
        if (stringBuilder.length() > 0){
        	stringBuilder.append("&");
        }
        stringBuilder.append(URLEncoder.encode(name, Encoding)).append("=");
        if (property != null) {
        	stringBuilder.append(URLEncoder.encode(property.toString(), Encoding));
        }
    }

    @Override
    public String toString(){
        return stringBuilder.toString();
    }

}
