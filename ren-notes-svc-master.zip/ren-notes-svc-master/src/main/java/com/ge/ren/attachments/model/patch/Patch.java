
package com.ge.ren.attachments.model.patch;

import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.ge.ren.attachments.model.AttachmentData;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "op",
    "path",
    "value"
})
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Patch {

    @JsonProperty("op")
    public String op;
    @JsonProperty("path")
    public String path;
    @JsonProperty("value")
    public String value;

}
