package com.ge.ren.notes.constants;

public enum Status {
	active, inactive
}
