package com.ge.ren.notes.controller;

import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.utils.Autils;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.constants.Constants;
import com.ge.ren.notes.constants.DomainResources;
import com.ge.ren.notes.exception.Error;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.AssetNotes;
import com.ge.ren.notes.model.CaseNotes;
import com.ge.ren.notes.model.EventNotes;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.InlineResponse200;
import com.ge.ren.notes.model.SiteNotes;
import com.ge.ren.notes.model.TaskNotes;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.model.UpsertNote;
import com.ge.ren.notes.service.NotesService;
import com.ge.ren.notes.utils.ApiUtil;


import static com.ge.ren.notes.constants.Constants.MAX_FILE_SIZE;
import static com.ge.ren.notes.constants.Constants.SIZE_NOT_ALLOWED;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import java.io.IOException;
import java.text.ParseException;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/common/v2")
public class NotesApiControllerV2 {

    private final static String EMPTY_JSON_RESPONSE = "{}"; 
	@Autowired
    NotesService service;
	
    
    @Value("${pageNum:0}")
    private int pageNum;

    @Value("${pageSize:100}")
    private int pageSizeDef;
   
    @Autowired
    ApiUtil apiUtil;
    
    @Autowired
    private RequestInterceptor requestInterceptor;   
   
    @ApiOperation(value = "Upsert Notes for Assets", nickname = "apiV2NotesAssetsUpsert", notes = "Insert or update multiple notes for assets", response = SiteNotes.class,tags = { "Notes Service" })
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Upsert Successful", response = SiteNotes.class),
        @ApiResponse(code = 207, message = "Partial Success", response = SiteNotes.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class),
        @ApiResponse(code = 404, message = "Not Found", response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 409, message = "Conflict", response = Error.class) })
    @PatchMapping(value = "/asset-notes",
        produces = { MediaType.APPLICATION_JSON_VALUE },
        consumes = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<?> apiV2NotesAssetsUpsert(
         @RequestBody List<UpsertNote> upsertNotesList) throws JsonParseException, IOException {        
        String tenantId = apiUtil.retrieveTenantId(requestInterceptor);
        String userName = apiUtil.retrieveUserName(requestInterceptor);
       
        List<NotesRequest> requests = upsertNotesList.stream()
            .map(upsertNote -> new NotesRequest(
                DomainResources.assetNotes.toString(),
                upsertNote.getDomainId(),
                tenantId,
                upsertNote,
                null,
                userName
            ))
        .collect(Collectors.toList());
        return service.processBulkUpsertRequest(requests);
    }
    @ApiOperation(value = "Upsert Notes for Sites", nickname = "apiV2NotesSitesUpsert", notes = "Insert or update multiple notes for sites", response = SiteNotes.class,tags = { "Notes Service" })
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Upsert Successful", response = SiteNotes.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class),
        @ApiResponse(code = 404, message = "Not Found", response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 409, message = "Conflict", response = Error.class) })
    @PatchMapping(value = "/site-notes",
        produces = { MediaType.APPLICATION_JSON_VALUE },
        consumes = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<?> apiV2NotesSitesUpsert(
         @RequestBody List<UpsertNote> upsertNotesList) throws JsonParseException, IOException {        
        String tenantId = apiUtil.retrieveTenantId(requestInterceptor);
        String userName = apiUtil.retrieveUserName(requestInterceptor);
       
        List<NotesRequest> requests = upsertNotesList.stream()
            .map(upsertNote -> new NotesRequest(
                DomainResources.siteNotes.toString(),
                upsertNote.getDomainId(),
                tenantId,
                upsertNote,
                null,
                userName
            ))
        .collect(Collectors.toList());
        return service.processBulkUpsertRequest(requests);
    }
}
