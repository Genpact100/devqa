package com.ge.ren.notes.resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.ren.notes.model.ApplicationHealth;

@Component
public class HealthCheckResourceImpl implements HealthCheckResource {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(HealthCheckResourceImpl.class);
	
	@Autowired 
	private HealthCheckDetails healthcheckDetails;
	
	public void setHealthcheckDetails(HealthCheckDetails healthcheckDetails) {
		this.healthcheckDetails = healthcheckDetails;
	}

	public enum ErrorSeverity {
		MAJOR, MINOR
	}
	public enum AppErrorCode {
		DI_NULL_500, DI_NULL_501
	}
	
	@Override
	public ApplicationHealth getHealthCheck() {
		final ApplicationHealth applicationHealth= healthcheckDetails.getApplicationHealth();
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = null;
		try {
			jsonString = mapper.writeValueAsString(applicationHealth);
		} catch( Exception ex) {
			LOGGER.error("[{}] [{}] - Error message. ", AppErrorCode.DI_NULL_500, ErrorSeverity.MAJOR);
		}
		LOGGER.debug(jsonString);
		return applicationHealth;
	}

	@Override
	public ApplicationHealth getHealthCheckDeep() throws JsonProcessingException{
		final ApplicationHealth applicationHealth= healthcheckDetails.getApplicationHealth();
		String jsonString = new ObjectMapper().writeValueAsString(applicationHealth);
		LOGGER.debug(jsonString);
		return applicationHealth;
	}

}
