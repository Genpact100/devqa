package com.ge.ren.attachments.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.TreeNode;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jsonpatch.JsonPatchException;

import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Validator;

import java.io.IOException;

@Component
@RequiredArgsConstructor
public class PatchHelper {

		//@Autowired
	    //ObjectMapper objectMapper;

	    //private final Validator validator;

	    
	    /**
	    * Applies a JsonPatch to an object
	    */
	   @SuppressWarnings("unchecked")
	   public <T> T applyPatch(T originalObj, String patchString) throws JsonProcessingException, IOException, JsonPatchException {
		    // Parse the patch to JsonNode
		    //ObjectMapper objectMapper = new ObjectMapper();
		    //JsonNode patchNode = objectMapper.readTree(patchString);
		    // Create the patch
			//com.github.fge.jsonpatch.JsonPatch patching = com.github.fge.jsonpatch.JsonPatch.fromJson(objectMapper.readTree(patchString));
	        // Convert the original object to JsonNode
	        //JsonNode originalObjNode = objectMapper.valueToTree(originalObj);
	        // Apply the patch
	        //TreeNode patchedObjNode = patching.apply(objectMapper.valueToTree(originalObj));
		    // Convert the patched node to an updated obj
		    //return objectMapper.treeToValue(patching.apply(objectMapper.valueToTree(originalObj)), (Class<T>) originalObj.getClass());
		   ObjectMapper om = new ObjectMapper();
			return om.treeToValue(com.github.fge.jsonpatch.JsonPatch.fromJson(om.readTree(patchString))
									.apply(om.valueToTree(originalObj)), (Class<T>) originalObj.getClass());
	   }
	   
		/**
		 * Serializes an object to JSON string
		 * @throws JsonProcessingException 
		 */
		public static <T> String toJson(T obj)	throws RuntimeException, JsonProcessingException{
				return new ObjectMapper().writeValueAsString(obj);
		}


		/**
		 * Deserializes a JSON String
		 */
		public static <T> T fromJson(String json, Class<T> clazz) throws RuntimeException, JsonProcessingException{
			return new ObjectMapper().readValue(json, clazz);
		}
}
