package com.ge.ren.attachments.utils;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AwsDownloader { //extends AbstractDownloader {

    @Value("${storage.type:s3aws}")
	private String storageType;
    
    
    @Value("${aws.bucket.prefix:TODO_add_bucket_name_to_properties}")
	private String bucket;
    
    Region usEast1 = Region.getRegion(Regions.US_EAST_1);


}
