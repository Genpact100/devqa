package com.ge.ren.notes.exception;

public class InvalidParameterException extends ApiException {
 
	private static final long serialVersionUID = -2764054471193423499L;

	public InvalidParameterException(String msg) {
        super("Site Error ", msg);
    }
}
