
package com.ge.ren.attachments.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "file",
    "contentType",
    "fileName"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentData {

    @JsonProperty("file")
    public String file;
    @JsonProperty("contentType")
    public String contentType;
    @JsonProperty("fileName")
    public String fileName;
	
	@Override public String toString() { 
		return "{\"file\":\"" + file + "\",\"contentType\":\"" + contentType + "\",\"fileName\":\"" + fileName + "\"}"; }
	  			 
}
