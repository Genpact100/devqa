package com.ge.ren.notes.exception;

public class AttachmentNotFound extends ApiException {
 	private static final long serialVersionUID = 4511835238916381631L;

	public AttachmentNotFound(String msg) {
        super("Attachment not found with provided ID: ", msg);
    }
}
