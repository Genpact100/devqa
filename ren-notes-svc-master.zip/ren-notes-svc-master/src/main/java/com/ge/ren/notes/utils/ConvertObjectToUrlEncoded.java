package com.ge.ren.notes.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
//import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.stereotype.Component;
import com.ge.ren.notes.exception.NotImplementedException;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
//@Slf4j
@Component
public class ConvertObjectToUrlEncoded  implements HttpMessageConverter{

	private static final Logger log = LoggerFactory.getLogger(ConvertObjectToUrlEncoded.class);
	private static final String Encoding = "UTF-8";

    private final ObjectMapper mapper;

    public ConvertObjectToUrlEncoded(ObjectMapper mapper) {
        this.mapper = mapper;
    }
    public ConvertObjectToUrlEncoded() {
		this.mapper = new ObjectMapper(); }    
    
    @Override
    public boolean canWrite(Class clazz, MediaType mediaType){
        return getSupportedMediaTypes().contains(mediaType);
    }
    @Override
    public List<MediaType> getSupportedMediaTypes() {
        return Collections.singletonList(MediaType.APPLICATION_FORM_URLENCODED);
    }
    @Override
    public Object read(Class clazz, HttpInputMessage inputMessage) throws HttpMessageNotReadableException {
        throw new NotImplementedException("Method is not Implemented");
    }
    
    @Override
    public void write(Object o, MediaType contentType, HttpOutputMessage outputMessage) throws HttpMessageNotWritableException {
        if (o != null) {
            String body = mapper.convertValue(o, UrlEncodedWriter.class).toString();
            try {
                outputMessage.getBody().write(body.getBytes(Encoding));
            } catch (IOException e) {
                log.error("UTF-8 is not supporter: ", e);
            }
        }
    }

	@Override
	public boolean canRead(Class clazz, MediaType mediaType) {
		return false;
	}
}
