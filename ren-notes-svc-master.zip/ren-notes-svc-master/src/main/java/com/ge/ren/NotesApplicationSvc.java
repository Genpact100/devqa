package com.ge.ren;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.amqp.RabbitAutoConfiguration;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.data.mongo.MongoRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.embedded.EmbeddedMongoAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication(exclude = {ErrorMvcAutoConfiguration.class,
		/* RabbitAutoConfiguration.class, EmbeddedMongoAutoConfiguration.class */ 
} )
@ComponentScan(basePackages = {"com.ge.ren.attachments*, com.ge.ren.notes.*, com.ge.ren.common.keycloak.*"})
public class NotesApplicationSvc {

	public static void main(String[] args) {
		SpringApplication.run(NotesApplicationSvc.class, args);
	}

}
