package com.ge.ren.notes.utils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;
import com.fasterxml.jackson.annotation.JsonInclude;
@Component
public class JacksonConfiguration {

  
	@SuppressWarnings("deprecation")
	public ObjectMapper getOMconfiguration(ObjectMapper om){
		om.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		om.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		om.configure(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS, true);
		om.disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);
		om.disable(DeserializationFeature.FAIL_ON_UNRESOLVED_OBJECT_IDS);
		om.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return om;
	}
	
	public String getResponseBody(HttpServletRequest request) throws IOException {
		
	    String body = null;
	    StringBuilder stringBuilder = new StringBuilder();
	    BufferedReader bufferedReader = null;
	
	    try(InputStream inputStream = request.getInputStream()) {
	        if (inputStream != null) {
	            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
	            char[] charBuffer = new char[128];
	            int bytesRead = -1;
	            while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
	                stringBuilder.append(charBuffer, 0, bytesRead);
	            }
	        } else {
	            stringBuilder.append("");
	        }
	    } catch (IOException ex) {
	        throw ex;
	    }
	
	    body = stringBuilder.toString();
	    return body;
	}

}
