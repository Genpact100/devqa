
package com.ge.ren.notes.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.attachments.model.AttachmentData;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "domainId",
    "note",
    "title",
    "priority",
    "category",
    "scope",
    "status",
    "validDateBy",
    "attachements"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PostNote {

    @JsonProperty("domainId")
    public String domainId;
    @JsonProperty("note")
    public String note;
    @JsonProperty("title")
    public String title;
    @JsonProperty("priority")
    public String priority;
    @JsonProperty("category")
    public String category;
    @JsonProperty("scope")
    public String scope;
    @JsonProperty("status")
    public String status;
    @JsonProperty("validDateBy")
    public String validDateBy;
    @JsonProperty("attachments")
    public List<AttachmentData> attachments = null;
    
	@Override
	public String toString() {
		return "{\"domainId\":\"" + domainId + "\", \"note\":\"" + note + "\", \"title\":\"" + title + "\", \"priority\":\"" + priority
				+ "\", \"category\":\"" + category + "\", \"scope\":\"" + scope + "\", \"status\":\"" + status + "\", \"validDateBy\":\"" + validDateBy + "\", \"attachments\":" + attachments
				+ "}";
	}
    

}
