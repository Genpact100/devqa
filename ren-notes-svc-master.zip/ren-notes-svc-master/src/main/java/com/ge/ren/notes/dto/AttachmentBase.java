package com.ge.ren.notes.dto;

import java.sql.Timestamp;
import java.util.List;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.PostAttachment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



  @JsonPropertyOrder({ "id", "domainName", "domainId", "tenantId", "title",
  "description", "creationDate", "updateDate", "createdBy", "updatedBy",
  "timestampc", "timstampu", "attachments" })
 
@Document(collection = "attachments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AttachmentBase {

    @JsonProperty("id")
    public String id;
    @JsonProperty("domainName")
    public String domainName;
    @JsonProperty("domainId")
    public String domainId;
    @JsonProperty("tenantId")
    public String tenantId;
    @JsonProperty("title")
    public String title;
    @JsonProperty("description")
    public String description;
    @JsonProperty("creationDate")
    public String creationDate;
    @JsonProperty("updateDate")
    public String updateDate;
    @JsonProperty("createdBy")
    public String createdBy;
    @JsonProperty("updatedBy")
    public String updatedBy;
    @JsonProperty("timestampc")
    private Timestamp timestampc;
    @JsonProperty("timestampu")
    private Timestamp timestampu;
    @JsonProperty("attachments")
    public List<AttachmentData> attachments;
    
    public AttachmentBase(PostAttachment pa) {
    	this.description = pa.getDescription();
    	this.domainId = pa.getDomainId();
    	this.domainName = pa.getDomainName();
    	this.title = pa.getTitle();
    	this.attachments = pa.getAttachments();
    }

}
