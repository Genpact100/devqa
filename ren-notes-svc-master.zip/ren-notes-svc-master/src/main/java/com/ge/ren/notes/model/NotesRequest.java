package com.ge.ren.notes.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class NotesRequest {

    @Value("${pageNum:0}")
    private static int pageNum;

    @Value("${pageSizeDef:20}")
    private static int pageSizeDef;

    private String domain;
	private String domainIds;
	private String tenantId;
	private String filter;
	private Integer pageIdx;
	private Integer pageSize;
	private Object body;
	private String id;
	private String createdBy;
	private String creationDate;
	private String updateDate;
	private String category;
	private int count;
	private String query;
	private MultipartFile file;
	
	public NotesRequest(String domain, String domainIds, String tenantId, Object body, String id, String createdBy) {
		super();
		this.domain = domain;
		this.domainIds = domainIds; 
		this.tenantId = tenantId;
		this.body = body;
		this.id = id; // attachments
		this.createdBy = createdBy;
	}

	public NotesRequest(String domain, String domainIds, String tenantId, Object body, String id, String createdBy, MultipartFile file) {
		super();
		this.domain = domain;
		this.domainIds = domainIds; 
		this.tenantId = tenantId;
		this.body = body;
		this.id = id; // attachments
		this.createdBy = createdBy;
		this.file = file;
	}

}
