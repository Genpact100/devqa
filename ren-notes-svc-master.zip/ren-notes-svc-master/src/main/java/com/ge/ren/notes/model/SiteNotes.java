package com.ge.ren.notes.model;

import com.ge.ren.notes.dto.Note;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Site Notes
 */

@Document(collection = "siteNotes")
public class SiteNotes extends Note  {}

