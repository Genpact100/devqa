package com.ge.ren.notes.utils;

import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.support.DefaultConversionService;

import com.github.rutledgepaulv.rqe.conversions.StringToTypeConverter;
import com.github.rutledgepaulv.rqe.conversions.parsers.StringToInstantConverter;
import com.github.rutledgepaulv.rqe.conversions.parsers.StringToObjectBestEffortConverter;

public class QueryConvertionUtil implements StringToTypeConverter{

		  private ConversionService conversionService;
		  
		  @Override
		  public Object apply(String s, Class<?> aClass) {
		    return conversionService.convert(s, aClass);
		  }
		  @Override
		  public boolean supports(Class<?> clazz) {
		    return conversionService.canConvert(String.class, clazz);
		  }
		  
		  public QueryConvertionUtil() {
		    DefaultConversionService defaultConversionService = new DefaultConversionService();
		    defaultConversionService.addConverter(new StringToInstantConverter());
		    defaultConversionService.addConverter(new StringToObjectBestEffortConverter());
		    defaultConversionService.addConverter(new StringToDateConverter());
		    this.conversionService = defaultConversionService;
		  }
		  
		  public QueryConvertionUtil(ConversionService conversionService){
		    this.conversionService = conversionService;
		  }

		}
