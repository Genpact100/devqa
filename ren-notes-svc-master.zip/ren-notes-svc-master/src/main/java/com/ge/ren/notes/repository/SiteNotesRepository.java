package com.ge.ren.notes.repository;


import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.ge.ren.notes.model.SiteNotes;


public interface SiteNotesRepository extends MongoRepository<SiteNotes, String> {
	List<SiteNotes> findAll();
	List<SiteNotes> findByTenantId(String tenantId);
	SiteNotes save(SiteNotes Notes);
	
	Optional<SiteNotes> deleteByTenantIdAndId(String tenantId, String id);
	
    Page<SiteNotes> findByTenantId(String tenantId, Pageable pageRequest);

    Page<SiteNotes> findByTenantIdNot(String tenantId, Pageable pageRequest);

    Page<SiteNotes> findByTenantIdIn(List<String> tenantIds, Pageable pageRequest);

    Page<SiteNotes> findByTenantIdNotIn(List<String> tenantIds, Pageable pageRequest);

    @Query(value = "{ 'id' : ?0 }")
    Page<SiteNotes> findById(String id, Pageable pageRequest);
    @Query("{id : ?0}")
    Page<SiteNotes> findByIdNot(String id, Pageable pageRequest);
    @Query("{id : ?0}")
    Page<SiteNotes> findByIdIn(List<String> ids, Pageable pageRequest);
    Page<SiteNotes> findByIdNotIn(List<String> ids, Pageable pageRequest);
    @Query(value = "{'tenantId': ?0, 'id' : ?1 }")
    Page<SiteNotes> findByTenantIdAndId(String tenantID, String id, Pageable pageRequest);
    @Query(value = "{'tenantId': ?0, 'id' : ?1 }")
    Page<SiteNotes> findByTenantIdAndIdNot(String tenantId, String id, Pageable pageRequest);
    @Query(value = "{'tenantId': ?0,  'id' : { $in: ?1 }}")
    Page<SiteNotes> findByTenantIdAndIdIn(String tenantId, List<String> ids, Pageable pageRequest);
    @Query(value = "{'tenantId': ?0,  '_id' : { $ne: ?1 }}")
    Page<SiteNotes> findByTenantIdAndIdNotIn(String tenantId, List<String> ids, Pageable pageRequest);
    
    Page<SiteNotes> findByTenantIdAndDomainIdIn(String tenantId, List<String> domainIds, Pageable pageRequest);
}
