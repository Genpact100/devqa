package com.ge.ren.notes.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.UnsupportedEncodingException;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import static java.util.stream.Collectors.joining;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ObjectMapperUtils {
	private static final Logger log = LoggerFactory.getLogger(ObjectMapperUtils.class);
    private static ObjectMapper objectMapper = new ObjectMapper();

    public static String convertToUrlEncoded(Object obj) {
        Map<String, String> map = objectMapper.convertValue(obj, Map.class);
        log.debug("map: " + map.toString());
        return map.keySet().stream()
                .map(key -> {
                    try {
                    	String type = "String";
                        String value = null;

                        if (type.equals("String")) {
                            value = map.get(key);
                        }
                        log.debug("key > "+ key + " , value: " + value);
                        return value != null && value.length() > 0
                                ? key + "=" + URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
                                : null;
                    } catch (UnsupportedEncodingException e) {
                        log.error("0: "+ e.toString());
                        throw new UnsupportedOperationException(); 
                    } catch (Exception e) {
                        log.error("1: "+ e.toString());
                    }
					return null;
                })
                .filter(value -> value != null)
                .collect(joining("&"));
    }
}