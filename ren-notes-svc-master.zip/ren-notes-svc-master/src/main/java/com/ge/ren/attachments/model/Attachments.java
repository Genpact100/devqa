
package com.ge.ren.attachments.model;


import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.ge.ren.notes.model.Pagination;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"pagination",
    "attachments"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Attachments {
	@JsonProperty("pagination")
	public Pagination pagination;
    @JsonProperty("attachments")
    public List<Attachment> attachments;

}
