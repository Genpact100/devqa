package com.ge.ren.notes.exception;

public class ResourceNotValid extends ApiException {
 
	private static final long serialVersionUID = 864808673590786898L;

	public ResourceNotValid(String msg) {
        super("Resource Not Valid ", msg);
    }
}
