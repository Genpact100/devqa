package com.ge.ren.notes.config;


import javax.annotation.PostConstruct;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.mongo.embedded.EmbeddedMongoAutoConfiguration;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.data.mapping.context.MappingContext;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.index.IndexOperations;
import org.springframework.data.mongodb.core.index.MongoPersistentEntityIndexResolver;
import org.springframework.data.mongodb.core.mapping.BasicMongoPersistentEntity;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.data.mongodb.core.mapping.MongoPersistentEntity;
import org.springframework.data.mongodb.core.mapping.MongoPersistentProperty;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Configuration
public class MongoConfig {
    @Value("${truststore.pwd:un_set}")
        private String trustStorePwd;
    
    /**
	 * Changing MongoDbFactory to MongoDatabaseFactory, as in latest version of Spring MongoDbFactory is deprecated. 
	 */
        @Autowired
        private MongoDatabaseFactory factory;
        @Autowired
        private MappingContext<? extends MongoPersistentEntity<?>, MongoPersistentProperty> mappingContext;
        @Autowired
        private BeanFactory beanFactory;

        @PostConstruct
        public void setup() {
            System.setProperty("javax.net.ssl.trustStorePassword", this.trustStorePwd);
        }

        @Bean
        public DefaultMongoTypeMapper defaultMongoTypeMapper() {
            return new DefaultMongoTypeMapper(null);
        }

        @Bean
        public MappingMongoConverter mappingMongoConverter(@Autowired DefaultMongoTypeMapper defaultMongoTypeMapper) {
            MappingMongoConverter converter = new MappingMongoConverter(new DefaultDbRefResolver(this.factory), this.mappingContext);
            converter.setTypeMapper(defaultMongoTypeMapper);
            return converter;
        }

        @Bean
        public MongoTemplate mongoTemplate(@Autowired MappingMongoConverter mappingMongoConverter) {
            return new MongoTemplate(this.factory, mappingMongoConverter);
        }

        @EventListener({ApplicationReadyEvent.class})
        public void initIndicesAfterStartup() {
            log.info("Mongo InitIndicesAfterStartup init");
            long init = System.currentTimeMillis();
            MongoTemplate mongoTemplate = this.beanFactory.getBean(MongoTemplate.class);
            if (this.mappingContext instanceof MongoMappingContext) {
                MongoMappingContext mongoMappingContext = (MongoMappingContext)this.mappingContext;

                for (MongoPersistentEntity<?> mongoPersistentProperties : mongoMappingContext.getPersistentEntities()) {
                    Class<?> clazz = mongoPersistentProperties.getType();
                    if (clazz.isAnnotationPresent(Document.class)) {
                        MongoPersistentEntityIndexResolver resolver = new MongoPersistentEntityIndexResolver(mongoMappingContext);
                        IndexOperations indexOps = mongoTemplate.indexOps(clazz);
                        resolver.resolveIndexFor(clazz).forEach(indexOps::ensureIndex);
                    }
                }
            }

            log.info("Mongo InitIndicesAfterStartup take: {}ms", System.currentTimeMillis() - init);
        }
}
