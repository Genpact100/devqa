package com.ge.ren.notes.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
@AllArgsConstructor
public class NoteLookupException extends RuntimeException {
 
	private static final long serialVersionUID = -8960481224790189210L;
	private HttpStatus httpStatus;
    private String message;
}
