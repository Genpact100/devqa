package com.ge.ren.notes.exception;

public class AttributeNotFound extends ApiException {

	private static final long serialVersionUID = 470592173970691734L;
	public AttributeNotFound(String msg) {
        super("Attribute not found ", msg);
    }
}
