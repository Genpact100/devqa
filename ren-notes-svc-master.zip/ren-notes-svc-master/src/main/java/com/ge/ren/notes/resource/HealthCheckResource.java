package com.ge.ren.notes.resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ge.ren.notes.model.ApplicationHealth;

@RestController
@RequestMapping("/common/v1/notes")
public interface HealthCheckResource {
	
	@GetMapping("/healthcheck")
	public ApplicationHealth getHealthCheck();
	
	@GetMapping("/healthcheck/deep")
	public ApplicationHealth getHealthCheckDeep() throws JsonProcessingException;
}
