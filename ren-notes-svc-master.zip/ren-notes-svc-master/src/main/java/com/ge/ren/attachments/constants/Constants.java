package com.ge.ren.attachments.constants;

public interface Constants {
	
}
