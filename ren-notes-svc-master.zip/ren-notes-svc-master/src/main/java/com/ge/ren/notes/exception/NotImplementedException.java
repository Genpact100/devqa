package com.ge.ren.notes.exception;

public class NotImplementedException extends ApiException {
    public NotImplementedException(String msg) {
        super("Resource Not Found ", msg);
    }
}
