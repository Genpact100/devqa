package com.ge.ren.notes.exception;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Error
 */

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Error   {
	
  @JsonProperty("timestamp")
  private String timestamp;
	
  @JsonProperty("errorTitle")
  private String errorTitle;

  @JsonProperty("errorCode")
  private String errorCode;

  @JsonProperty("errorDescription")
  private String errorDescription;
  

}

