
package com.ge.ren.notes.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.ge.ren.notes.dto.Note;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "pagination",
    "notes"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GetNotes {

    @JsonProperty("pagination")
    public Pagination pagination;
    @JsonProperty("notes")
    public List<Note> notes = null;

}
