package com.ge.ren.notes.utils;

import com.fasterxml.jackson.databind.util.ISO8601DateFormat;
import com.fasterxml.jackson.databind.util.ISO8601Utils;
import com.ge.ren.notes.exception.ResourceNotValid;
import static com.ge.ren.notes.constants.Constants.*;
import java.sql.Timestamp;
import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.TimeZone;

import org.springframework.stereotype.Component;

@Component
@SuppressWarnings("deprecation")
public class DateFormatMS extends ISO8601DateFormat {

  private static final long serialVersionUID = 1L;
  // added to ISO8601DatFormat serializing milliseconds.
  //@Override
  //public StringBuffer format(Date date, StringBuffer toAppendTo, FieldPosition fieldPosition) {
  //  return toAppendTo.append(ISO8601Utils.format(date, true));
  //}

  public String getCurrentDateFormated() {
	  SimpleDateFormat sdf = new SimpleDateFormat(DATE_PATTERN);
	  sdf.setTimeZone(TimeZone.getTimeZone(UTC_TZ));
	  return sdf.format(new Date(System.currentTimeMillis()));
  }
  
  public Timestamp getcurrentTimestamp() {
	  return new Timestamp(System.currentTimeMillis() + TimeZone.getTimeZone(UTC_TZ).getOffset(System.currentTimeMillis()));
  }
  
  public Timestamp covertStringToTimestamp(String dateStr) {
	  return java.sql.Timestamp.valueOf(dateStr); 
  }
  public Timestamp covertToTimestamp(String dateStr){
	  if(dateStr.trim().length() == 10) {
		  dateStr = new StringBuilder(dateStr.trim()).append(TIME_PATTERN).toString();
	  }
	  return new java.sql.Timestamp(new Date(dateStr).getTime());
  }
  
  /*
   * get Date for Bucket name
   */
  public String getTodayDateString() {
	  SimpleDateFormat sdf = new SimpleDateFormat(BUCKET_DATE_PATTERN);
	  sdf.setTimeZone(TimeZone.getTimeZone(UTC_TZ));
	  return sdf.format(new Date(System.currentTimeMillis())).trim();
  }
  public String getFileNameDateString() {
	  SimpleDateFormat sdf = new SimpleDateFormat(FILE_DATE_PATTERN);
	  sdf.setTimeZone(TimeZone.getTimeZone(UTC_TZ));
	  return sdf.format(new Date(System.currentTimeMillis())).trim();
  }

  public long getcurrentUnixTimestamp() {
	  return Instant.now().toEpochMilli();
  }
  
}