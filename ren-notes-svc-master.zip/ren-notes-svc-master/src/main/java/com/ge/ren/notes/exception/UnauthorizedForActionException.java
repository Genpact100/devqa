package com.ge.ren.notes.exception;

public class UnauthorizedForActionException extends ApiException {
    
	private static final long serialVersionUID = 9876281715766455L;

    public UnauthorizedForActionException(String msg) {
        super("Site Error ", msg);
    }
}
