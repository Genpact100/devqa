package com.ge.ren.attachments.utils;


import java.io.File;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.GetAttachments;
import com.ge.ren.attachments.model.PostAttachment;
import com.ge.ren.notes.constants.ErrorConstants;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.ResourceNotValid;

import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.Pagination;
import com.ge.ren.notes.model.TaskNotes;
import com.ge.ren.notes.utils.DateFormatMS;
import com.ge.ren.notes.utils.ValidateUtil;

import static com.ge.ren.notes.constants.Constants.DOT;
import static com.ge.ren.notes.constants.Constants.MAX_FILE_SIZE;
import static com.ge.ren.notes.constants.Constants.NOTE_SIZE;
import static com.ge.ren.notes.constants.Constants.PATCH;
import static com.ge.ren.notes.constants.Constants.SLASH;
import static com.ge.ren.notes.constants.Constants.TITLE_SIZE;
import static com.ge.ren.notes.constants.Constants.VALID_DATE_BY;
import static com.ge.ren.notes.constants.Constants.TITLE;
import static com.ge.ren.notes.constants.Constants.ATTACHMENTS;
import static com.ge.ren.notes.constants.Constants.DESCRIPTION;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class Autils {
    @Autowired
    DateFormatMS dateFormat;
	
    @Value("${storage.type:s3aws}")
	private String storageType;
    
    
    @Value("${aws.bucket.prefix:TODO_add_bucket_to_properties}")
	private String bucket;

	@Value("${noteSize:2500}")
    private int descriptionSize = NOTE_SIZE;
    
    @Value("${titleSize:120}")
    private int titleSize = TITLE_SIZE;
    
    private List<String> ext = Arrays.asList("js", "sh","py");
    private String[] DOMAIN = {"asset","task","event","site","case"};
    /*
     * Validate for File Size
     */
	public boolean validateForFileSize(Optional<MultipartFile[]> files) {
		if(files.isPresent() && !files.isEmpty()) {
			int size = 0;
			for (MultipartFile multipartFile : files.get()) {
	            if ((size +=multipartFile.getSize()) > MAX_FILE_SIZE) {
	            	return false;
	            }
	        }
		}
		return true;
	}
	/*
	 * Validate for Path
	 */
	public boolean validatePathExists(String bucket) {
		File path = new File(bucket);
		if (!path.exists()) {
			log.debug("Folder has been created -> {}", bucket );
			path.mkdirs();
		}
		return true;
	}
	
	/*
	 * getTitleSizeChecked
	 * @param PostAttachment
	 * @return boolean
	 */
	public boolean getTitleSizeCheck(Object attachment, String type) {
		if(type.equalsIgnoreCase("post")) {
			if(((PostAttachment) attachment).getTitle().length() > titleSize) {
				throw new ResourceNotValid(ErrorConstants.VaidatedMessage.TITLE_SIZE_LIMIT.description() + titleSize);
			}
		}else if(((Attachment) attachment).getTitle().length() > titleSize)  {
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.TITLE_SIZE_LIMIT.description() + titleSize);
		}
		return true;
	}
	
	/*
	 * getDescriptionSizeChecked
	 * @param PostAttachment
	 * return boolean
	 */
	public boolean getDescriptionSizeCheck(Object attachment, String type) {
		if(type.equalsIgnoreCase("post")) {
			if(((PostAttachment) attachment).getDescription().length() > descriptionSize) {
				throw new ResourceNotValid(ErrorConstants.VaidatedMessage.NOTE_SIZE_LIMIT.description() + titleSize);
			}
		}else if(((Attachment) attachment).getDescription().length() > descriptionSize)  {
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.TITLE_SIZE_LIMIT.description() + titleSize);
		}
		return true;
	}
	
	/*
	 * Validate for File Type
	 */
	public void validateForFileType(MultipartFile mfile) throws JsonMappingException, JsonProcessingException{

    	String fileType = mfile.getOriginalFilename().substring(mfile.getOriginalFilename().lastIndexOf(DOT)+1);

		if (ext.parallelStream().filter(p -> p.contains(fileType)).collect(Collectors.toList()).size() > 0) {
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.FILE_TYPE_NOT_ALLOWED.description() + fileType);
		};
	}
	
	public Object removeDeletedField(Object object, String api, List<com.ge.ren.attachments.model.patch.Patch> at) throws JsonMappingException, JsonProcessingException{
 
		List<com.ge.ren.attachments.model.patch.Patch>	 list =	at.parallelStream().filter(p -> p.getOp().contains("remove")).collect(Collectors.toList());
		//Set<String> scopes = matchPermissions.stream().map(Permission::getScopes).flatMap(Set::stream).collect(Collectors.toSet());
		Set<String> op = at.stream().map(com.ge.ren.attachments.model.patch.Patch::getPath).collect(Collectors.toSet());  //flatMap(Set::stream). 


		Iterator<String> it = op.iterator(); 
		if(api.equalsIgnoreCase("attachment")) {
			Attachment updated = (Attachment)object;
			while(it.hasNext()) {
				switch(it.next()) {
				case "/description":
			        updated.setDescription(null);
					break;
				case "/title":
					updated.setTitle(null);
					break;
				case "/domainName":
					updated.setDomainName(null);
					break;
		        }	
			}
			return updated;
		}else {
			Note updatedn = (Note) object;
			while(it.hasNext()) {
				switch(it.next()) {
				case "/note":
			        updatedn.setNote(null);
					break;
				case "/title":
					updatedn.setTitle(null);
					break;
				case "/priority":
					updatedn.setPriority(null);
					break;
				case "/category":
					updatedn.setPriority(null);
					break;
				case "/status":
					updatedn.setStatus(null);
					break;
				case "/scope":
					updatedn.setScope(null);
					break;
		        }	
			}
			return updatedn;
		}
		
	}
	
	/*
	 * Compile Exception
	 */
    protected String getErrorDescription(String message, int status, String acode, String atype, String aid) {
     	return "AWSException, "
        		+ " Error Message:  " + message 
        		+ " Status Code:    " + status
        		+ " AWS Error Code: " + acode
        		+ " Error Type:     " + atype
        		+ " Request ID:     " + aid;
    }
    
    /*
     * Get Notes by Domain
     */
	public boolean getNotesByDomain(String domain) {
		if(!Arrays.asList(DOMAIN).contains(domain)) {
			throw new ResourceNotValid("The Domain is not Valid: " + domain);
		}
		return true;
	}    

	/*
	 * compile bucket path
	 * @param String
	 * @return String
	 */
    public String compileBucketPath(String domainName) {
		return "attachments/" + domainName + SLASH + dateFormat.getTodayDateString(); 
    }

    /*
     * Pagination
     * @param List<Attachment> 
 	 * @param NotesRequest
     * @return GetAttachments
     */
    public GetAttachments setPaginationMetadata(List<Attachment> attachments, NotesRequest request ) {
    	return new GetAttachments(
  							new Pagination(request.getPageIdx(), request.getCount(), (int)(Math.ceil((double)request.getCount()/request.getPageSize())), request.getPageSize()),
   								attachments);
    }
    
    public Attachment validatePatchRequest(Attachment attachment, MultipartFile[] multipartFiles, String type) throws JsonMappingException, JsonProcessingException{
		if(null == attachment.domainId){
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.DOMAINID_NOT_FOUND.description());
		}
		if(null == attachment.domainName){
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.DOMAINNAME_NOT_FOUND.description());
		}
		if( StringUtils.hasLength(attachment.getDescription()) && getDescriptionSizeCheck(attachment, PATCH)){ 
			attachment.setDescription(ValidateUtil.validateForSpecChars(attachment.getDescription(), DESCRIPTION));
			if( StringUtils.hasLength(attachment.getTitle()) && getTitleSizeCheck(attachment, PATCH)){
				attachment.setTitle(ValidateUtil.validateForSpecChars(attachment.getTitle(), TITLE));					
			}
		}else
		if( StringUtils.hasLength(attachment.getTitle()) && getTitleSizeCheck(attachment, PATCH)){
			attachment.setTitle(ValidateUtil.validateForSpecChars(attachment.getTitle(), TITLE));
		}else if(null == multipartFiles || multipartFiles[0].isEmpty()) {
			if(type.equalsIgnoreCase(PATCH)) {
				throw new AttributeNotFound(ErrorConstants.VaidatedMessage.ATTACHMENT_EMPTY_PATCH.description());
			}else {
				throw new AttributeNotFound(ErrorConstants.VaidatedMessage.ATTACHMENT_EMPTY_POST.description());
			}
		}
		return attachment;
	}
}
