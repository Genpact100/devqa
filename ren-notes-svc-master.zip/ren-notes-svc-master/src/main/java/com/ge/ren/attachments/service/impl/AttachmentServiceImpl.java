package com.ge.ren.attachments.service.impl;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static com.ge.ren.notes.constants.Constants.*;

import com.ge.ren.attachments.dto.NoteBase;
import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.attachments.model.Attachments;
import com.ge.ren.attachments.model.PostAttachment;
import com.ge.ren.attachments.service.AttachmentService;
import com.ge.ren.attachments.utils.AwsUploader;
import com.ge.ren.attachments.utils.FileUploader;
import com.ge.ren.attachments.utils.PatchHelper;
import com.ge.ren.attachments.utils.Autils;
import com.ge.ren.notes.constants.ErrorConstants;
import com.ge.ren.notes.constants.ErrorConstants.ErrorCodes;
import com.ge.ren.notes.constants.ErrorConstants.VaidatedMessage;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.Error;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.Pagination;
import com.ge.ren.notes.utils.ApiUtil;
import com.ge.ren.notes.utils.DateFormatMS;
import com.ge.ren.notes.utils.JacksonConfiguration;
import com.ge.ren.notes.utils.ValidateUtil;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.model.patch.Patch;
import com.mongodb.client.result.DeleteResult;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class AttachmentServiceImpl implements AttachmentService {


 	@Autowired
 	MongoTemplate mongoTemplate;
    @Autowired
    JacksonConfiguration jc;   
    
    @Autowired
    ApiUtil apiUtil;
    
    @Autowired
    Autils utils;
    
    @Autowired
    DateFormatMS dateFormat;
    
   
    @Autowired
    FileUploader fileUploader;
    
    @Autowired
    AwsUploader awsUploader;
    
    @Autowired
    ObjectMapper objectMapper;
    
    @Autowired
    PatchHelper patchHelper;
    
	@Value("${mongodb.search.limit:10}")
	private int searchLimit;
    
    @Value("${storage.type:s3aws}")
	private String storageType;
    
    @Value("${aws.bucket.prefix:attachments}")
	private String bucket;
    
    @Value("${aws.bucket.s3}")
    private String s3Bucket;
    
    @Value("${spring.profiles.active}")
    String activeProfile;
    private static final String HTTPS = "https://";    
    /*
     * Method Get Site Notes for all or by parameters
     * @method GetNotesRequest
     * @param NotesRequest
     * @return String
     */
	@Override
	public String processGetRequest(String domainName, String id, int pageIdx, int pageSize, String queryString, String filterString ) throws IOException {
		List<Attachment> ats = new ArrayList <>(); 
		Query query = new Query();
		if(null != queryString) {
			query = apiUtil.getCriteriaFromQueryParser(queryString, query);
		}
		if(null != id) {
			query.addCriteria(Criteria.where(ID).is(id)).fields().exclude(TIMESTAMPC).exclude(TIMESTAMPU);
			//query.addCriteria(Criteria.where("domainName").is(domainName));
			ats.addAll(Optional.of(mongoTemplate.find(query, Attachment.class)).get());
			ats = processUpdateLinks(id, ats, Attachment.class);
			return (!ats.isEmpty())? jc.getOMconfiguration(new ObjectMapper()).writeValueAsString(ats.get(0)): "{}";
		}
		int count = ((int) mongoTemplate.count(query, ATTACHMENTS));
		query.with(PageRequest.of(pageIdx, pageSize, org.springframework.data.domain.Sort.Direction.DESC, PAGE_SEARCH_SORT_KEY));
		if(null != filterString) {
			List<String> filters = Arrays.asList(filterString.split(SPLIT_RULE));
			final Query tQuery = query;
			filters.stream().forEach(filter -> { 
				tQuery.fields().include(filter);
			});
			query = tQuery;
		}else {
			query.fields().exclude(TIMESTAMPC).exclude(TIMESTAMPU);
		}
		ats.addAll(Optional.of(mongoTemplate.find(query, Attachment.class)).get());
		ats = processUpdateLinks(id, ats, Attachment.class);
		return  objectMapper.writeValueAsString(new Attachments(new Pagination(pageIdx, count, (int)(Math.ceil((double)count/pageSize)), pageSize), ats));
	}

	@Override
	public String processGetRequest( NotesRequest request ) throws IOException {
		List<Attachment> ats = new ArrayList <>(); 
		Query query = new Query();
		query.addCriteria(Criteria.where(TENANTID).is(request.getTenantId()));
		if(null != request.getQuery()) {
			query = apiUtil.getCriteriaFromQueryParser(request.getQuery(), query);
		}
		if(null != request.getId()) {
			query.addCriteria(Criteria.where(ID).is(request.getId())).fields().exclude(TIMESTAMPC).exclude(TIMESTAMPU);
			//query.addCriteria(Criteria.where("domainName").is(domainName));
			ats.addAll(Optional.of(mongoTemplate.find(query, Attachment.class)).get());
			ats = processUpdateLinks(request.getId(), ats, Attachment.class);
			return (!ats.isEmpty())? objectMapper.writeValueAsString(ats.get(0)): "{}";
		}
		int count = ((int) mongoTemplate.count(query, ATTACHMENTS));
		query.with(PageRequest.of(request.getPageIdx(), request.getPageSize(), org.springframework.data.domain.Sort.Direction.DESC, PAGE_SEARCH_SORT_KEY));
		if(null != request.getFilter()) {
			List<String> filters = Arrays.asList(request.getFilter().split(SPLIT_RULE));
			final Query tQuery = query;
			filters.stream().forEach(filter -> { 
				tQuery.fields().include(filter);
			});
			query = tQuery;
		}else {
			query.fields().exclude(TIMESTAMPC).exclude(TIMESTAMPU);
		}
		ats.addAll(Optional.of(mongoTemplate.find(query, Attachment.class)).get());
		ats = processUpdateLinks(request.getId(), ats, Attachment.class);
		return  objectMapper.writeValueAsString(new Attachments(new Pagination(request.getPageIdx(), count, (int)(Math.ceil((double)count/request.getPageSize())), request.getPageSize()), ats));
	}
	/*
	 * Process POST Attachment request
	 * @param NotesRequest request
	 * @return ResponseEntity<Object>
	 */
	@Override
	public ResponseEntity<Object> processPostRequest(NotesRequest request , Optional<MultipartFile[]> multipartFiles) throws JsonParseException, IOException{ 
		log.debug("Date- > {} " , dateFormat.getCurrentDateFormated());
		try {
			PostAttachment attachment = ((PostAttachment) request.getBody());
			ValidateUtil.validateJsonString(((PostAttachment)request.getBody()).toString());
			attachment = validatePostRequest(attachment,  (multipartFiles.isPresent() && !multipartFiles.isEmpty()? multipartFiles.get(): null), POST);
			//Save Attachments into bucket
			Attachment note = new Attachment(null,	attachment.getDomainName(),
					attachment.getDomainId(),
					request.getTenantId(),
					attachment.getTitle(),
					attachment.getDescription(),
					dateFormat.getCurrentDateFormated(),
					dateFormat.getCurrentDateFormated(),
					request.getCreatedBy(),
					request.getCreatedBy(),
					new Timestamp(System.currentTimeMillis()),
					new Timestamp(System.currentTimeMillis()),
					null);
			if(multipartFiles.isPresent() || !multipartFiles.isEmpty()) {
				note.setAttachments(fileUploader.uploadFiles(((PostAttachment)request.getBody()).getDomainName(), multipartFiles.get()));
			}
			note = mongoTemplate.save(note, ATTACHMENTS);
			note.setTimestampc(null);
			note.setTimestampu(null);
			//log.debug("NOTE Saved ->> {}" , note);
			return new ResponseEntity<> (jc.getOMconfiguration(new ObjectMapper()).writeValueAsString(note), HttpStatus.CREATED);
		} catch (RuntimeException e) {
			log.error("Exception processPostRequest: {} ",e);
			throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), e.getMessage());
		}
	}
	
	/*
	 * Delete note
	 * @param NotesRequest request
	 * @param Class<T> entityClass
	 * return <T> ResponseEntity<Object>
	 */
	@Override
	public <T> ResponseEntity<Object> processDeleteRequest(NotesRequest request, Class<T> entityClass)  {

		log.info("Date- > {} " , dateFormat.getCurrentDateFormated());
		Query query = new Query();
		Path path = null;
		try {
			query.addCriteria(Criteria.where(ID).is(request.getId())).fields().include(ID,ATTACHMENTS);
			Attachment attachment = (Attachment) mongoTemplate.findOne(query, entityClass, ATTACHMENTS);
			if(null == attachment) {
				return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.CODE_404.errordescription(), VaidatedMessage.NOT_FOUND.description() + request.getId()), HttpStatus.NOT_FOUND);
			}
			log.debug(">>>> BEFORE delete -> {}", attachment);
			if(null != attachment.getAttachments()) {
				//Delete attached files
				Iterator<AttachmentData> it = attachment.getAttachments().iterator();
				while(it.hasNext()) {
					AttachmentData at =  it.next();
					if(!storageType.equalsIgnoreCase(S3BUCKET)) { // save to fileSystem
						path = Paths.get( at.getFile());
					    Files.delete( path);
					}else { 
						awsUploader.removeS3Object(at.getFile().substring((AWS_PATH1+activeProfile+AWS_PATH2).length()));
					}
				}
				DeleteResult at = mongoTemplate.remove(query, entityClass, ATTACHMENTS) ;
				log.debug("Attachment marked as DELETED ->> {}" , at.wasAcknowledged());
			}
		} catch (NoSuchFileException x) {
		    log.error( NO_FILE_EXCEPTION + " {}", path);
		    throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), NO_FILE_EXCEPTION + x.getMessage());
		}catch (RuntimeException | IOException x) {
			log.error(PERMISSION_EXCEPTION + " {}", x);
			throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), PERMISSION_EXCEPTION + x.getMessage());
		}

		//log.debug("after delete ....");
		return new ResponseEntity<> (request.getId(), HttpStatus.OK);
	}
	
	/* 
	 * processPatchRequest
	 * @param NotesRequest request
	 * @param Class<T> entityClass
	 * @return <T> ResponseEntity<Object>
	 */
	@Override
	public <T> ResponseEntity<Object> processPatchRequest(NotesRequest request, Class<T> entityClass, Optional<MultipartFile[]> files) throws ApiException, JsonParseException, IOException {

		log.debug("Date- > {} " , dateFormat.getCurrentDateFormated());
		Map<String, Attachment> patch = new HashMap<>();
		Query query = new Query();
		query.addCriteria(Criteria.where(ID).is(request.getId())).fields().include(DOMAINNAME).include(DOMAIN_ID).include(TENANTID)
			 .include(TITLE).include(DESCRIPTION).include(CREATED_BY).include(UPDATEDBY).include(UPDATEDATE).include(ATTACHMENTS);
		ValidateUtil.validateJsonString( objectMapper.writeValueAsString(((JsonPatch)request.getBody())));
		List<AttachmentData> attachments = new ArrayList<>(); 
		Path path = null;
		Update update = new Update();
		Attachment updated = new Attachment();
		try {
			Attachment attachment =  (Attachment) mongoTemplate.findOne(query, entityClass, ATTACHMENTS);
			patch.put(ORIGINAL, attachment);
			log.debug("attachment Found: {}", attachment);
			if(null == attachment) {
				return new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.CODE_404.errordescription(), VaidatedMessage.NOT_FOUND.description() + request.getId()), HttpStatus.NOT_FOUND);
			}else if(null != attachment.attachments){
				attachments.addAll(attachment.getAttachments());
			}
			if(null != request.getBody()) {
				JsonPatch jsonPatch =  (JsonPatch) request.getBody();
				List<Patch> patchList = jsonPatch.getPatch();
				List<com.ge.ren.attachments.model.patch.Attachment> attachmentList = null;
				if(null != patchList) {
					updated =  patchHelper.applyPatch(attachment, objectMapper.writeValueAsString(patchList) );
					updated = validatePatchRequest(updated,  (files.isPresent() && !files.isEmpty()? files.get(): null), PATCH);
				} 
				if (null != jsonPatch.getAttachments()){
					attachmentList = jsonPatch.getAttachments();
					Iterator <com.ge.ren.attachments.model.patch.Attachment> it = attachmentList.iterator(); 
					while(it.hasNext()) {
						com.ge.ren.attachments.model.patch.Attachment atmt = it.next();
						if(!storageType.equalsIgnoreCase(S3BUCKET)) { // save to fileSystem
							log.debug("In Attachments PATCH file to delete -> {}", atmt.getPath());
							path = Paths.get(atmt.getPath().substring((AWS_PATH1+activeProfile+AWS_PATH2).length()));
							Files.delete(path);
						}else {
							log.debug("In PATCH aws delete file -> {}", atmt.getPath());
							awsUploader.removeS3Object(atmt.getPath().substring((AWS_PATH1+activeProfile+AWS_PATH2).length()));
						}
						List<AttachmentData> list = attachments.parallelStream().filter(p -> p.getFile().contains(atmt.getPath())).collect(Collectors.toList());
						log.debug("Attachment to remove ->>>> {}  >>>> {}", list.size()  , list);
						if(list.size() > 0) { 
							attachments.removeAll(list); 
						}
					}
				}
			}
			if(files.isPresent() && !files.isEmpty()) {
				attachments.addAll(fileUploader.uploadFiles(attachment.getDomainName(), files.get()));
			}	
			updated.setAttachments(attachments);
			updated.setUpdatedBy(request.getCreatedBy());
			update = validateAttachmentFields(updated);
			update.set(ATTACHMENTS, updated.getAttachments());

			mongoTemplate.findAndModify(query, update, entityClass, ATTACHMENTS);
			patch.put("updated", updated);						
			log.debug("NOTE patched ->> {}" , patch);
			return new ResponseEntity<> (jc.getOMconfiguration(new ObjectMapper()).writeValueAsString(patch) , HttpStatus.OK);
		} catch (NoSuchFileException x) {
		    log.error( NO_FILE_EXCEPTION + "{}", path);
		    throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), NO_FILE_EXCEPTION + x.getMessage());
		}catch (RuntimeException | IOException x) {
		    // File permission problems ...
			log.error(PERMISSION_EXCEPTION + " {}", x);
			throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(),PERMISSION_EXCEPTION + x.getMessage());
		} catch (Exception e) {
			log.error("Exception processPatchRequest: {} ",e);
			throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), e.getMessage());
		}
	}


	/*
	 *  Validate for Attachments
	 *  
	 */
	public PostAttachment validatePostRequest(PostAttachment attachment, MultipartFile[] multipartFiles, String type) throws JsonMappingException, JsonProcessingException{
		if(null == attachment.domainId){
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.DOMAINID_NOT_FOUND.description());
		}
		if(null == attachment.domainName){
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.DOMAINNAME_NOT_FOUND.description());
		}

		if( StringUtils.hasLength(attachment.getDescription()) && utils.getDescriptionSizeCheck(attachment, POST)){ 
			attachment.setDescription(ValidateUtil.validateForSpecChars(attachment.getDescription(), DESCRIPTION));
			if( StringUtils.hasLength(attachment.getTitle()) && utils.getTitleSizeCheck(attachment, POST)){
				attachment.setTitle(ValidateUtil.validateForSpecChars(attachment.getTitle(), TITLE));					
			}
		}else
		if( StringUtils.hasLength(attachment.getTitle()) && utils.getTitleSizeCheck(attachment, POST)){
			attachment.setTitle(ValidateUtil.validateForSpecChars(attachment.getTitle(), "title"));
		}else if(null == multipartFiles || multipartFiles[0].isEmpty()) {
			if(type.equalsIgnoreCase(PATCH)) {
				throw new AttributeNotFound(ErrorConstants.VaidatedMessage.ATTACHMENT_EMPTY_PATCH.description());
			}else {
				throw new AttributeNotFound(ErrorConstants.VaidatedMessage.ATTACHMENT_EMPTY_POST.description());
			}
		}
		return attachment;
	}
	
	public Attachment validatePatchRequest(Attachment attachment, MultipartFile[] multipartFiles, String type) throws JsonMappingException, JsonProcessingException{
		if(null == attachment.domainId){
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.DOMAINID_NOT_FOUND.description());
		}
		if(null == attachment.domainName){
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.DOMAINNAME_NOT_FOUND.description());
		}

		if( StringUtils.hasLength(attachment.getDescription()) && utils.getDescriptionSizeCheck(attachment, PATCH)){ 
			attachment.setDescription(ValidateUtil.validateForSpecChars(attachment.getDescription(), DESCRIPTION));
			if( StringUtils.hasLength(attachment.getTitle()) && utils.getTitleSizeCheck(attachment, PATCH)){
				attachment.setTitle(ValidateUtil.validateForSpecChars(attachment.getTitle(), TITLE));					
			}
		}else
		if( StringUtils.hasLength(attachment.getTitle()) && utils.getTitleSizeCheck(attachment, PATCH)){
			attachment.setTitle(ValidateUtil.validateForSpecChars(attachment.getTitle(), "title"));
		}else if(null == multipartFiles || multipartFiles[0].isEmpty()) {
			if(type.equalsIgnoreCase(PATCH)) {
				throw new AttributeNotFound(ErrorConstants.VaidatedMessage.ATTACHMENT_EMPTY_PATCH.description());
			}else {
				throw new AttributeNotFound(ErrorConstants.VaidatedMessage.ATTACHMENT_EMPTY_POST.description());
			}
		}
		return attachment;
	}
	
	public Update validateAttachmentFields(Attachment request) {
		Update update = new Update();
		if(null != request.getTitle()) {
			update.set(TITLE, request.getTitle());
		}
		if(null != request.getDescription()) {
			update.set(DESCRIPTION, request.getDescription());
		}
		update.set(UPDATEDATE, dateFormat.getCurrentDateFormated())
			  .set(TIMESTAMPU, dateFormat.getcurrentTimestamp())
			  .set(UPDATEDBY, request.getCreatedBy())
			  .set(DOMAINNAME, request.getDomainName());
		return update;
	}

	/*
	 * 
	 */
	public Update validateNewFields(NoteBase note) {
		Update update = new Update();
		if(null != note.getNoteTitle()) {
			update.set("newTitle", note.getNoteTitle());
		}
		if(null != note.getNote()) {
			update.set("newNote", note.getNote());
		}
		if(null !=  note.getNotePriority()) {
			update.set("newPriority", note.getNotePriority());	
		}
		if(null != note.getNoteCategory()){
			update.set("newCategory", note.getNoteCategory());
		}
		if(null != note.getNoteScope()) {
			update.set("newScope", note.getNoteScope());
		}
		if(null != note.getNoteStatus()){
			update.set("newStatus", note.getNoteStatus());
		}
		if(null != note.getNoteValidDateBy()){
			update.set(VALID_DATE_BY, note.getNoteValidDateBy());
		}
		update.set("updateDate", dateFormat.getCurrentDateFormated());
		update.set(TIMESTAMPU, dateFormat.getcurrentTimestamp());				
		return update;
	}

	/* 
	 * processPatchRequest
	 * @param NotesRequest request
	 * @param Class<T> entityClass
	 * @return <T> ResponseEntity<Object>
	 */
	//@Scheduled(fixedRateString  = "${ren.scheduler.rate:PT24H}")
	@Override
	public <T> List<Attachment> processUpdateLinks(String id, List<Attachment> attachments, Class<T> entityClass) {
		log.debug("Process update links started - > {} " , attachments);
		Query query = new Query(); query.addCriteria(Criteria.where(ID).is(id)).fields().include(DOMAINNAME).include(DOMAIN_ID).include(TENANTID).include(TITLE).include(DESCRIPTION).include(CREATED_BY).include(UPDATEDBY).include(UPDATEDATE).include(ATTACHMENTS);
		Update update = new Update();
		try {
			Iterator<Attachment> it = attachments.iterator(); boolean updated = false;
			while(it.hasNext()) {
				Attachment at = it.next();
				if (null != at.attachments) {
					log.debug("attachments Found: {}", at.attachments); List<AttachmentData> atsNew = new ArrayList<>(); List<AttachmentData> ats = at.getAttachments();	List<AttachmentData> atsOld = new ArrayList<>();
					Iterator <AttachmentData> itr = ats.iterator();
					while(itr.hasNext()) {
						AttachmentData ad = itr.next(); String key = ad.getFile();
						if(key.contains("?")) {
							String dateStr = key.substring(key.indexOf("X-Amz-Date=")+11, key.indexOf("X-Amz-Date=") + 19); SimpleDateFormat formatter = new SimpleDateFormat(AWS_DATE_PATTERN); Date date = formatter.parse(dateStr); Timestamp ts = new java.sql.Timestamp(date.getTime());
							log.debug("ts Before Current -> {} ", ts.before( new Date((Instant.now().toEpochMilli() - (1000*60*60)*8))) );
							if((ts.after( new Date((Instant.now().toEpochMilli() - (1000*60*60)*8)))) || ts.before( new Date((Instant.now().toEpochMilli())))) {
								key = key.substring(key.indexOf(".com/")+5, key.indexOf("?")); log.debug("bucket + key -> {} ", bucket+key ); URL url = fileUploader.updateLinks(bucket, key);
								atsNew.add(new AttachmentData(HTTPS + url.getHost() + url.getFile(), ad.getContentType(), ad.getFileName()));	atsOld.add(ad); 
							}
						}
					}
					if(!atsNew.isEmpty()) {	ats.removeAll(atsOld); ats.addAll(atsNew); update = validateAttachmentFields(at); update.set(ATTACHMENTS, ats); update.set(UPDATEDBY, PRESIGNED); updated = true;
						log.debug("Links updated ->> {}" , update);
					}
				}
				if(updated) { mongoTemplate.findAndModify(query, update, entityClass, ATTACHMENTS);}
			}	
			
			return attachments;
		} catch (Exception e) {
			log.error("Exception processUpdateLinks: {} ",e);
			throw new ApiException(ErrorCodes.EXCEPTION_ERROR_500.toString(), e.getMessage());
		}
	}

}
