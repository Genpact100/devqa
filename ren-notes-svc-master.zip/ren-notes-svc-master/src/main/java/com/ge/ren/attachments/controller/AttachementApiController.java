package com.ge.ren.attachments.controller;

import io.swagger.annotations.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.attachments.model.PostAttachment;
import com.ge.ren.attachments.service.AttachmentService;
import com.ge.ren.attachments.utils.Autils;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.constants.DomainResources;
import com.ge.ren.notes.exception.Error;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.SiteNotes;
import com.ge.ren.notes.utils.ApiUtil;
import com.ge.ren.attachments.model.patch.JsonPatch;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import static com.ge.ren.notes.constants.Constants.MAX_FILE_SIZE;
import static com.ge.ren.notes.constants.Constants.SIZE_NOT_ALLOWED;

import java.io.IOException;
import java.util.Optional;

@Validated
@Api(value = "controller", description = "Attachement API controller")
@Controller
@RequestMapping("${service.basePath:/common/v1}")
public class AttachementApiController {
	
    private final static String EMPTY_JSON_RESPONSE = "{}"; 
	@Autowired
    AttachmentService service;
	
   
    @Value("${pageNum:0}")
    private int pageNum;

    @Value("${pageSize:100}")
    private int pageSizeDef;
   
    @Autowired
    ApiUtil apiUtil;
    
    @Autowired
    Autils utils;

    @Autowired
    private RequestInterceptor requestInterceptor;

    //
    @Value("${tenantId:geservdrZp}")
	private String tenantId;
	
    @ApiOperation(value = "Create a Attachment for a domain", nickname = "apiV1AttachmentPost", notes = "", response = Object.class, tags={ "Attachment Service" })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "Created", response = Object.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 500, message = "Internal Server Error", response = Error.class),
        @ApiResponse(code = 404, message = "Not Found", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 409, message = "Conflict", response = Error.class) })
    @RequestMapping(value = "/attachments",
        produces = { "application/json" },
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE },
        method = RequestMethod.POST)
     ResponseEntity<Object> apiV1AttachmentPost(
    		 @ApiParam(value = "" ,required=false ) @RequestPart("json")  @Valid  Optional<PostAttachment> postAttachment,
    		 @RequestPart("file") Optional<MultipartFile[]> files ) throws JsonParseException, IOException { 
				if(! utils.validateForFileSize( files)) { 	throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE); }
				return service.processPostRequest(new NotesRequest(null, null, apiUtil.retrieveTenantId(requestInterceptor), (postAttachment.isPresent())? postAttachment.get(): null, "attachments", 	apiUtil.retrieveUserName(requestInterceptor)), files);
    }
 
    //
    @ApiOperation(value = "Get Notes for all Sites", nickname = "apiV1NotesSitesGet", notes = "Get Notes for all sites", response = Object.class, responseContainer = "List", 
    		tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Object.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/attachments",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
     ResponseEntity<Object> apiV1AttachmentsSitesGet(
	    		@RequestParam Optional<String> filter,
	            @RequestParam Optional<Integer> pageIdx,
	            @RequestParam Optional<Integer> pageSize,
	            @RequestParam Optional<String> domainName,
	            @RequestParam Optional<String> query,
	            HttpServletResponse res) throws  IOException{
		NotesRequest noteRequest = new NotesRequest();
    	noteRequest.setId(null);
    	noteRequest.setDomainIds((domainName.isPresent())? domainName.get(): null); 
    	noteRequest.setTenantId(apiUtil.retrieveTenantId(requestInterceptor));
    	noteRequest.setFilter(filter.isPresent()? filter.get(): null);
    	noteRequest.setPageIdx(pageIdx.isPresent()? pageIdx.get(): pageNum);
    	noteRequest.setPageSize(pageSize.isPresent()? pageSize.get(): pageSizeDef); 
    	noteRequest.setQuery(query.isPresent()? query.get(): null);		
    	String response = service.processGetRequest(noteRequest); 
        return (response.length() > 2 )? (
        		new ResponseEntity<>(response, HttpStatus.OK)) : 
        			(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT));
    }
    


    @ApiOperation(value = "Get Attachment for a Note", nickname = "apiV1AttachmentIdGet", notes = "", response = Object.class, tags={ "Attachement Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = SiteNotes.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 404, message = "Not Found", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/attachments/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
     ResponseEntity<Object> apiV1AttachmentIdGet(
    		@ApiParam(value = "",required=true) @PathVariable("id") String id, 
    		@RequestParam Optional<String> filter,
    		@RequestParam Optional<Integer> pageIdx,
    		@RequestParam Optional<Integer> pageSize,
    		@RequestParam Optional<String> query,
    		@RequestParam Optional<String> domainName
    		) throws  IOException{
		NotesRequest noteRequest = new NotesRequest();
    	noteRequest.setDomainIds((domainName.isPresent())? domainName.get(): null); 
    	noteRequest.setId(id);
    	noteRequest.setTenantId(apiUtil.retrieveTenantId(requestInterceptor));
    	noteRequest.setFilter(filter.isPresent()? filter.get(): null);
    	noteRequest.setPageIdx(pageIdx.isPresent()? pageIdx.get(): pageNum);
    	noteRequest.setPageSize(pageSize.isPresent()? pageSize.get(): pageSizeDef); 
    	noteRequest.setQuery(query.isPresent()? query.get(): null);		
    	String response = service.processGetRequest(noteRequest); 
        return (response.length() > 2 )? 
                		(new ResponseEntity<>(response, HttpStatus.OK)) : 
                			(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT)); 
    }
    
    @ApiOperation(value = "Delete  Attachment for a domain", nickname = "apiV1AttachmentIdDelete", notes = "", tags={ "Attachment Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 400, message = "Bad Request",  response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/attachments/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.DELETE)
     ResponseEntity<Object> apiV1AttachmentIdDelete (
    		 @ApiParam(value = "The id parameter to constrain the results. See **Usage Instructions** for more detail.",required=true) 
    		 @PathVariable("id") String id) throws Exception{
		return service.processDeleteRequest(new NotesRequest(null,	null, apiUtil.retrieveTenantId(requestInterceptor), null, id, apiUtil.retrieveUserName(requestInterceptor)), Attachment.class);

    }

    @ApiOperation(value = "Update Attachment for a domain", nickname = "apiV1AttachmentIdPatch", notes = "", response = Object.class, tags={ "Attachment Service" })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Object.class),
        @ApiResponse(code = 204, message = "No Content"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class),
        @ApiResponse(code = 500, message = "Internal Server Error", response = Error.class)})
    @RequestMapping(value = "/attachments/{id}",
        produces = { "application/json" }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json" },
        method = RequestMethod.PATCH)
     ResponseEntity<Object> apiV1AttachmentIdPatch(
    		 @ApiParam(value = "The siteId parameter to constrain the results. See **Usage Instructions** for more detail.",required=true) 
    		 @PathVariable("id") String id,
    		 @ApiParam(value = "" , required=false )  @Valid @RequestPart("json")  Optional<JsonPatch> patchAttachments,
    		 @RequestPart("file") Optional<MultipartFile[]> files) throws IOException {
		if(! utils.validateForFileSize( files)) { 	throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE);	}
		return service.processPatchRequest(new NotesRequest(null, null, apiUtil.retrieveTenantId(requestInterceptor), (patchAttachments.isPresent())? patchAttachments.get(): null, id, apiUtil.retrieveUserName(requestInterceptor)), 	Attachment.class, files);
	}
}
