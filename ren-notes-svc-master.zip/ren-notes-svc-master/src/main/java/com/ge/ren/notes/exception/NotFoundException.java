package com.ge.ren.notes.exception;

public class NotFoundException extends ApiException {
 
	private static final long serialVersionUID = -8263778360282246869L;

	public NotFoundException(String msg) {
        super("Resource Not Found ", msg);
    }
}
