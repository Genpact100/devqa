package com.ge.ren.attachments.dto;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ge.ren.attachments.model.AttachmentData;

@Document(collection = "attachments")
public class Attachment { //extends AttachmentBase {


    @JsonProperty("id")
    public String id;
    @JsonProperty("domainName")
    public String domainName;
    @JsonProperty("domainId")
    public String domainId;
    @JsonProperty("tenantId")
    public String tenantId;
    @JsonProperty("title")
    public String title;
    @JsonProperty("description")
    public String description;
    @JsonProperty("creationDate")
    public String creationDate;
    @JsonProperty("updateDate")
    public String updateDate;
    @JsonProperty("createdBy")
    public String createdBy;
    @JsonProperty("updatedBy")
    public String updatedBy;
    @JsonProperty("timestampc")
    private Timestamp timestampc;
    @JsonProperty("timestampu")
    private Timestamp timestampu;
    @JsonProperty("attachments")
    public List<AttachmentData> attachments;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public String getDomainId() {
		return domainId;
	}
	public void setDomainId(String domainId) {
		this.domainId = domainId;
	}
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Timestamp getTimestampc() {
		return timestampc;
	}
	public void setTimestampc(Timestamp timestampc) {
		this.timestampc = timestampc;
	}
	public Timestamp getTimestampu() {
		return timestampu;
	}
	public void setTimestampu(Timestamp timestampu) {
		this.timestampu = timestampu;
	}
	public List<AttachmentData> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<AttachmentData> attachments) {
		this.attachments = attachments;
	}
	public Attachment() {
		super();
	}
	public Attachment(String id, String domainName, String domainId, String tenantId, String title, String description,
			String creationDate, String updateDate, String createdBy, String updatedBy, Timestamp timestampc,
			Timestamp timestampu, List<AttachmentData> attachments) {
		super();
		this.id = id;
		this.domainName = domainName;
		this.domainId = domainId;
		this.tenantId = tenantId;
		this.title = title;
		this.description = description;
		this.creationDate = creationDate;
		this.updateDate = updateDate;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.timestampc = timestampc;
		this.timestampu = timestampu;
		this.attachments = attachments;
	}
}
