package com.ge.ren.notes.controller;

import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.ge.ren.attachments.model.patch.JsonPatch;
import com.ge.ren.attachments.utils.Autils;
import com.ge.ren.common.keycloak.intercept.RequestInterceptor;
import com.ge.ren.notes.constants.Constants;
import com.ge.ren.notes.constants.DomainResources;
import com.ge.ren.notes.exception.Error;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.AssetNotes;
import com.ge.ren.notes.model.CaseNotes;
import com.ge.ren.notes.model.EventNotes;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.InlineResponse200;
import com.ge.ren.notes.model.SiteNotes;
import com.ge.ren.notes.model.TaskNotes;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.service.NotesService;
import com.ge.ren.notes.utils.ApiUtil;

import static com.ge.ren.notes.constants.Constants.MAX_FILE_SIZE;
import static com.ge.ren.notes.constants.Constants.SIZE_NOT_ALLOWED;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import java.io.IOException;
import java.text.ParseException;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Slf4j
@Validated
//@Api(value = "controller", description = "the Notes API controller")
@Controller
@RequestMapping("${service.basePath:/common/v1}")
public class NotesApiController {

    private final static String EMPTY_JSON_RESPONSE = "{}"; 
	@Autowired
    NotesService service;
	
    
    @Value("${pageNum:0}")
    private int pageNum;

    @Value("${pageSize:100}")
    private int pageSizeDef;
   
    @Autowired
    ApiUtil apiUtil;

    @Autowired
    Autils utils;
    
    @Autowired
    private RequestInterceptor requestInterceptor;
   
    @ApiOperation(value = "Get Notes for all Sites", nickname = "apiV1NotesSitesGet", notes = "Get Notes for all sites", response = Object.class, responseContainer = "List", 
    		tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Object.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/site-notes",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
     ResponseEntity<Object> apiV1NotesSitesGet(
	    		@RequestParam Optional<String> filter,
	            @RequestParam Optional<Integer> pageIdx,
	            @RequestParam Optional<Integer> pageSize,
	            @RequestParam Optional<String> domainId,
	            @RequestParam Optional<String> createdBy,
	            @RequestParam Optional<String> updatedBy,
	            @RequestParam Optional<String> creationDate,
	            @RequestParam Optional<String> updateDate,
	            @RequestParam Optional<String> category,
	            @RequestParam Optional<String> query,
	            HttpServletResponse res) throws  IOException{    	
    	log.info("getAttributeScopes -> "+requestInterceptor.getAttributeScopes());
    	log.info("getUserCapabilities -> "+requestInterceptor.getUserCapabilities());
    	log.info("getUserRoles -> "+requestInterceptor.getUserRoles());
    	NotesRequest noteRequest = new NotesRequest();
		noteRequest.setDomain(DomainResources.siteNotes.toString()); 
		noteRequest.setDomainIds((domainId.isPresent())? domainId.get(): null);
		noteRequest.setTenantId(apiUtil.retrieveTenantId(requestInterceptor));
		noteRequest.setFilter(filter.isPresent()? filter.get(): null);
		noteRequest.setPageIdx(pageIdx.isPresent()? pageIdx.get(): pageNum);
		noteRequest.setPageSize(pageSize.isPresent()? pageSize.get(): pageSizeDef);
		noteRequest.setBody(updatedBy.isPresent()? updatedBy.get(): null);
		noteRequest.setCreatedBy(apiUtil.retrieveUserName(requestInterceptor));
		noteRequest.setCreationDate(creationDate.isPresent()? creationDate.get(): null);
		noteRequest.setUpdateDate(updateDate.isPresent()? updateDate.get(): null);
		noteRequest.setCategory(category.isPresent()? category.get(): null);
		noteRequest.setQuery(query.isPresent()? query.get(): null);		
		String response = service.processGetRequest(noteRequest); 
    	return (response.length() > 2 )? (new ResponseEntity<>(response, HttpStatus.OK)) : (new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT));
    }

    @ApiOperation(value = "Get Notes for a Site", nickname = "apiV1NotesSitesIdGet", notes = "", response = Object.class, tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Object.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 404, message = "Not Found", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/site-notes/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
     ResponseEntity<Object> apiV1NotesSitesIdGet(
    		@ApiParam(value = "",required=true) @PathVariable("id") String id, 
    		@RequestParam Optional<String> filter,
    		@RequestParam Optional<Integer> pageIdx,
    		@RequestParam Optional<Integer> pageSize,
    		@RequestParam Optional<String> domainId)  throws  IOException{
  		String response = service.processGetRequest(
  				new NotesRequest(DomainResources.siteNotes.toString(), 
  						(domainId.isPresent()? domainId.get(): null), 
  						apiUtil.retrieveTenantId(requestInterceptor),
  						filter, 
  						id,	
  						apiUtil.retrieveUserName(requestInterceptor)));
      	return (response.length() > 2 )? 
      			(new ResponseEntity<>(response, HttpStatus.OK)) : 
      				(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT));//(new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.CODE_404.errordescription(), VaidatedMessage.NOT_FOUND.description() + id), HttpStatus.NOT_FOUND));
    }
    
    @ApiOperation(value = "Delete  Note for a Site", nickname = "apiV1NotesSitesIdDelete", notes = "", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/site-notes/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.DELETE)
     ResponseEntity<?> apiV1NotesSitesIdDelete (
    		 @ApiParam(value = "The siteId parameter to constrain the results. See **Usage Instructions** for more detail.",required=true) @PathVariable("id") String id) throws Exception{

		return (service.processDeleteRequest(new NotesRequest(DomainResources.siteNotes.toString(), null, apiUtil.retrieveTenantId(requestInterceptor), null, id, apiUtil.retrieveUserName(requestInterceptor)), SiteNotes.class));
    }

    @ApiOperation(value = "Update Note for the Site", nickname = "apiV1NotesSitesIdPatch", notes = "", response = Object.class, tags={ "Notes Service" })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = Object.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class),
        @ApiResponse(code = 500, message = "Internal Server Error", response = Error.class)})
    @RequestMapping(value = "/site-notes/{id}",
        produces = { "application/json" }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json" },
        method = RequestMethod.PATCH)
     ResponseEntity<?> apiV1NotesSitesIdPatch(
    		 @ApiParam(value = "The siteId parameter to constrain the results. See **Usage Instructions** for more detail.",required=true) @PathVariable("id") String id,
    		 @ApiParam(value = "" ,required=false )  @Valid @RequestPart("json") Optional<JsonPatch> patchNotes,
    		 @RequestPart("file") Optional<MultipartFile[]> files) throws Exception {
		 		if(! utils.validateForFileSize( files)) { throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE); }
				return service.processPatchRequest(new NotesRequest(DomainResources.siteNotes.toString(), null,	apiUtil.retrieveTenantId(requestInterceptor),(patchNotes.isPresent())? patchNotes.get(): null, id,	apiUtil.retrieveUserName(requestInterceptor)), SiteNotes.class, files);
						
	}


    @ApiOperation(value = "Create a Note for a Site", nickname = "apiV1NotesSitesPost", notes = "", response = SiteNotes.class, tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "Created", response = SiteNotes.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 500, message = "Internal Server Error", response = Error.class),
        @ApiResponse(code = 404, message = "Not Found", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 409, message = "Conflict", response = Error.class) })
    @RequestMapping(value = "/site-notes",
        produces = { MediaType.APPLICATION_JSON_VALUE }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE },
        method = RequestMethod.POST)
     ResponseEntity<?> apiV1NotesSitesPost(
    		 @RequestPart("file") Optional<MultipartFile[]> files,
    		 @RequestPart("json") PostNote postNotes) throws JsonParseException, IOException { 
    	if(! utils.validateForFileSize( files)) { throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE);	}
		return service.processPostRequest(new NotesRequest(DomainResources.siteNotes.toString(), postNotes.getDomainId(), apiUtil.retrieveTenantId(requestInterceptor), postNotes,	null, apiUtil.retrieveUserName(requestInterceptor)), files);
    }
        
    @ApiOperation(value = "Get Notes for all assets", nickname = "apiV1NotesAssetsGet", notes = "Get Notes for assets", response = SiteNotes.class, responseContainer = "List", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = SiteNotes.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/asset-notes",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
     ResponseEntity<Object> apiV1NotesAssetsGet(
				@RequestParam Optional<String> filter,
		        @RequestParam Optional<Integer> pageIdx,
		        @RequestParam Optional<Integer> pageSize,
	            @RequestParam Optional<String> creationDate,
	            @RequestParam Optional<String> updateDate,
	            @RequestParam Optional<String> updatedBy,
	            @RequestParam Optional<String> createdBy,	
		        @RequestParam Optional<String> domainId,
		        @RequestParam Optional<String> category,
		        @RequestParam Optional<String> query) throws IOException{
    	NotesRequest noteRequest = new NotesRequest();
					noteRequest.setDomain(DomainResources.assetNotes.toString()); 
					noteRequest.setDomainIds((domainId.isPresent())? domainId.get(): null); 
					noteRequest.setTenantId(apiUtil.retrieveTenantId(requestInterceptor));
					noteRequest.setFilter(filter.isPresent()? filter.get(): null);
					noteRequest.setPageIdx(pageIdx.isPresent()? pageIdx.get(): pageNum);
					noteRequest.setPageSize(pageSize.isPresent()? pageSize.get(): pageSizeDef);
					noteRequest.setBody(updatedBy.isPresent()? updatedBy.get(): null);
					noteRequest.setCreatedBy(apiUtil.retrieveUserName(requestInterceptor));
					noteRequest.setCreationDate(creationDate.isPresent()? creationDate.get(): null);
					noteRequest.setUpdateDate(updateDate.isPresent()? updateDate.get(): null);
					noteRequest.setCategory(category.isPresent()? category.get(): null);
					noteRequest.setQuery(query.isPresent()? query.get(): null);		
					String response = service.processGetRequest(noteRequest); 
                	return (response.length() > 2 )? 
                			(new ResponseEntity<>(response, HttpStatus.OK)) : 
                				(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT));
    }


    @ApiOperation(value = "Delete Note for an Asset", nickname = "apiV1NotesAssetsIdDelete", notes = "", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/asset-notes/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.DELETE)
     ResponseEntity<?> apiV1NotesAssetsIdDelete(
    		 @ApiParam(value = "The asset Id parameter to constrain the results. See **Usage Instructions** for more detail.",required=true) @PathVariable("id") String id)  throws Exception{

		return service.processDeleteRequest(
				new NotesRequest(DomainResources.assetNotes.toString(), 
						null, 
						apiUtil.retrieveTenantId(requestInterceptor), 
						null, 
						id, 
						apiUtil.retrieveUserName(requestInterceptor)), 
				AssetNotes.class); 
    }



    @ApiOperation(value = "Get Note for an Asset", nickname = "apiV1NotesAssetsIdGet", notes = "", response = SiteNotes.class, responseContainer = "List", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = SiteNotes.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/asset-notes/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
     ResponseEntity<Object> apiV1NotesAssetsIdGet(
    		 	@ApiParam(value = "The assetId parameter to constrain the results. See **Usage Instructions** for more detail.",required=true) 
    		 	@PathVariable("id") String id,
				@RequestParam Optional<String> filter,
		        @RequestParam Optional<Integer> pageIdx,
		        @RequestParam Optional<Integer> pageSize,
		        @RequestParam Optional<String> domainId) throws IOException{
		        	
  		String response = service.processGetRequest(
  				new NotesRequest(DomainResources.assetNotes.toString(), 
  						(domainId.isPresent()? domainId.get(): null), 
  						apiUtil.retrieveTenantId(requestInterceptor),	
  						null, 
  						id, 
  						apiUtil.retrieveUserName(requestInterceptor)));
        return (response.length() > 2 )? (new ResponseEntity<>(response, HttpStatus.OK)) : 
        	(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT)); //(new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.CODE_404.errordescription(), VaidatedMessage.NOT_FOUND.description() + id), HttpStatus.NOT_FOUND));
	
    }


    @ApiOperation(value = "Update Note for an Asset", nickname = "apiV1NotesAssetsIdPatch", notes = "", response = InlineResponse200.class, tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InlineResponse200.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/asset-notes/{id}",
        produces = { "application/json" }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE, "application/json-patch+json" },
        method = RequestMethod.PATCH)
     ResponseEntity<?> apiV1NotesAssetsIdPatch(@ApiParam(value = "The siteId parameter to constrain the results. See **Usage Instructions** for more detail.",required=true) 
     @PathVariable("id") String id,  
	 @ApiParam(value = "" ,required=true )  @Valid @RequestPart("json") Optional<JsonPatch> patchNotes,
	 @RequestPart("file") Optional<MultipartFile[]> files) throws Exception {
		if(! utils.validateForFileSize( files)) { throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE); }
    	return service.processPatchRequest(
    			new NotesRequest(DomainResources.assetNotes.toString(), null, apiUtil.retrieveTenantId(requestInterceptor), (patchNotes.isPresent())? patchNotes.get(): null, id, apiUtil.retrieveUserName(requestInterceptor)),	AssetNotes.class, files);
 	}


    @ApiOperation(value = "Create Note for an Asset", nickname = "apiV1NotesAssetsPost", notes = "", response = SiteNotes.class, tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "Created", response = SiteNotes.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 409, message = "Conflict", response = Error.class) })
    @RequestMapping(value = "/asset-notes",
        produces = { "application/json" }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json" },
        method = RequestMethod.POST)
     ResponseEntity<?> apiV1NotesAssetsPost(
    		 @RequestPart("file") Optional<MultipartFile[]> files,
    		 @RequestPart("json")  @Valid PostNote postNotes) throws JsonParseException, IOException { 
		if(! utils.validateForFileSize( files)) { throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE); }

		return service.processPostRequest(new NotesRequest(DomainResources.assetNotes.toString(), postNotes.getDomainId(), apiUtil.retrieveTenantId(requestInterceptor), postNotes, null, apiUtil.retrieveUserName(requestInterceptor)), files);
    }

    @ApiOperation(value = "Get Notes for all Cases", nickname = "apiV1NotesCasesGet", notes = "Get Notes", response = SiteNotes.class, responseContainer = "List", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = SiteNotes.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/case-notes",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
    ResponseEntity<Object> apiV1NotesCasesGet(
			@RequestParam Optional<String> filter,
	        @RequestParam Optional<Integer> pageIdx,
	        @RequestParam Optional<Integer> pageSize,
            @RequestParam Optional<String> creationDate,
            @RequestParam Optional<String> updateDate,
            @RequestParam Optional<String> updatedBy,
            @RequestParam Optional<String> createdBy,
	        @RequestParam Optional<String> domainId,
	        @RequestParam Optional<String> category,
	        @RequestParam Optional<String> query) throws IOException{
    	NotesRequest noteRequest = new NotesRequest();
		noteRequest.setDomain(DomainResources.caseNotes.toString()); 
		noteRequest.setDomainIds((domainId.isPresent())? domainId.get(): null); 
		noteRequest.setTenantId(apiUtil.retrieveTenantId(requestInterceptor));
		noteRequest.setFilter(filter.isPresent()? filter.get(): null);
		noteRequest.setPageIdx(pageIdx.isPresent()? pageIdx.get(): pageNum);
		noteRequest.setPageSize(pageSize.isPresent()? pageSize.get(): pageSizeDef);
		noteRequest.setBody(updatedBy.isPresent()? updatedBy.get(): null);
		noteRequest.setCreatedBy(apiUtil.retrieveUserName(requestInterceptor));
		noteRequest.setCreationDate(creationDate.isPresent()? creationDate.get(): null);
		noteRequest.setUpdateDate(updateDate.isPresent()? updateDate.get(): null);
		noteRequest.setCategory(category.isPresent()? category.get(): null);
		noteRequest.setQuery(query.isPresent()? query.get(): null);		
		String response = service.processGetRequest(noteRequest); 
       	return (response.length() > 2 )? 
       			(new ResponseEntity<>(response, HttpStatus.OK)) : 
       				(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT));

    }

    @ApiOperation(value = "Delete Notes for a Cases", nickname = "apiV1NotesCasesIdDelete", notes = "", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/case-notes/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.DELETE)
     ResponseEntity<?> apiV1NotesCasesIdDelete(@ApiParam(value = "",required=true) @PathVariable("id") String id)  throws Exception{

       	return service.processDeleteRequest(new NotesRequest( DomainResources.caseNotes.toString(), null, apiUtil.retrieveTenantId(requestInterceptor), null,id, apiUtil.retrieveUserName(requestInterceptor)), CaseNotes.class);
    }


    @ApiOperation(value = "Get Notes for a Cases", nickname = "apiV1NotesCasesIdGet", notes = "", response = SiteNotes.class, responseContainer = "List", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = SiteNotes.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/case-notes/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
     ResponseEntity<Object> apiV1NotesCasesIdGet(
    		 	@ApiParam(value = "",required=true) 
     			@PathVariable("id") String id,
				@RequestParam Optional<String> filter,
		        @RequestParam Optional<Integer> pageIdx,
		        @RequestParam Optional<Integer> pageSize,
		        @RequestParam Optional<String> domainId) throws IOException{
  			String response = service.processGetRequest(
  					new NotesRequest(DomainResources.caseNotes.toString(),	
  							(domainId.isPresent()? domainId.get(): null), 
  							apiUtil.retrieveTenantId(requestInterceptor),	
  							null, 
  							id, 
  							null));
          	return (response.length() > 2 )? 
          			(new ResponseEntity<>(response, HttpStatus.OK)) : 
          				(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT)); //(new ResponseEntity<> (new Error(dateFormat.getCurrentDateFormated(), ErrorConstants.ERROR_TITLE, ErrorCodes.CODE_404.errordescription(), VaidatedMessage.NOT_FOUND.description() + id), HttpStatus.NOT_FOUND));

    }


    @ApiOperation(value = "Update Note for the Cases", nickname = "apiV1NotesCasesIdPatch", notes = "", response = InlineResponse200.class, tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InlineResponse200.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/case-notes/{id}",
        produces = { "application/json" }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE ,  "application/json-patch+json"},
        method = RequestMethod.PATCH)
     ResponseEntity<?> apiV1NotesCasesIdPatch(@ApiParam(value = "",required=true) @PathVariable("id") String id,
    		 @ApiParam(value = "" ,required=true )  @Valid @RequestPart("json") Optional<JsonPatch> patchNotes,
    		 @RequestPart("file") Optional<MultipartFile[]> files) throws Exception {
		 if(! utils.validateForFileSize( files)) {	throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE);	}
	     return service.processPatchRequest(new NotesRequest( DomainResources.caseNotes.toString(), null, apiUtil.retrieveTenantId(requestInterceptor),	(patchNotes.isPresent())? patchNotes.get(): null,	id,	apiUtil.retrieveUserName(requestInterceptor)), CaseNotes.class, files);
 	}


    @ApiOperation(value = "Create Note for a Cases", nickname = "apiV1NotesCasesPost", notes = "", response = SiteNotes.class, tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "Created", response = SiteNotes.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 409, message = "Conflict", response = Error.class) })
    @RequestMapping(value = "/case-notes",
        produces = { MediaType.APPLICATION_JSON_VALUE }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE },
        method = RequestMethod.POST)
     ResponseEntity<?> apiV1NotesCasesPost(
    		 @RequestPart("file") Optional<MultipartFile[]> files,
    		 @RequestPart("json")  @Valid PostNote postNotes) throws JsonParseException, IOException { 

		if(! utils.validateForFileSize( files)) { throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE); }

       	return service.processPostRequest(new NotesRequest(DomainResources.caseNotes.toString(), postNotes.getDomainId(), apiUtil.retrieveTenantId(requestInterceptor), postNotes, 	null, apiUtil.retrieveUserName(requestInterceptor)), files);
    }

    @ApiOperation(value = "Get Notes for all Events", nickname = "apiV1NotesEventsGet", notes = "Get Notes", response = SiteNotes.class, responseContainer = "List", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = SiteNotes.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/event-notes",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
    ResponseEntity<?> apiV1NoteEventsGet(
			@RequestParam Optional<String> filter,
	        @RequestParam Optional<Integer> pageIdx,
	        @RequestParam Optional<Integer> pageSize,
            @RequestParam Optional<String> creationDate,
            @RequestParam Optional<String> updateDate,	  
            @RequestParam Optional<String> updatedBy,
            @RequestParam Optional<String> createdBy,
	        @RequestParam Optional<String> domainId,
	        @RequestParam Optional<String> category,
	        @RequestParam Optional<String> query) throws IOException{
    	NotesRequest noteRequest = new NotesRequest();
		noteRequest.setDomain(DomainResources.eventNotes.toString()); 
		noteRequest.setDomainIds((domainId.isPresent())? domainId.get(): null); 
		noteRequest.setTenantId(apiUtil.retrieveTenantId(requestInterceptor));
		noteRequest.setFilter(filter.isPresent()? filter.get(): null);
		noteRequest.setPageIdx(pageIdx.isPresent()? pageIdx.get(): pageNum);
		noteRequest.setPageSize(pageSize.isPresent()? pageSize.get(): pageSizeDef);
		noteRequest.setBody(updatedBy.isPresent()? updatedBy.get(): null);
		noteRequest.setCreatedBy(apiUtil.retrieveUserName(requestInterceptor));
		noteRequest.setCreationDate(creationDate.isPresent()? creationDate.get(): null);
		noteRequest.setUpdateDate(updateDate.isPresent()? updateDate.get(): null);
		noteRequest.setCategory(category.isPresent()? category.get(): null);
		noteRequest.setQuery(query.isPresent()? query.get(): null);		
		String response = service.processGetRequest(noteRequest); 
      	return (response.length() > 2 )? 
      			(new ResponseEntity<>(response, HttpStatus.OK)) : 
      				(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT));
    }
    

    @ApiOperation(value = "Delete Note for an Event", nickname = "apiV1NotesEventsIdDelete", notes = "", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/event-notes/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.DELETE)
     ResponseEntity<?> apiV1NotesEventsIdDelete(@ApiParam(value = "",required=true) @PathVariable("id") String id) throws Exception{
	        
      	return service.processDeleteRequest(new NotesRequest(DomainResources.eventNotes.toString(),	
      			null, 
      			apiUtil.retrieveTenantId(requestInterceptor),	
      			null, 
      			id, 
      			apiUtil.retrieveUserName(requestInterceptor)), 
      			EventNotes.class);
    }

    @ApiOperation(value = "Get Note for an Event", nickname = "apiV1NotesEventsIdGet", notes = "", response = SiteNotes.class, responseContainer = "List", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = SiteNotes.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/event-notes/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
    ResponseEntity<Object> apiV1NoteEventIdGet(
		 	@ApiParam(value = "The eventId parameter to constrain the results. See **Usage Instructions** for more detail.",required=true)
		 	@PathVariable("id") String id,
			@RequestParam Optional<String> filter,
	        @RequestParam Optional<String> domainId)  throws IOException{
							        	
		String response = service.processGetRequest(new NotesRequest(
				DomainResources.eventNotes.toString(), 
				(domainId.isPresent()? domainId.get(): null), 
				apiUtil.retrieveTenantId(requestInterceptor),	
				null, 
				id, 
				null));
       	return (response.length() > 2 )? 
       			(new ResponseEntity<>(response, HttpStatus.OK)) :
       				(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT)); 
    }



    @ApiOperation(value = "Update Note for an Event", nickname = "apiV1NotesEventsIdPatch", notes = "", response = InlineResponse200.class, tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InlineResponse200.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/event-notes/{id}",
        produces = { "application/json" }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json" },
        method = RequestMethod.PATCH)
     ResponseEntity<?> apiV1NotesEventsIdPatch(@ApiParam(value = "",required=true) @PathVariable("id") String id,
    		 @ApiParam(value = "" ,required=true )  @Valid @RequestPart("json") Optional<JsonPatch> patchNotes,
    		 @RequestPart("file") Optional<MultipartFile[]> files) throws Exception {
 		if(! utils.validateForFileSize( files)) { throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE);	}
        return service.processPatchRequest(new NotesRequest(DomainResources.eventNotes.toString(), null, apiUtil.retrieveTenantId(requestInterceptor), (patchNotes.isPresent())? patchNotes.get(): null, id, apiUtil.retrieveUserName(requestInterceptor)), EventNotes.class, files);
					
 	}


    @ApiOperation(value = "Create Note for an Event", nickname = "apiV1NotesEventsPost", notes = "", response = SiteNotes.class, tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "Created", response = SiteNotes.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 409, message = "Conflict", response = Error.class) })
    @RequestMapping(value = "/event-notes",
        produces = { "application/json" }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE },
        method = RequestMethod.POST)
     ResponseEntity<?> apiV1NotesEventsPost(
    		 @RequestPart("file") Optional<MultipartFile[]> files,
    		 @RequestPart("json")  @Valid PostNote postNotes) throws JsonParseException, IOException { 
		if(! utils.validateForFileSize( files)) { throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE); }
					
	    return service.processPostRequest(new NotesRequest(DomainResources.eventNotes.toString(), postNotes.getDomainId(), apiUtil.retrieveTenantId(requestInterceptor), postNotes, null,  apiUtil.retrieveUserName(requestInterceptor)), files);
    }


    @ApiOperation(value = "Get Notes for all Task", nickname = "apiV1NotesTasksGet", notes = "Get Notes", response = SiteNotes.class, responseContainer = "List", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = SiteNotes.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/task-notes",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
    ResponseEntity<Object> apiV1NotesTaskssGet(
			@RequestParam Optional<String> filter,
	        @RequestParam Optional<Integer> pageIdx,
	        @RequestParam Optional<Integer> pageSize,
            @RequestParam Optional<String> creationDate,
            @RequestParam Optional<String> updateDate,	 
            @RequestParam Optional<String> updatedBy,
            @RequestParam Optional<String> createdBy,
	        @RequestParam Optional<String> domainId,
	        @RequestParam Optional<String> category,
	        @RequestParam Optional<String> query) throws IOException{
    	NotesRequest noteRequest = new NotesRequest();
		noteRequest.setDomain(DomainResources.taskNotes.toString()); 
		noteRequest.setDomainIds((domainId.isPresent())? domainId.get(): null); 
		noteRequest.setTenantId(apiUtil.retrieveTenantId(requestInterceptor));
		noteRequest.setFilter(filter.isPresent()? filter.get(): null);
		noteRequest.setPageIdx(pageIdx.isPresent()? pageIdx.get(): pageNum);
		noteRequest.setPageSize(pageSize.isPresent()? pageSize.get(): pageSizeDef);
		noteRequest.setBody(updatedBy.isPresent()? updatedBy.get(): null);
		noteRequest.setCreatedBy(apiUtil.retrieveUserName(requestInterceptor));
		noteRequest.setCreationDate(creationDate.isPresent()? creationDate.get(): null);
		noteRequest.setUpdateDate(updateDate.isPresent()? updateDate.get(): null);
		noteRequest.setCategory(category.isPresent()? category.get(): null);
		noteRequest.setQuery(query.isPresent()? query.get(): null);		
    	String response = service.processGetRequest(noteRequest); 
       	return (response.length() > 2 )? 
       			(new ResponseEntity<>(response, HttpStatus.OK)) : 
       				(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT));

    }


    @ApiOperation(value = "Delete Note for a Task", nickname = "apiV1NotesTasksIdDelete", notes = "", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/task-notes/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.DELETE)
     ResponseEntity<?> apiV1NotesTasksIdDelete(@ApiParam(value = "",required=true) @PathVariable("id") String id) throws Exception{
					
	  	return service.processDeleteRequest(
	  			new NotesRequest( 
	  					DomainResources.taskNotes.toString(), 
	  					null, 
	  					apiUtil.retrieveTenantId(requestInterceptor), 
	  					null, 
	  					id, 
	  					apiUtil.retrieveUserName(requestInterceptor)), 
	  			TaskNotes.class);
    }


    @ApiOperation(value = "Get Note for a Task", nickname = "apiV1NotesTasksIdGet", notes = "", response = SiteNotes.class, responseContainer = "List", tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = SiteNotes.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/task-notes/{id}",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
    ResponseEntity<Object> apiV1NotesTaskIdGet(
		 	@ApiParam(value = "The eventId parameter to constrain the results. See **Usage Instructions** for more detail.",required=true)
		 	@PathVariable("id") String id,
			@RequestParam Optional<String> filter,
	        @RequestParam Optional<Integer> pageIdx,
	        @RequestParam Optional<Integer> pageSize,
	        @RequestParam Optional<String> domainId)  throws IOException{
							        	
			String response = service.processGetRequest(
					new NotesRequest(
							DomainResources.taskNotes.toString(), 
							(domainId.isPresent()? domainId.get(): null), 
							apiUtil.retrieveTenantId(requestInterceptor), 
							null, 
							id, 
							null));
           	return (response.length() > 2 )? 
           			(new ResponseEntity<>(response, HttpStatus.OK)) : 
           				(new ResponseEntity<> (EMPTY_JSON_RESPONSE, HttpStatus.NO_CONTENT));

    }


    @ApiOperation(value = "Update Note for a Task", nickname = "apiV1NotesTasksIdPatch", notes = "", response = InlineResponse200.class, tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "OK", response = InlineResponse200.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class) })
    @RequestMapping(value = "/task-notes/{id}",
        produces = { "application/json" }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE,  "application/json-patch+json" },
        method = RequestMethod.PATCH)
     ResponseEntity<?> apiV1NotesTasksIdPatch(@ApiParam(value = "",required=true) @PathVariable("id") String id,
    		 @ApiParam(value = "" ,required=true )  @Valid @RequestPart("json") Optional<JsonPatch> patchNotes,
    		 @RequestPart("file") Optional<MultipartFile[]> files) throws Exception {
 		if(! utils.validateForFileSize( files)) {throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE); }
        return service.processPatchRequest(new NotesRequest(DomainResources.taskNotes.toString(), null,	apiUtil.retrieveTenantId(requestInterceptor),(patchNotes.isPresent())? patchNotes.get(): null,	id,	apiUtil.retrieveUserName(requestInterceptor)), TaskNotes.class, files);
 	}


    @ApiOperation(value = "Create Note for a Task", nickname = "apiV1NotesTasksPost", notes = "", response = SiteNotes.class, tags={ "Notes Service", })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "Created", response = SiteNotes.class),
        @ApiResponse(code = 400, message = "Bad Request", response = Error.class),
        @ApiResponse(code = 401, message = "Unauthorized", response = Error.class),
        @ApiResponse(code = 403, message = "Forbidden", response = Error.class),
        @ApiResponse(code = 404, message = "NotFound",     response = Error.class),
        @ApiResponse(code = 500, message = "Server Internal Error", response = Error.class),
        @ApiResponse(code = 409, message = "Conflict", response = Error.class) })
    @RequestMapping(value = "/task-notes",
        produces = { "application/json" }, 
        consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.MULTIPART_MIXED_VALUE, MediaType.APPLICATION_JSON_VALUE },
        method = RequestMethod.POST)
     ResponseEntity<?> apiV1NotesTasksPost(
    		 @RequestPart("file") Optional<MultipartFile[]> files,
    		 @RequestPart("json")  @Valid PostNote postNotes) throws JsonParseException, IOException { 
		if(! utils.validateForFileSize( files)) { throw new ResourceNotValid(SIZE_NOT_ALLOWED + MAX_FILE_SIZE);	}

        return service.processPostRequest(new NotesRequest(DomainResources.taskNotes.toString(), postNotes.getDomainId(), apiUtil.retrieveTenantId(requestInterceptor), postNotes, 	null, apiUtil.retrieveUserName(requestInterceptor)), files);

    }

}
