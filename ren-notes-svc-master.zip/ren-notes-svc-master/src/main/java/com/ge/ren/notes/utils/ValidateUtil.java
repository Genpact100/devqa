package com.ge.ren.notes.utils;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.ge.ren.notes.exception.AttributeNotFound;
import com.ge.ren.notes.exception.ResourceNotValid;
import com.ge.ren.notes.model.GetNotes;
import com.ge.ren.notes.model.NotesRequest;
import com.ge.ren.notes.model.Pagination;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ge.ren.notes.config.AppConfig;
import com.ge.ren.notes.constants.ErrorConstants;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.model.UpsertNote;
import lombok.extern.slf4j.Slf4j;
import com.ge.ren.notes.constants.Scope;
import static com.ge.ren.notes.constants.Constants.*;

@Slf4j
@Component
public class ValidateUtil {

 	@Value("${noteSize:4000}")
    private static int noteSize = NOTE_SIZE;
    
    @Value("${titleSize:120}")
    private static int titleSize = TITLE_SIZE;
    
    static DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_PATTERN, Locale.ENGLISH);
    static DateTimeFormatter formatterm = DateTimeFormatter.ofPattern(DATE_PATTERN_MONGO, Locale.ENGLISH);

	public static void validatePostRequest(Note note, MultipartFile[] files, String type) throws JsonMappingException, JsonProcessingException{
		if( !StringUtils.hasLength(note.getDomainId()) && type.equalsIgnoreCase(POST)){
			throw new AttributeNotFound(ErrorConstants.VaidatedMessage.DOMAINID.description());
		}
		
		if( StringUtils.hasLength(note.getNote()) && getNoteSizeChecked(note)){
			if( StringUtils.hasLength(note.getTitle()) && getTitleSizeChecked(note)){}
		}else
		if( StringUtils.hasLength(note.getTitle()) && getTitleSizeChecked(note)){
		}else {
			if( null == files || files[0].isEmpty()) {
				if(type.equalsIgnoreCase(PATCH)) {
					throw new AttributeNotFound(ErrorConstants.VaidatedMessage.ATTACHMENT_EMPTY_PATCH.description());
				}else {
					throw new AttributeNotFound(ErrorConstants.VaidatedMessage.ATTACHMENT_EMPTY_POST.description());
				}
			}
		}

		if(StringUtils.hasLength(note.getScope())) {
			validateScope(note);
		}
		if(StringUtils.hasLength(note.getValidDateBy())) {
			validateDateBy(note.getValidDateBy(), VALID_DATE_BY);
		}
		if(StringUtils.hasLength(note.getPriority())) {
			validatePriority(note);
		}
		if(StringUtils.hasLength(note.getStatus())) {
			validateStatus(note);
		}		
	}
	public static void validatePatchRequest(UpsertNote note, String type) throws JsonMappingException, JsonProcessingException{
		if( !StringUtils.hasLength(note.getDomainId()) && type.equalsIgnoreCase(PATCH)){
			throw new AttributeNotFound(ErrorConstants.VaidatedMessage.DOMAINID.description());
		}
		
		if( StringUtils.hasLength(note.getNote()) && getNoteSizeChecked(note)){
			if( StringUtils.hasLength(note.getTitle()) && getTitleSizeChecked(note)){}
		}

		if(StringUtils.hasLength(note.getScope())) {
			validateScope(note.getScope());
		}		
		if(StringUtils.hasLength(note.getPriority())) {
			validatePriority(note.getPriority());
		}
		if(StringUtils.hasLength(note.getStatus())) {
			validateStatus(note.getStatus().toLowerCase());
		}		
	}
	static boolean getTitleSizeChecked(Note note) {
		if(note.getTitle().length() > titleSize){
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.TITLE_SIZE_LIMIT.description() + titleSize);
		}
		return true;

	}
	static boolean getTitleSizeChecked(UpsertNote note) {
		if(note.getTitle().length() > titleSize){
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.TITLE_SIZE_LIMIT.description() + titleSize);
		}
		return true;

	}
	static boolean getNoteSizeChecked(Note note) {
		if(note.getNote().length() > noteSize){
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.NOTE_SIZE_LIMIT.description() + noteSize);
		}
		return true;
	}
	static boolean getNoteSizeChecked(UpsertNote note) {
		if(note.getNote().length() > noteSize){
			throw new ResourceNotValid(ErrorConstants.VaidatedMessage.NOTE_SIZE_LIMIT.description() + noteSize);
		}
		return true;
	}
	protected static void validateScope(String scope){
		Scope.internal.toString();
		switch(scope){
			case EXTERNAL :
				break;
			case INTERNAL:
				break;
			default:
				throw new ResourceNotValid(SCOPE_VALUE_MSG);
		}
	}

	protected static void validateScope(Note note){
		Scope.internal.toString();
		switch(note.getScope()){
			case EXTERNAL :
				break;
			case INTERNAL:
				break;
			default:
				throw new ResourceNotValid(SCOPE_VALUE_MSG);
		}
	}

	protected static void validateStatus(String status) {
		switch(status){
			case ACTIVE :
				break;
			case INACTIVE:
				break;
			default:
				throw new ResourceNotValid(STATUS_VALUE_MSG);
		}
	}

	protected static void validateStatus(Note note) {
		switch(note.getStatus().toLowerCase()){
			case ACTIVE :
				break;
			case INACTIVE:
				break;
			default:
				throw new ResourceNotValid(STATUS_VALUE_MSG);
		}
	}

	protected static void validatePriority(Note note){
		switch(note.getPriority()){
			case HIGH :
				break;
			case MEDIUM:
				break;
			case LOW:
				break;
			default:
				throw new ResourceNotValid(PRIORITY_VALUE_MSG);
		}
	}

	protected static void validatePriority(String priority){
		switch(priority){
			case HIGH :
				break;
			case MEDIUM:
				break;
			case LOW:
				break;
			default:
				throw new ResourceNotValid(PRIORITY_VALUE_MSG);
		}
	}
	
	protected static void validateDateBy(String date, String name) {
		  log.debug("date " + name + ": " + date);
		  
		  LocalDateTime dateTime = LocalDateTime.now();
		  try {
			  dateTime = LocalDateTime.parse(date, formatter);
		  }catch(Exception e) {
			  log.error("exception to parse validDateBy into LocalDateTime: {} ", e.getMessage());
			  throw new ResourceNotValid("Value of " + name  +": "+  date + ", "+ CORRECT_DATE_MSG + DATE_PATTERN );
		  }
		  if ( dateTime.isBefore(LocalDateTime.now())) {
			  throw new ResourceNotValid(DATE_AFTER_MSG + dateTime);
		  }

	}

	public static void validateJsonString(String json) throws IOException{
        try {
			new AppConfig().objectMapper().readTree(json);  //new JSONObject(json);
        } catch (JsonParseException ex) {
            log.error(ErrorConstants.LOG_PLACE_HOLDER, ErrorConstants.ErrorCodes.JSON_PARSE_FAIL, MINOR,
                    ErrorConstants.ErrorCodes.JSON_PARSE_FAIL.errordescription() + ex.getMessage());
            throw new JsonParseException(null, "Received Invalid json");
        }
    }

    public static String validateForSpecChars(String json, String field) {
       Pattern pt = Pattern.compile("[~`@#$%&^]"); 
       Matcher match= pt.matcher(json);
       if(match.find()) {
    	   log.debug(" spec char in json : {}", json); //throw new ResourceNotValid(ErrorConstants.VaidatedMessage.SPEC_CHAR_INCLUDED.description() + field);
       }
       pt = Pattern.compile(SCRIPT);
       match = pt.matcher(json);
       if(match.find()) {
    	   throw new ResourceNotValid(ErrorConstants.VaidatedMessage.SCRIPT_INCLUDED.description() + field);
       }
       return json;
    }
    
    /*
     * Pagination
     * @return GetNotes
     */
    public static GetNotes setPaginationMetadata(List<Note> notes, NotesRequest request ) {
    	return new GetNotes(
					new Pagination(request.getPageIdx(), request.getCount(), (int)(Math.ceil((double)request.getCount()/request.getPageSize())), request.getPageSize()),
   								notes);
    }

}
