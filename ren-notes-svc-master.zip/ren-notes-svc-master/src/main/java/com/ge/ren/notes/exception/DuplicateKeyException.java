package com.ge.ren.notes.exception;

public class DuplicateKeyException extends ApiException {
    public DuplicateKeyException(String msg) {
        super("Resource Not Found ", msg);
    }
}
