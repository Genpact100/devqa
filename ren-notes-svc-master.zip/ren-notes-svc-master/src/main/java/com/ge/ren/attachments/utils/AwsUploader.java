package com.ge.ren.attachments.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SDKGlobalConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.ge.ren.notes.exception.ApiException;

import lombok.extern.slf4j.Slf4j;
import static com.ge.ren.notes.constants.Constants.REGION;

@Component
@Slf4j
public class AwsUploader {
	
    @Autowired
    Autils utils;
    
    @Autowired
    FileUploader fileUploader;
    
    @Value("${storage.type:s3aws}")
	private String storageType;
    
    @Value("${aws.bucket.prefix:TODO_add_to_properties}")
	private String bucket;
    
    @Value("${aws.region:us-east-1}")
    private String region;
	
    @Value("${aws.folder:attachments}")
    private String folder;
    
    @Value("${AWS_S3_KMS_KEY:TODO_ADD_KMS_KEY_TO_PROPS}")
    private String kmsKey;

	private AmazonS3 s3b; 

    
	 public boolean removeS3Object(String key) {
		 try {
			System.setProperty(SDKGlobalConfiguration.DISABLE_CERT_CHECKING_SYSTEM_PROPERTY, "true");
			s3b = AmazonS3ClientBuilder.standard().withRegion(REGION).build();
			s3b.deleteObject(bucket, key);
			return true;
		 }catch(com.amazonaws.SdkClientException e) {
            log.error("{}",e);
            throw new ApiException("500", e.getMessage());			 
		 }
	 }

}



