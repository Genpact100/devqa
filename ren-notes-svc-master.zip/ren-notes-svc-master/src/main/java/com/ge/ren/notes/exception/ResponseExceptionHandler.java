package com.ge.ren.notes.exception;

import com.ge.ren.notes.constants.ErrorConstants;
import com.ge.ren.notes.utils.DateFormatMS;
import com.ge.ren.common.keycloak.exception.TokenVerifyException;
import com.ge.ren.foundation.logging.ErrorSeverity;
import com.mongodb.MongoClientException;
import com.mongodb.MongoServerException;

import lombok.extern.slf4j.Slf4j;
import java.util.Objects;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


@ControllerAdvice
@Slf4j
public class ResponseExceptionHandler extends ResponseEntityExceptionHandler {
	@Autowired
	DateFormatMS dateFormat;

	@ExceptionHandler({ ApiException.class })
	public final ResponseEntity<Object> handleApiException(ApiException ex, WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		HttpStatus status = HttpStatus.BAD_REQUEST;
		if (ex instanceof NotImplementedException) {
			status = HttpStatus.NOT_IMPLEMENTED;
		} else if (ex instanceof NotFoundException) {
			status = HttpStatus.NOT_FOUND;
		}else if (ex instanceof InvalidParameterException) {
			status = HttpStatus.BAD_REQUEST;
		} else if (ex instanceof UnauthorizedForActionException) {
			status = HttpStatus.UNAUTHORIZED;
		} else if (ex instanceof DuplicateKeyException) {
			status = HttpStatus.CONFLICT;
		} else if (ex instanceof ResourceNotValid) {
			status = HttpStatus.BAD_REQUEST;
		}

		return this.handleExceptionInternal(ex, null, headers, status, request);
	}

	@Override
	protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		String code = status.toString();
		if (ex instanceof ApiException) {
			code = ((ApiException) ex).getCode();
		}

		Error error = new Error(dateFormat.getCurrentDateFormated(), ex.getClass().getName(),
				HttpStatus.BAD_REQUEST.toString(), ex.getMessage());
		return super.handleExceptionInternal(ex, error, headers, status, request);
	}

	@ExceptionHandler({ MongoClientException.class })
	public final ResponseEntity<Object> handleMongoClientException(MongoClientException ex, WebRequest request) {
		Error error = new Error(dateFormat.getCurrentDateFormated(), "MongoClient_Error_500", ex.getClass().getName(),
				ex.getMessage());
		return super.handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
	}

	@ExceptionHandler({ MongoServerException.class })
	public final ResponseEntity<Object> handleMongoServerException(MongoServerException ex, WebRequest request) {
		Error error = new Error(dateFormat.getCurrentDateFormated(), "MongoServer_Error_500", ex.getClass().getName(),
				ex.getMessage() + " on " + ex.getServerAddress());
		return super.handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
	}

	
	@ExceptionHandler(ValidationException.class)
    public final ResponseEntity<Object> handleValidationException(ValidationException ex, WebRequest request) {
        Throwable cause = findCause(ex);
        Error error = new Error(dateFormat.getCurrentDateFormated(), "Validation_Error_400", cause.getClass().getName(), cause.getMessage());
        log.error(ErrorConstants.LOG_PLACE_HOLDER, ErrorConstants.ErrorCodes.VALIDATION_ERROR_400, ErrorSeverity.MAJOR,
        		  ErrorConstants.ErrorCodes.VALIDATION_ERROR_400.errordescription() + ex.getMessage());
        log.debug(ErrorConstants.LOG_PLACE_HOLDER, ErrorConstants.ErrorCodes.VALIDATION_ERROR_400, ErrorSeverity.MAJOR, 
        		  ErrorConstants.ErrorCodes.VALIDATION_ERROR_400.errordescription() + ex.getMessage());
        return super.handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(TokenVerifyException.class)
    public final ResponseEntity<Object> handleAuthzValidationException(TokenVerifyException ex, WebRequest request) {
        Throwable cause = findCause(ex);
        Error error = new Error(dateFormat.getCurrentDateFormated(), "401 Authorization_Error", cause.getClass().getName(), cause.getMessage());
        log.error(ErrorConstants.LOG_PLACE_HOLDER, ErrorConstants.ErrorCodes.AUTHORIZATION_ERROR, ErrorSeverity.MAJOR,
        		  ErrorConstants.ErrorCodes.AUTHORIZATION_ERROR.errordescription() + ex.getMessage());
        log.debug(ErrorConstants.LOG_PLACE_HOLDER, ErrorConstants.ErrorCodes.AUTHORIZATION_ERROR, ErrorSeverity.MAJOR,
        		  ErrorConstants.ErrorCodes.AUTHORIZATION_ERROR.errordescription() + ex.getMessage());
        return super.handleExceptionInternal(ex, error, new HttpHeaders(), ex.getStatus(), request);
    }



    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleGenericException(Exception ex, WebRequest request) {
    	log.error("Exception Occurred -> "+ex.getMessage());
        Throwable cause = findCause(ex);
        Error error = new Error(dateFormat.getCurrentDateFormated(), "Exception_Error_500", cause.getClass().getName(), cause.getMessage());
        log.error(ErrorConstants.LOG_PLACE_HOLDER, ErrorConstants.ErrorCodes.EXCEPTION_ERROR_500, ErrorSeverity.MAJOR,
        		  ErrorConstants.ErrorCodes.EXCEPTION_ERROR_500.errordescription() + ex.getMessage());
        log.debug(ErrorConstants.LOG_PLACE_HOLDER, ErrorConstants.ErrorCodes.EXCEPTION_ERROR_500, ErrorSeverity.MAJOR,
        		  ErrorConstants.ErrorCodes.EXCEPTION_ERROR_500.errordescription() + ex.getMessage());
        return super.handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    private static Throwable findCause(Throwable throwable) {
        Objects.requireNonNull(throwable);
        Throwable rootCause = throwable;
        while (rootCause.getCause() != null && rootCause.getCause() != rootCause) {
            rootCause = rootCause.getCause();
        }
        return rootCause;
    }
}
