package com.ge.ren.notes.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

import com.newrelic.api.agent.NewRelic;

import brave.Span;
import brave.Tracer;

@Component
@Configuration
public class TraceFilter extends GenericFilterBean {
	
	private static final String TRACEID = "traceId";
	private static final String TRACE_ID = "TRACE-ID";

	private final Tracer tracer;

	TraceFilter(Tracer tracer) {
		this.tracer = tracer;
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		Span currentSpan = this.tracer.currentSpan();
		
		if (currentSpan == null) {
			chain.doFilter(request, response);
			return;
		}
		
		HttpServletRequest req = (HttpServletRequest) request;
		if(req.getHeader(TRACEID) != null) {
			MDC.put(TRACEID, req.getHeader(TRACEID));
			((HttpServletResponse) response).addHeader(TRACE_ID, req.getHeader(TRACEID));
		} else {
			((HttpServletResponse) response).addHeader(TRACE_ID, currentSpan.context().traceIdString());
		}
		chain.doFilter(request, response);
		NewRelic.addCustomParameter(TRACE_ID, currentSpan.context().traceIdString());

	}

}
