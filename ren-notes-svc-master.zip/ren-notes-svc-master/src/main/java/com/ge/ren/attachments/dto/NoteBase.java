package com.ge.ren.attachments.dto;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ge.ren.notes.model.PatchNote;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.model.SiteNotes;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.validation.constraints.*;

import com.ge.ren.attachments.model.AttachmentData;


/**
 * Note Base
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NoteBase   {

  private String id;
  @NotNull
  @ApiModelProperty(example = "500023", required = true, value = "")
  @JsonProperty("noteDomainId")
  private String noteDomainId;
  @NotNull
  @ApiModelProperty(example = "GE000WWW", value = "")
  @JsonProperty("tenantId")
  private String tenantId;
  @ApiModelProperty(example = "This is title", value = "")
  @JsonProperty("noteTitle")
  @NotNull
  @Max(value = 120)
  private String noteTitle;
  @ApiModelProperty(example = "This placeholder is for text notes", value = "")
  @JsonProperty("note")
  @Max(value = 2500)
  private String note;
  @ApiModelProperty(example = "06/09/2021 12:45:55", value = "")
  @JsonProperty("noteCreationDate")
  private String noteCreationDate; // = new Date(System.currentTimeMillis()).toGMTString();
  @ApiModelProperty(example = "06/10/2021 1:40:55", value = "")
  @JsonProperty("noteUpdateDate")
  private String noteUpdateDate;
  @ApiModelProperty(example = "06/11/2021 2:00:00", value = "")
  @JsonProperty("noteValidDateBy")
  private String noteValidDateBy;
  @ApiModelProperty(example = "HIGH", value = "LOW")
  @JsonProperty("notePriority")
  private String notePriority;
  @ApiModelProperty(example = "503206931", value = "")
  @JsonProperty("noteCreatedBy")
  private String noteCreatedBy;
  @ApiModelProperty(example = "503206931", value = "")
  @JsonProperty("noteUpdatedBy")
  private String noteUpdatedBy;
  @ApiModelProperty(example = "category", value = "")
  @JsonProperty("noteCategory")
  private String noteCategory;
  @ApiModelProperty(example = "status", value = "active")
  @JsonProperty("noteStatus")
  private String noteStatus; // = "active";
  @JsonProperty("noteScope")
  private String noteScope; // = Scope.internal.toString();
  
  @JsonProperty("timestampc")
  private Timestamp noteTimestampc;
  @JsonProperty("timestampu")
  private Timestamp noteTimestampu;
  
  @JsonProperty("noteDeleted")
  private Boolean noteDeleted = false;

  @JsonProperty("attachments")
  public List<AttachmentData> attachments;

  public NoteBase(SiteNotes notes) {
		super();
		this.id = notes.getId();
		this.noteDomainId = notes.getDomainId();
		this.tenantId = notes.getTenantId();
		this.noteTitle = notes.getTitle();
		this.note = notes.getNote();
		this.noteCreationDate = notes.getCreationDate();
		this.noteUpdateDate = notes.getUpdateDate();
		this.noteValidDateBy = notes.getValidDateBy();
		this.notePriority = notes.getPriority();
		this.noteCreatedBy = notes.getCreatedBy();
		this.noteUpdatedBy = notes.getUpdatedBy();
		this.noteCategory = notes.getCategory();
		this.noteStatus = notes.getStatus();
		this.noteScope = notes.getScope();
		this.noteDeleted = notes.getDeleted();
  }
  
	  public NoteBase(PostNote notes) {
			super();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
			sdf.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
			this.noteDomainId = notes.getDomainId();
			this.noteTitle = notes.getTitle();
			this.note = notes.getNote();
			this.noteCreationDate = sdf.format(new Date(System.currentTimeMillis())).toString();
			this.notePriority = notes.getPriority();
			this.noteCategory = notes.getCategory();
			this.noteScope = notes.getScope();
			this.noteStatus = notes.getStatus();
			this.noteValidDateBy = notes.getValidDateBy();
	  }
  
	  public NoteBase(PatchNote notes) {
		  	super();
		    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy HH:mm:ss");  
			sdf.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
		    this.noteTitle = notes.getTitle();
			this.note = notes.getNote();
			this.noteCreationDate = sdf.format(new Date(System.currentTimeMillis())).toString();
			this.notePriority = notes.getPriority();
			this.noteCategory = notes.getCategory();
			this.noteScope = notes.getScope();
			this.noteStatus = notes.getStatus();
			this.noteValidDateBy = notes.getValidDateBy();
			this.attachments = notes.getAttachments();

	  }
	  
    @Override
	public String toString() {
		return  "{\"id\":\"" + id + "\","
				+"\"domainId\":\"" + noteDomainId + "\", \"tenantId\":\"" + tenantId + "\", \"title\":\"" + noteTitle + "\", \"note\":\""
				+ note + "\", \"creationDate\":\"" + noteCreationDate + "\", \"updateDate\":\"" + noteUpdateDate + "\", \"validDateBy\":\"" + noteValidDateBy
				+ "\", \"priority\":\"" + notePriority + "\", \"createdBy\":\"" + noteCreatedBy + "\", \"updatedBy\":\"" + noteUpdatedBy + "\", \"category\":\""
				+ noteCategory + "\", \"scope\":\"" + noteScope + "\", \"status\":\"" + noteStatus + "\", \"deleted\":" + noteDeleted + ",\"attachments\":" + attachments +"}";
	}


}

