package com.ge.ren.notes.model;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationHealth {
	
	public enum HealthCheckStatus {
		HEALTHY, UNHEALTHY
	}
	
	private String javaVersion;
	private String applicationVersion;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd:HH:mm:ss")
	private Date startDateTime;
	private HealthCheckStatus status;
	private String podNameSpace;
	private String podName;
	private String environment;
	
}
