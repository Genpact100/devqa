package com.ge.ren.notes.model;

import com.ge.ren.notes.dto.Note;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * TaskNotes
 */

@Document(collection = "taskNotes")
public class TaskNotes extends Note  {
  
}

