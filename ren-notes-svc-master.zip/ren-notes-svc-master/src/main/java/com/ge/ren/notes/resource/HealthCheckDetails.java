package com.ge.ren.notes.resource;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.Date;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.ren.NotesApplicationSvc;
import com.ge.ren.notes.model.ApplicationHealth;
import com.ge.ren.notes.model.ApplicationHealth.HealthCheckStatus;

@Component
public class HealthCheckDetails {
	
	private static final String JAVA_VERSION = "java.version";
	private String javaVersion;
	private String applicationVersion;
	private Date startDateTime;
	private HealthCheckStatus status;
	@Value("${POD_NAMESPACE:ds}")
	private String podNameSpace;
	@Value("${POD_NAME:ren-notes-svc}")
	private String podName;
	@Value("${ENVIRONMENT:prod}")
	private String environment;
	
	
	@PostConstruct
	private void init() {
		this.applicationVersion = NotesApplicationSvc.class.getPackage().getImplementationVersion();
		this.javaVersion = System.getProperty(JAVA_VERSION);
		this.startDateTime = getStartDateTime();
	}
	
	private Date getStartDateTime() {
		final RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();
		return new Date(runtime.getStartTime());
	}
	
	public ApplicationHealth getApplicationHealth() {
		final ApplicationHealth applicationHealth = new ApplicationHealth();
		applicationHealth.setStatus(HealthCheckStatus.HEALTHY);
		applicationHealth.setApplicationVersion(applicationVersion);
		applicationHealth.setJavaVersion(javaVersion);
		applicationHealth.setPodName(podName);
		applicationHealth.setPodNameSpace(podNameSpace);
		applicationHealth.setEnvironment(environment);
		return applicationHealth;
	}
	
}
