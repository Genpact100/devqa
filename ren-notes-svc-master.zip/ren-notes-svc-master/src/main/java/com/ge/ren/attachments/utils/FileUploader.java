package com.ge.ren.attachments.utils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.SSEAwsKeyManagementParams;
import com.ge.ren.attachments.model.AttachmentData;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.utils.DateFormatMS;

import static com.ge.ren.notes.constants.Constants.AWS_PATH1;
import static com.ge.ren.notes.constants.Constants.AWS_PATH2;
import static com.ge.ren.notes.constants.Constants.DOT;
import static com.ge.ren.notes.constants.Constants.REGION;
import static com.ge.ren.notes.constants.Constants.S3BUCKET;
import static com.ge.ren.notes.constants.Constants.SLASH;
import static com.ge.ren.notes.constants.Constants.AWS_KMS;
import static com.ge.ren.notes.constants.Constants.AWSS3;
import static com.ge.ren.notes.constants.Constants.METHOD_GET;


import lombok.extern.slf4j.Slf4j;
@Component
@Slf4j
public class FileUploader extends AbstractUploader {
	
    @Autowired
    Autils utils;

    @Autowired
    DateFormatMS dateFormat;

    @Value("${storage.type:s3aws}")
	private String storageType;
    
    @Value("${aws.bucket.prefix:TODO_add_to_properties}")
	private String bucket;
    
    @Value("${ENVIRONMENT:qa}")
	private String ENVIRONMENT;

    @Value("${AWS_S3_KMS_KEY:487459321624:key/ca3ac646-b2aa-4540-bd28-37981be8ec87}")
    private String awsS3KmsKey;
    
    @Value("${spring.profiles.active}")
    String activeProfile;
    
    @Value("${aws.bucket.s3}")
    private String bucketUrl;

    @Value("${aws.access.key}")
    private String awsAccessKey;
    @Value("${aws.secret.key}")
    private String awsSecretKey; 
  
    private static final String FILE = "file/";
    
    @Override
	public List<AttachmentData> uploadFiles(String domainName, MultipartFile[] multipartFiles) throws IOException {

		String fullbucket = utils.compileBucketPath(domainName);
		List<AttachmentData> attachments = new ArrayList<>();
		if(null == multipartFiles) {
			return attachments;
		}
		try {
			utils.validatePathExists(fullbucket);
		    for (MultipartFile mfile : multipartFiles) {
		    	log.debug("mfile.getOriginalFilename().length() -> " +mfile.getOriginalFilename().length());
	            if(mfile.getSize() < 0 ||  mfile.isEmpty() || mfile.getOriginalFilename().length() <= 0) {
	            	return attachments;
	            }
	            utils.validateForFileType(mfile);
		    	String fname = mfile.getOriginalFilename();
		    	//String key = fullbucket + SLASH + dateFormat.getFileNameDateString() + fname.substring(fname.lastIndexOf(DOT));
		    	String key = fullbucket + SLASH + dateFormat.getcurrentUnixTimestamp()  + new java.security.SecureRandom().nextInt() + "-" + fname;
				
        		File file = new File(key);		    	
	        	byte[] bytes = mfile.getBytes();
	        	//int read = 0; byte[] bytes = new byte[1024];
	        	try (BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(file));
	        				//InputStream inputStream = mfile.getInputStream();
	        			BufferedOutputStream stream =
		  		        	      new BufferedOutputStream(new FileOutputStream(file))
	        			) {
	            	byte[] byteArray = IOUtils.toByteArray(mfile.getInputStream());  // IOUtils.toByteArray(inputStream);
	            	log.debug(">>>>>> Determine Setting the content length using IOUtils.inputStream byteArray.length: {} ", byteArray.length);
	            	log.debug("FILE - > {}  exist ?  {} " ,file.getCanonicalPath(),  file.exists());
	        	    stream.write(bytes);
	        	    //while ((read = inputStream.read(bytes)) != -1) {	outputStream.write(bytes, 0, read); }
	        	    log.debug("file upload is done:  {}", key);
	        	    
		        }
	        	URL url = null;
	        	// TODO research inputStream usage instead of file
	        	if(storageType.equalsIgnoreCase(S3BUCKET)) {
        		
	    			AmazonS3 s3b = AmazonS3ClientBuilder.standard().withRegion(REGION).build();
		            PutObjectRequest putRequest = new com.amazonaws.services.s3.model.PutObjectRequest(bucket, key, new File(key) )
		            		.withSSEAwsKeyManagementParams(new SSEAwsKeyManagementParams(AWS_KMS + awsS3KmsKey));   //ROLEARN
			        s3b.putObject(putRequest);
			        Files.delete(Paths.get(key));
			        log.info("aws3 bucket upload is done:  {} ", bucket + key);
			        GeneratePresignedUrlRequest generatePresignedUrlRequest =
		                    new GeneratePresignedUrlRequest(bucket, key).withMethod(HttpMethod.GET).withExpiration(new java.util.Date(Instant.now().toEpochMilli() + 604700000));
		            url = s3b.generatePresignedUrl(generatePresignedUrlRequest);
		            //
		            AWS4SignerForRoleAuth signer = new AWS4SignerForRoleAuth( new URL(bucketUrl + key), METHOD_GET, AWSS3, REGION);
		            String authorizationQueryParameters = signer.computeSignature(new HashMap<String, String>(), 
		            												new HashMap<String, String>(),
		                                                            AWS4SignerBase.UNSIGNED_PAYLOAD, 
		                                                            awsAccessKey, 
		                                                            awsSecretKey);
		                    
		            String presignedUrl = bucketUrl + key + "?" + authorizationQueryParameters;
		            attachments.add(new AttachmentData(presignedUrl, FILE + fname.substring(1+fname.lastIndexOf(DOT)), mfile.getOriginalFilename()));
	        	}else {
			        attachments.add(new AttachmentData((AWS_PATH1+activeProfile+AWS_PATH2) + key, FILE + fname.substring(1+fname.lastIndexOf(DOT)), mfile.getOriginalFilename()));	        		
	        	}
	        	log.debug(attachments.toString());
		    }
		 } catch (AmazonServiceException e) {
             log.error("{}",e);
             throw new ApiException(e.getErrorCode(), utils.getErrorDescription(e.getMessage(), e.getStatusCode(), e.getErrorCode(), e.getErrorType().toString(), e.getRequestId()));
        } catch (IOException e) {
        	log.error("{}", e);
        	throw new ApiException("500", e.getMessage());
        }
		return attachments; 
	}

    @Override
	public AttachmentData uploadFile(AttachmentData at, String domainName) throws IOException {
		return at; 
	}
	
	@Override
	public void uploadFile(String bucket, String fileName, String binary)	{
	}


	@Override
	protected void uploadFile(String bucket, String fileName, byte[] contents) throws RuntimeException {
	}

	
	public URL updateLinks(String bucket, String key) {
		//AmazonS3 s3b = AmazonS3ClientBuilder.standard().withRegion(REGION).build(); GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(bucket, key).withMethod(HttpMethod.GET).withExpiration(new java.util.Date((Instant.now().toEpochMilli() + 604700000)));
        AWS4SignerForRoleAuth signer;
        URL url = null;
		try {
			signer = new AWS4SignerForRoleAuth( new URL(bucketUrl + key ), METHOD_GET, AWSS3, REGION);
	        String authorizationQueryParameters = signer.computeSignature(new HashMap<String, String>(), 
					new HashMap<String, String>(),
                    AWS4SignerBase.UNSIGNED_PAYLOAD, 
                    awsAccessKey, 
                    awsSecretKey);

	        String presignedUrl = bucketUrl + key + "?" + authorizationQueryParameters;
	        url = new URL(presignedUrl);
		} catch (MalformedURLException e) {
			throw new ApiException("500", "MalformedURLException exception: " + e.getMessage());
		}
        return url; //s3b.generatePresignedUrl(generatePresignedUrlRequest);
	}
}
