package com.ge.ren.notes.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.*;

/**
 * Patch
 */

public class Patch   {
  @JsonProperty("note")
  private String note;

  public Patch note(String note) {
    this.note = note;
    return this;
  }

  /**
   * Get note
   * @return note
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull
  public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

}

