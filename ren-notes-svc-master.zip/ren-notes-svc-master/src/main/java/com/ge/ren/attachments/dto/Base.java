package com.ge.ren.attachments.dto;

import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ge.ren.attachments.model.AttachmentData;

import io.swagger.annotations.ApiModelProperty;


public class Base { 

    @JsonProperty("id")
    public String id;
    @JsonProperty("bdomainName")
    public String bdomainName;
    @JsonProperty("bdomainId")
    public String bdomainId;
    @JsonProperty("btenantId")
    public String btenantId;
    @JsonProperty("btitle")
    public String btitle;
    @JsonProperty("bdescription")
    public String bdescription;
    @JsonProperty("bcreationDate")
    public String bcreationDate;
    @JsonProperty("bupdateDate")
    public String bupdateDate;
    @JsonProperty("bcreatedBy")
    public String bcreatedBy;
    @JsonProperty("bupdatedBy")
    public String bupdatedBy;
    @JsonProperty("btimestampc")
    private Timestamp btimestampc;
    @JsonProperty("btimestampu")
    private Timestamp btimestampu;
    @JsonProperty("bvalidDateBy")
    private String bvalidDateBy;
    @ApiModelProperty(example = "HIGH", value = "LOW")
    @JsonProperty("bpriority")
    private String bpriority;
    @ApiModelProperty(example = "category", value = "")
    @JsonProperty("bcategory")
    private String bcategory;
    @ApiModelProperty(example = "status", value = "active")
    @JsonProperty("bstatus")
    private String bstatus; // = "active";
    @JsonProperty("bscope")
    private String bscope; // = Scope.internal.toString();
    
    @JsonProperty("attachments")
    public List<AttachmentData> attachments;

    

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBdomainName() {
		return bdomainName;
	}
	public void setBdomainName(String bdomainName) {
		this.bdomainName = bdomainName;
	}
	public String getBdomainId() {
		return bdomainId;
	}
	public void setBdomainId(String bdomainId) {
		this.bdomainId = bdomainId;
	}
	public String getBtenantId() {
		return btenantId;
	}
	public void setBtenantId(String btenantId) {
		this.btenantId = btenantId;
	}
	public String getBtitle() {
		return btitle;
	}
	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}
	public String getBdescription() {
		return bdescription;
	}
	public void setBdescription(String bdescription) {
		this.bdescription = bdescription;
	}
	public String getBcreationDate() {
		return bcreationDate;
	}
	public void setBcreationDate(String bcreationDate) {
		this.bcreationDate = bcreationDate;
	}
	public String getBupdateDate() {
		return bupdateDate;
	}
	public void setBupdateDate(String bupdateDate) {
		this.bupdateDate = bupdateDate;
	}
	public String getBcreatedBy() {
		return bcreatedBy;
	}
	public void setBcreatedBy(String bcreatedBy) {
		this.bcreatedBy = bcreatedBy;
	}
	public String getBupdatedBy() {
		return bupdatedBy;
	}
	public void setBupdatedBy(String bupdatedBy) {
		this.bupdatedBy = bupdatedBy;
	}
	public Timestamp getBtimestampc() {
		return btimestampc;
	}
	public void setBtimestampc(Timestamp btimestampc) {
		this.btimestampc = btimestampc;
	}
	public Timestamp getBtimestampu() {
		return btimestampu;
	}
	public void setBtimestampu(Timestamp btimestampu) {
		this.btimestampu = btimestampu;
	}
	public String getBvalidDateBy() {
		return bvalidDateBy;
	}
	public void setBvalidDateBy(String bvalidDateBy) {
		this.bvalidDateBy = bvalidDateBy;
	}
	public String getBpriority() {
		return bpriority;
	}
	public void setBpriority(String bpriority) {
		this.bpriority = bpriority;
	}
	public String getBcategory() {
		return bcategory;
	}
	public void setBcategory(String bcategory) {
		this.bcategory = bcategory;
	}
	public String getBstatus() {
		return bstatus;
	}
	public void setBstatus(String bstatus) {
		this.bstatus = bstatus;
	}
	public String getBscope() {
		return bscope;
	}
	public void setBscope(String bscope) {
		this.bscope = bscope;
	}
	public List<AttachmentData> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<AttachmentData> attachments) {
		this.attachments = attachments;
	}
	public Base() {
		super();
	}
	public Base(String id, String domainName, String domainId, String tenantId, String title, String description,
			String creationDate, String updateDate, String createdBy, String updatedBy, Timestamp timestampc,
			Timestamp timestampu, List<AttachmentData> attachments) {
		super();
		this.id = id;
		this.bdomainName = domainName;
		this.bdomainId = domainId;
		this.btenantId = tenantId;
		this.btitle = title;
		this.bdescription = description;
		this.bcreationDate = creationDate;
		this.bupdateDate = updateDate;
		this.bcreatedBy = createdBy;
		this.bupdatedBy = updatedBy;
		this.btimestampc = timestampc;
		this.btimestampu = timestampu;
		this.attachments = attachments;
	}
	@Override
	public String toString() {
		return "Base [id=" + id + ", domainName=" + bdomainName + ", domainId=" + bdomainId + ", tenantId=" + btenantId
				+ ", title=" + btitle + ", description=" + bdescription + ", creationDate=" + bcreationDate
				+ ", updateDate=" + bupdateDate + ", createdBy=" + bcreatedBy + ", updatedBy=" + bupdatedBy
				+ ", timestampc=" + btimestampc + ", timestampu=" + btimestampu + ", validDateBy=" + bvalidDateBy
				+ ", priority=" + bpriority + ", category=" + bcategory + ", status=" + bstatus + ", scope=" + bscope
				+ ", attachments=" + attachments + "]";
	}
	
	
}
