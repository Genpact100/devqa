package com.ge.ren.attachments.utils;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import com.ge.ren.notes.exception.ApiException;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.List;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
//import java.nio.charset.Charset;
//import org.apache.commons.io.IOUtils;
@Component
@Slf4j
public class FileDownloader { //extends AbstractDownloader {

/*    @Override
    protected char[] downloadFile(String bucket, String fileName)
            throws RuntimeException {

        char[] charArray = null;
        InputStream inputStream = null;
        try {
        	File file = new ClassPathResource(bucket + fileName).getFile(); 
            String encodeImage = Base64.getEncoder().withoutPadding().encodeToString(Files.readAllBytes(file.toPath())); 
            Map<String, String> jsonMap = new HashMap<>(); 
            jsonMap.put("content", encodeImage); 
           
            inputStream = new FileInputStream(new File(bucket + fileName));
//			// write the inputStream to a FileOutputStream
//			int read = 0;
//			byte[] bytes = new byte[1024];
//			while ((read = inputStream.read(bytes)) != -1) {
//				outputStream.write(bytes, 0, read);
//			}
            //if (downloadType.name().indexOf(mycomConfigConstants.FOLDER_TYPE_DECODED) == -1) {
                // binary
                int fileLength = 0; //s3InputStream.available();
                List<Character> tempContents = new ArrayList<Character>();
                int content;
                while ((content = inputStream.read()) != -1) {
                    // convert to char and display it
                    tempContents.add((char) content);
                    //System.out.println((char) content);
                    fileLength++;
                }
                if (fileLength != tempContents.size()) {
                    throw new ApiException("500", "Error in converting inputStream to Char array " + fileLength + "<>" + tempContents.size());
                }
                System.out.println(fileLength);
                charArray = new char[fileLength];
                for (int m = 0; m < fileLength; m++) {
                    charArray[m] = tempContents.get(m);
                }
            //} else {
                // ascii
            //    charArray = IOUtils.toCharArray(inputStream, Charset.forName("UTF-8"));
            //}

            log.info("Data read complete");
            return charArray;
        } catch (IOException e) {
            log.error("{}",e);
            //response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            throw new ApiException("500",e.getMessage());
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    log.error("{}",e);
                }
            }
        }
    }*/

/*    @Override
    protected Map<String, char[]> downloadFiles(String bucket, List<String> fileNameList)
            throws RuntimeException {
        Map<String, char[]> fileMap = new HashMap<String, char[]>();
        if (fileNameList != null) {
            for (String fileName : fileNameList) {
                try {
                    char[] fileContent = downloadFile(bucket, fileName);
                    fileMap.put(fileName, fileContent);
                } catch (Exception e) {
                    //fail safe for non blocking file download
                    fileMap.put(fileName, null);
                }
            }
        }
        return fileMap;
    }
*/

/*    @Override
    protected InputStream downloadFileAsStream(String bucket, String fileName)
            throws RuntimeException {

        InputStream inputStream = null;
        try {

            inputStream = new FileInputStream(new File(bucket + fileName));
        } catch (IOException e) {
            log.error("{}",e);
            throw new ApiException("500",e.getMessage());
        }
        return inputStream;
    }
*/
}

