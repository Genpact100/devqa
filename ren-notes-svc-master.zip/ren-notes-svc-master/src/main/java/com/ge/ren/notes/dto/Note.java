package com.ge.ren.notes.dto;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ge.ren.notes.model.PatchNote;
import com.ge.ren.notes.model.PostNote;
import com.ge.ren.notes.model.SiteNotes;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.validation.constraints.*;

import com.ge.ren.attachments.model.AttachmentData;


/**
 * Notes
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Note   {

  private String id;
  @NotNull
  @ApiModelProperty(example = "500023", required = true, value = "")
  @JsonProperty("domainId")
  private String domainId;
  @NotNull
  @ApiModelProperty(example = "GE000WWW", value = "")
  @JsonProperty("tenantId")
  private String tenantId;
  @ApiModelProperty(example = "This is title", value = "")
  @JsonProperty("title")
  @NotNull
  @Max(value = 120)
  private String title;
  @ApiModelProperty(example = "This placeholder is for text notes", value = "")
  @JsonProperty("note")
  @Max(value = 4000)
  private String note;
  @ApiModelProperty(example = "06/09/2021 12:45:55", value = "")
  @JsonProperty("creationDate")
  private String creationDate; // = new Date(System.currentTimeMillis()).toGMTString();
  @ApiModelProperty(example = "06/10/2021 1:40:55", value = "")
  @JsonProperty("updateDate")
  private String updateDate;
  @ApiModelProperty(example = "06/11/2021 2:00:00", value = "")
  @JsonProperty("validDateBy")
  private String validDateBy;
  @ApiModelProperty(example = "HIGH", value = "LOW")
  @JsonProperty("priority")
  private String priority;
  @ApiModelProperty(example = "503206931", value = "")
  @JsonProperty("createdBy")
  private String createdBy;
  @ApiModelProperty(example = "503206931", value = "")
  @JsonProperty("updatedBy")
  private String updatedBy;
  @ApiModelProperty(example = "category", value = "")
  @JsonProperty("category")
  private String category;
  @ApiModelProperty(example = "status", value = "active")
  @JsonProperty("status")
  private String status; // = "active";
  @JsonProperty("scope")
  private String scope; // = Scope.internal.toString();
  
  @JsonProperty("timestampc")
  private Date timestampc;
  @JsonProperty("timestampu")
  private Date timestampu;
  
  @JsonProperty("deleted")
  private Boolean deleted = false;

  @JsonProperty("attachments")
  public List<AttachmentData> attachments;

  public Note(SiteNotes notes) {
		super();
		this.id = notes.getId();
		this.domainId = notes.getDomainId();
		this.tenantId = notes.getTenantId();
		this.title = notes.getTitle();
		this.note = notes.getNote();
		this.creationDate = notes.getCreationDate();
		this.updateDate = notes.getUpdateDate();
		this.validDateBy = notes.getValidDateBy();
		this.priority = notes.getPriority();
		this.createdBy = notes.getCreatedBy();
		this.updatedBy = notes.getUpdatedBy();
		this.category = notes.getCategory();
		this.status = notes.getStatus();
		this.scope = notes.getScope();
		this.deleted = notes.getDeleted();
  }
  
	  public Note(PostNote notes) {
			super();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
			sdf.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
			this.domainId = notes.getDomainId();
			this.title = notes.getTitle();
			this.note = notes.getNote();
			this.creationDate = sdf.format(new Date(System.currentTimeMillis())).toString();
			this.priority = notes.getPriority();
			this.category = notes.getCategory();
			this.scope = notes.getScope();
			this.status = notes.getStatus();
			this.validDateBy = notes.getValidDateBy();
	  }

	  public Note(PatchNote notes) {
		  	super();
		    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy HH:mm:ss");  
			sdf.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
		    this.title = notes.getTitle();
			this.note = notes.getNote();
			this.creationDate = sdf.format(new Date(System.currentTimeMillis())).toString();
			this.priority = notes.getPriority();
			this.category = notes.getCategory();
			this.scope = notes.getScope();
			this.status = notes.getStatus();
			this.validDateBy = notes.getValidDateBy();
			this.attachments = notes.getAttachments();

	  }
	  
    @Override
	public String toString() {
		return  "{\"id\":\"" + id + "\","
				+"\"domainId\":\"" + domainId + "\", \"tenantId\":\"" + tenantId + "\", \"title\":\"" + title + "\", \"note\":\""
				+ note + "\", \"creationDate\":\"" + creationDate + "\", \"updateDate\":\"" + updateDate + "\", \"validDateBy\":\"" + validDateBy
				+ "\", \"priority\":\"" + priority + "\", \"createdBy\":\"" + createdBy + "\", \"updatedBy\":\"" + updatedBy + "\", \"category\":\""
				+ category + "\", \"scope\":\"" + scope + "\", \"status\":\"" + status + "\", \"deleted\":" + deleted + ",\"attachments\":" + attachments +"}";
	}


}

