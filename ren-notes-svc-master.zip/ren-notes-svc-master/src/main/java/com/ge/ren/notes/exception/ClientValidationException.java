package com.ge.ren.notes.exception;

public class ClientValidationException extends ApiException {
    public ClientValidationException(String msg) {
        super("Client Validation Exception ", msg);
    }
}
