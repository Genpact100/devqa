package com.ge.ren.notes.constants;

public class Domain {
	public static enum DOMAIN {
		SITE("SITE"), ASSET("ASSET"), EVENT("EVENT"), CASE("CASE"), TASK("TASK");
		private final String DOMAIN;
		private DOMAIN(String domain) {
			DOMAIN = domain;
	    }
	}
}
