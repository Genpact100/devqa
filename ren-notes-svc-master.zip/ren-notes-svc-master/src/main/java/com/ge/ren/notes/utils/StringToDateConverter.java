package com.ge.ren.notes.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

import com.ge.ren.notes.exception.ResourceNotValid;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StringToDateConverter  implements Converter<String, Date> {
	  
	  public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	  /***
	   * dateInString has to be in the format of "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
	   * ex: 2021-08-01T11:11:02.0+00:00
	   * ParseException: When a parse error occurs, it returns null for Date and logs the exception
	   */
	  @Override
	  public Date convert(String dateInString) throws ResourceNotValid{
	    try {
	      SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
	      return formatter.parse(dateInString);
	    }catch(ParseException parseException) {
	      log.error("Unable to parse date from - {} to java.util.Date object", dateInString);
	      throw new ResourceNotValid("Unable to parse date "+dateInString+"to java.util.Date object");
	      //return null;
	    }
	    
	  }
	}