package com.ge.ren.notes.constants;

public enum Scope {
		internal,
		external
}
