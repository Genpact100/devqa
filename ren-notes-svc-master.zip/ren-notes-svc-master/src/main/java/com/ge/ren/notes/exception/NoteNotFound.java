package com.ge.ren.notes.exception;

public class NoteNotFound extends ApiException {
 	private static final long serialVersionUID = 4511835238916381631L;

	public NoteNotFound(String msg) {
        super("Note not found with provided ID: ", msg);
    }
}
