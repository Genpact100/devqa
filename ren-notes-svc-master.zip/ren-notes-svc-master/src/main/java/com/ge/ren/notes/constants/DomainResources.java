package com.ge.ren.notes.constants;

public enum DomainResources {
	siteNotes, assetNotes, eventNotes, taskNotes, caseNotes
}
