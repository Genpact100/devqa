
package com.ge.ren.attachments.model;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ge.ren.notes.dto.AttachmentBase;

import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Document(collection = "attachments")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Attachment { //extends AttachmentBase {


    @JsonProperty("id")
    public String id;
    @JsonProperty("domainName")
    public String domainName;
    @JsonProperty("domainId")
    public String domainId;
    @JsonProperty("tenantId")
    public String tenantId;
    @JsonProperty("title")
    public String title;
    @JsonProperty("description")
    public String description;
    @JsonProperty("creationDate")
    public String creationDate;
    @JsonProperty("updateDate")
    public String updateDate;
    @JsonProperty("createdBy")
    public String createdBy;
    @JsonProperty("updatedBy")
    public String updatedBy;
    @JsonProperty("timestampc")
    private Timestamp timestampc;
    @JsonProperty("timestampu")
    private Timestamp timestampu;
    @JsonProperty("attachments")
    public List<AttachmentData> attachments;

    public Attachment(PostAttachment pa) {
    	//super();
    	this.description = pa.getDescription();
    	this.domainId = pa.getDomainId();
    	this.domainName = pa.getDomainName();
    	this.title = pa.getTitle();
    	this.attachments = pa.getAttachments();
    }
}
