package com.ge.ren.attachments.utils;

public interface AttachmentMapper {

}
