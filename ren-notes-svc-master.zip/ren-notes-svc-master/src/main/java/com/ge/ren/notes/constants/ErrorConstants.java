package com.ge.ren.notes.constants;

public interface ErrorConstants {
		
		public static final String LOG_PLACE_HOLDER = "[{}] [{}] - {}";
		public enum ErrorCodes{
			JSON_PARSE_FAIL("Received Invalid json : "),
			MONGOCLIENT_ERROR_500("MongoClient_Error_500 : "),
			MONGOSERVER_ERROR_500("MongoServer_Error_500 : "),
			VALIDATION_ERROR_400("Validation_Error_400 : "),
			CODE_404("404 NOT_FOUND"),
			CODE_204("204 No_Data"),
			AUTHORIZATION_ERROR("Authorization_Error : "),
			SITE_GROUP_LOOKUP_ERROR("Failed at site group lookup : "),
			EXCEPTION_ERROR_500("Exception_Error_500 : "),
			EXCEPTION_400_BAD_REQUEST("Exception_400_Bad_Request : Query is not supported - "),
			DUPLICATE_IDS("Duplicate id's in BomAsRunning : "),		
			INVALID_COMPONENT_IDS("Invalid Component Id's : "),
			INVALID_COMPONENT_TYPES("Invalid Component Types : "),
			INVALID_HIERARCHY_ID("Invalid Hierarchy Id : "),
			INTERNAL_SERVER_ERROR("Internal server error occurred : ");
				
			ErrorCodes(String value) {
				this.errordesc = value;
			}
			
			private String errordesc = "";

			public String errordescription() {
				return errordesc;
			}
		}


	public enum VaidatedMessage{
		NOTE_NOT_FOUND("Note attribute has not been found."),
		DOMAINID_NOT_FOUND("Domain ID attribute is not found."),
		DOMAINNAME_NOT_FOUND("Domain Name attribute is not found."),
		NOT_FOUND("Document has not been found by ID: "),
		NOT_AUTHORIZED("Not Authorized due to scope mismatch: "),
		NOT_AUTHORIZED_SCOPE_OR_USERNAME("Not Authorized due to scope or username mismatch - contact Admin."),
		NOT_AUTHORIZED_SCOPE_1("1-Not Authorized due to scope mismatch - contact Admin."),
		NOT_AUTHORIZED_USERNAME_2("2-Not Authorized due to username mismatch - contact Admin."),
		NOT_AUTHORIZED_USERNAME_3("3-Not Authorized due to username mismatch - contact Admin."),
		NO_DATA("No Data found"),
		ATTRIBUTE_NOT_FOUND("Attribute Not Found. "),
		DOMAINID("domainId is required element in request body "),
		TITLE("title is required element in request body "),
		NOTE_SIZE_LIMIT("Notes size is limited not more charachters than: "),
		TITLE_SIZE_LIMIT("Title size is limited not more charachters than: "),
		SPEC_CHAR_INCLUDED("Special Characters have been included in json field: "),
		SCRIPT_INCLUDED("Script has been included into json field: "),
		DESCRIPTION_LIMIT("Description size is limited and should be not more than: "),
		ATTACHMENT_EMPTY_POST("At least One Item should be included in POST request: Title/Note or Description/Attachment File"),
		ATTACHMENT_EMPTY_PATCH("At least One Item should be included in PATCH request: Title/Note or Description/Attachment File"),
		FILE_TYPE_NOT_ALLOWED("The File Type selected is not allowed to save in s3 bucket: ");
		private String description = "";
		
		VaidatedMessage(String value) {
			this.description = value;
		}

		public String description() {
			return description;
		}
	}
	public static final String ERROR_TITLE = "ApiException";

}
