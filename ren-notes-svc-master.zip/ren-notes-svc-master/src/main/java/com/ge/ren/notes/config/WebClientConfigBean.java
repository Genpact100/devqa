package com.ge.ren.notes.config;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import org.springframework.context.annotation.Primary;
import org.springframework.beans.factory.annotation.Value;
@Configuration
public class WebClientConfigBean {
    @Value("${webclient.connection.timeout:5000}")
    private int timeout;
    @Value("${webclient.read.timeout:2}")
    private int readTimeout;
    @Value("${webclient.write.timeout:3}")
    private int writeTimeout;
    @Value("${rest.base.url:https://apis-intra-feature.rendigital.apps.ge.com}")
    private String baseUri;


    @SuppressWarnings("deprecation")
	@Bean
    @Primary
    public WebClient getWebClient() {
        HttpClient httpClient = HttpClient.create().tcpConfiguration((client) -> client.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, this.timeout).doOnConnected((conn) -> {conn.addHandlerLast(new ReadTimeoutHandler(this.readTimeout)).addHandlerLast(new WriteTimeoutHandler(this.writeTimeout)); }));
        ClientHttpConnector connector = new ReactorClientHttpConnector(httpClient);
        return WebClient.builder().baseUrl(this.baseUri).clientConnector(connector).defaultHeader("Content-Type", new String[]{"application/json"}).build();
    }
}
