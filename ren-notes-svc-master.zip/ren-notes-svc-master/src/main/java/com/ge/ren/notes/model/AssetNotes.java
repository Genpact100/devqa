package com.ge.ren.notes.model;

import com.ge.ren.notes.dto.Note;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * AssetNotes
 */

@Getter
@Setter
@Document(collection = "assetNotes")
public class AssetNotes extends Note{
  
}

