package com.ge.ren.attachments.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.ge.ren.attachments.model.Attachment;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.model.NotesRequest;

@Service
public interface AttachmentService {

	public String processGetRequest(String domainName, String id, int pageIdx, int pageSize, String queryString, String uri ) throws IOException;
	
	public ResponseEntity<Object> processPostRequest(NotesRequest request , Optional<MultipartFile[]> multipartFiles) throws JsonParseException, IOException;
	
	public <T> ResponseEntity<Object> processDeleteRequest(NotesRequest request, Class<T> entityClass) throws Exception;
	
	public <T> ResponseEntity<Object> processPatchRequest(NotesRequest request, Class<T> entityClass, Optional<MultipartFile[]> files) throws ApiException, JsonParseException, IOException;

	public String processGetRequest(NotesRequest noteRequest) throws  IOException;
	
	public <T> List<Attachment> processUpdateLinks(String id, List<Attachment> ats, Class<T> entityClass);


}
