package com.ge.ren.attachments.utils;
import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.ge.ren.attachments.model.AttachmentData;

public abstract class AbstractUploader {

	protected abstract List<AttachmentData> uploadFiles(String domainName, MultipartFile[] multipartFiles) throws IOException;
	
	protected abstract AttachmentData uploadFile(AttachmentData at, String domainName) throws IOException;

	protected abstract void uploadFile(String bucket, String fileName, byte[] contents) throws RuntimeException;
	
	protected abstract void uploadFile(String bucket, String fileName, String binary);
}
