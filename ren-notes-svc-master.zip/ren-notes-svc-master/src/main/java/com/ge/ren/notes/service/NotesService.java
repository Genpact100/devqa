package com.ge.ren.notes.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.ge.ren.notes.dto.Note;
import com.ge.ren.notes.exception.ApiException;
import com.ge.ren.notes.model.NotesRequest;


@Service
public interface NotesService {

	public String processGetRequest(NotesRequest request ) throws IOException;
	
	public <T> ResponseEntity<?>  processPostRequest(NotesRequest request, Optional<MultipartFile[]> multipartFiles ) throws JsonParseException, IOException;
	
	public <T> ResponseEntity<?> processDeleteRequest(NotesRequest request, Class<T> entityClass) throws Exception;
	
	public <T> ResponseEntity<?> processPatchRequest(NotesRequest request, Class<T> entityClass, Optional<MultipartFile[]> files) throws Exception;
	
	public <T> ResponseEntity<?> processBulkUpsertRequest(List<NotesRequest> requests) throws JsonParseException, IOException;

	public List<Note> processUpdateLinks(String id, List<Note> attachments, String domainName);

}
