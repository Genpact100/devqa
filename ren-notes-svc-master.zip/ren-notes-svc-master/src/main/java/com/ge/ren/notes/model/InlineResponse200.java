package com.ge.ren.notes.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * InlineResponse200
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class InlineResponse200   {
  @JsonProperty("original")
  private SiteNotes original = null;

  @JsonProperty("updated")
  private SiteNotes updated = null;

}

