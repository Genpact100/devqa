
package com.ge.ren.notes.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.ge.ren.attachments.model.AttachmentData;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "title",
	"note",
    "priority",
    "category",
    "scope",
    "status",
    "validDateBy",
    "updatedBy"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PatchNote {
	  public enum Scope {
			internal, external
	  }
    @JsonProperty("title")
    public String title;
    @JsonProperty("note")
    public String note;
    @JsonProperty("priority")
    public String priority;
    @JsonProperty("category")
    public String category;
    @JsonProperty("scope")
    public String scope = Scope.internal.toString();
    @JsonProperty("status")
    public String status;
    @JsonProperty("validDateBy")
    public String validDateBy;
    @JsonProperty("updatedBy")
    public String updatedBy;
    public List<AttachmentData> attachments;    

}
