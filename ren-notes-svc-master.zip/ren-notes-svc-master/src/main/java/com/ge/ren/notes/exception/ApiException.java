package com.ge.ren.notes.exception;

public class ApiException extends RuntimeException {

	private static final long serialVersionUID = -559330996403653594L;
	private final String code;

    public ApiException(String code, String msg) {
        super(msg);
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}