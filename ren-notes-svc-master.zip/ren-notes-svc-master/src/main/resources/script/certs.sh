mydir=/app/certs
truststore=${mydir}/rds-truststore.jks
storepassword=7rlI4njaWTXlFSAt

awk 'split_after == 1 {n++;split_after=0} /-----END CERTIFICATE-----/ {split_after=1}{print > "rds-ca-" n ".pem"}' < ${mydir}/global-bundle.pem
count=0
for CERT in rds-ca-*; do
  count=${count}+1
  #echo "Importing $alias"
  keytool -import -alias ${count} -file ${CERT} -storepass ${storepassword} -keystore ${truststore} -noprompt
  rm $CERT
done

rm ${mydir}/global-bundle.pem

awk 'split_after == 1 {n++;split_after=0} /-----END CERTIFICATE-----/ {split_after=1}{print > "Digi-CA-" n ".pem"}' < ${mydir}/DigiCertGlobalRootCA.pem
count=51
for CERT in Digi-CA-*; do
  count=${count}+1
  #echo "Importing $alias"
  keytool -import -alias ${count} -file ${CERT} -storepass ${storepassword} -keystore ${truststore} -noprompt
  rm $CERT
done

rm ${mydir}/DigiCertGlobalRootCA.pem

#echo "Trust store content is: "

keytool -list -v -keystore "$truststore" -storepass ${storepassword}
