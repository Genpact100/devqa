Create secrets in aws
Using files (helpful incase of large secret string, eg tokens)
echo -n 'admin' > ./username.txt
echo -n '1f2d1e2e67df' > ./password.txt
 
kubectl create secret generic <application-name>-secret \
--from-file=username=./username.txt \
--from-file=password=./password.txt


Using literals
kubectl create secret generic <application-name>-secret \
--from-literal=username='admin' \
--from-literal=password='1f2d1e2e67df'
Create a secret have name same as your application appended by keyword -secret, for easier identification (secret name can be anything)

Using yaml configuration
echo -n 'admin' | base64
echo -n '1f2d1e2e67df' | base64
bXktYXBw
Mzk1MjgkdmRnN0pi
Create a yaml file with following configuration for secret.

apiVersion: v1
kind: Secret
metadata:
  name: {{ .Values.application.name }}-secret
data:
  username: bXktYXBw
  password: Mzk1MjgkdmRnN0pi
kubectl apply -f <yaml file name>




To verify the secrets created using one of the above steps:

kubectl describe secrets <application-name>-secret


How to use it in your application ?
The secret once created will be available to the Pod thorough one of the following options.



 As container environment (preferred) 
env:
  - name: SECRET_USERNAME     # This is the name of the environment variable exposed to your application.
       valueFrom:
          secretKeyRef:
             name: {{ .Values.application.name }}-secret    # name of the secret.
             key: {{ .Values.application.secret.username}}  # name of the variable in the secret.
 
  - name: SECRET_PASSWORD     # This is the name of the environment variable exposed to your application.
        valueFrom:
            secretKeyRef:
                name: {{ .Values.application.name }}-secret    # name of the secret.
                key: {{ .Values.application.secret.password}}  # name of the variable in the secret.


       2. As files in a volume mounted on one or more of its containers

containers:
    - name: {{ .Values.application.tag }}
      image: {{ .Values.application.repository }}:{{ .Values.application.tag }}
      volumeMounts:
        # name must match the volume name below
        - name: secret-volume
          mountPath: /etc/secret-volume
  # The secret data is exposed to Containers in the Pod through a Volume.
  volumes:
    - name: secret-volume
      secret:
        secretName: {{ .Values.application.name }}-secret    # name of the secret.