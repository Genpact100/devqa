08/08/2022
1. Increase the pod size to improve performance: min - 4 and max - 5.