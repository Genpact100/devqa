// Build the code
def build() {
    sh 'mvn -s ./devops/settings.xml clean install -DskipTests=true'
}


// Run unit tests
def unitTest() {
    echo 'Running unit tests'
    sh 'mvn -s ./devops/settings.xml install'
    //sh 'mvn -s ./devops/settings.xml test jacoco:report' 
}

return this
